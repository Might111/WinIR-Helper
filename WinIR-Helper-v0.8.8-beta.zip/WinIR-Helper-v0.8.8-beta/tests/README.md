﻿# tests

当前目录用于后续放 Pester 测试。建议优先补以下用例：

```text
1. Listen 0.0.0.0 不应计入公网连接。
2. SecurityEventIds 应包含 4722/4723/4724/4725/4728/4738/4740/4688/4702。
3. Startup LNK 处置建议应删除 .lnk 本体，不应删除 powershell.exe/cmd.exe。
4. Winlogon SpecialAccounts 命中时，账户入侵证据链应提升到高危。
5. Offline 模式未提供 LogFolder 时应停止并提示。
```
