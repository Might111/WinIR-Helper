﻿# WinIR-Helper v0.8.8-beta module: 22-Collect-ServiceEvents.ps1
# This module is dot-sourced by WinIR-Helper.ps1.

# =========================================================
# 模块 3：服务安装 7045
# =========================================================

Write-Info "正在分析服务安装事件 7045..."

$ServiceEventsRaw = @()
$ServiceEvents = @()
$raw7045 = Get-EventsById -LogName "System" -Ids @(7045)

foreach ($evt in $raw7045) {
    try {
        [xml]$xml = $evt.ToXml()
        $serviceName = Get-EventDataValue -Xml $xml -Name "ServiceName"
        $imagePath   = Get-EventDataValue -Xml $xml -Name "ImagePath"
        $accountName = Get-EventDataValue -Xml $xml -Name "AccountName"

        if (-not $serviceName) { $serviceName = Get-EventMessageValue -Message $evt.Message -FieldName "Service Name" }
        if (-not $imagePath)   { $imagePath   = Get-EventMessageValue -Message $evt.Message -FieldName "Service File Name" }

        $riskLevel = "关注"
        $riskReason = "新服务安装，需要确认来源"

        if (Test-IsTrustedServiceEvent -ServiceName $serviceName -ImagePath $imagePath) {
            $riskLevel = "正常"
            $riskReason = "常见系统/厂商/安全工具服务，默认不进入重点关注项"
        }
        elseif ("$serviceName $imagePath" -match "(?i)c3pool|xmrig|miner|WinRing0|nssm|monero|stratum") {
            $riskLevel = "高危"
            $riskReason = "服务名或路径命中挖矿/驱动/服务持久化特征"
        }
        elseif (Test-IsSuspiciousPersistencePath -PathOrCommand $imagePath) {
            $riskLevel = "高危"
            $riskReason = "服务路径位于可写目录并执行可疑文件/脚本"
        }
        elseif ($serviceName -match "^[a-zA-Z]{5,14}$" -and $imagePath -match "(?i)\\system32\\drivers\\.*\.sys") {
            # OWNeac/反作弊/安全驱动一类不直接判高危，但保留关注，避免误导用户直接禁用驱动。
            if ("$serviceName $imagePath" -match "(?i)OWNeac|NeacSafe|anti.?cheat|netease|naraka") {
                $riskLevel = "关注"
                $riskReason = "疑似第三方驱动/反作弊或安全组件，需要复核签名与来源，不建议直接禁用"
            }
            else {
                $riskLevel = "中危"
                $riskReason = "随机命名驱动服务，需要复核签名与来源"
            }
        }

        $ServiceEventsRaw += [PSCustomObject]@{
            Level       = $riskLevel
            TimeCreated = $evt.TimeCreated
            ServiceName = $serviceName
            ImagePath   = $imagePath
            AccountName = $accountName
            Reason      = $riskReason
        }
    }
    catch {}
}

# v0.8.3：同一服务重复安装/更新按 ServiceName + ImagePath 聚合，避免报告刷屏。
$ServiceEvents = @(
    $ServiceEventsRaw |
        Group-Object { ("{0}|{1}" -f $_.ServiceName,$_.ImagePath).ToLowerInvariant() } |
        ForEach-Object {
            $items = @($_.Group | Sort-Object TimeCreated)
            $first = $items | Select-Object -First 1
            $last  = $items | Select-Object -Last 1
            [PSCustomObject]@{
                Level       = $last.Level
                TimeCreated = $last.TimeCreated
                FirstSeen   = $first.TimeCreated
                LastSeen    = $last.TimeCreated
                HitCount    = $items.Count
                ServiceName = $last.ServiceName
                ImagePath   = $last.ImagePath
                AccountName = $last.AccountName
                Reason      = $last.Reason
            }
        }
)

foreach ($item in ($ServiceEvents | Where-Object { $_.Level -ne "正常" })) {
    Add-Finding -Level $item.Level -Category "服务安装" -Title "发现服务安装线索" `
        -Evidence "服务=$($item.ServiceName)，路径=$($item.ImagePath)，首次=$($item.FirstSeen)，最近=$($item.LastSeen)，次数=$($item.HitCount)，原因=$($item.Reason)" `
        -Suggestion "先复核服务文件签名、Hash、创建时间和业务归属。对第三方安全/反作弊/扫描器组件只建议复核，不建议直接禁用。"
}

Export-DetailCsv -Name "7045_服务安装事件.csv" -Data $ServiceEvents
Export-DetailCsv -Name "7045_服务安装原始事件.csv" -Data $ServiceEventsRaw

# =========================================================
