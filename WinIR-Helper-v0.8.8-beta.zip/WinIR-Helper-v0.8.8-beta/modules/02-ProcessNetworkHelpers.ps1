﻿# WinIR-Helper v0.8.8-beta module: 02-ProcessNetworkHelpers.ps1
# This module is dot-sourced by WinIR-Helper.ps1.

# =========================================================
# 进程与端口辅助函数
# =========================================================

function Get-TotalPhysicalMemoryMB {
    try {
        $cs = Get-CimInstance Win32_ComputerSystem -ErrorAction Stop
        return [Math]::Round($cs.TotalPhysicalMemory / 1MB, 2)
    }
    catch { return 0 }
}

function Get-ProcessMemoryMB {
    param([int]$ProcessId)

    try {
        $p = Get-Process -Id $ProcessId -ErrorAction Stop
        return [Math]::Round($p.WorkingSet64 / 1MB, 2)
    }
    catch { return 0 }
}

function Get-ProcessCpuPercentMap {
    param([int]$SampleSeconds = 3)

    $result = @{}

    try {
        if ($SampleSeconds -lt 1) { $SampleSeconds = 1 }

        $cores = [Environment]::ProcessorCount
        if ($cores -le 0) { $cores = 1 }

        $first = @{}
        Get-Process -ErrorAction SilentlyContinue | ForEach-Object {
            try { $first[$_.Id] = $_.TotalProcessorTime.TotalSeconds } catch {}
        }

        Start-Sleep -Seconds $SampleSeconds

        Get-Process -ErrorAction SilentlyContinue | ForEach-Object {
            try {
                if ($first.ContainsKey($_.Id)) {
                    $delta = $_.TotalProcessorTime.TotalSeconds - $first[$_.Id]
                    $percent = ($delta / $SampleSeconds / $cores) * 100
                    if ($percent -lt 0) { $percent = 0 }
                    $result[$_.Id] = [Math]::Round($percent, 2)
                }
            }
            catch {}
        }
    }
    catch {}

    return $result
}

function Get-DangerousPortInfo {
    param([int]$Port)

    $map = @{
        21    = "FTP，明文传输风险"
        22    = "SSH，远程管理端口"
        23    = "Telnet，明文远程登录高风险"
        135   = "RPC，Windows 横向移动常见相关端口"
        139   = "NetBIOS，Windows 文件共享相关端口"
        445   = "SMB，Windows 文件共享/爆破/横向移动重点端口"
        1433  = "MSSQL 数据库"
        3306  = "MySQL 数据库"
        3389  = "RDP 远程桌面，高危暴露端口"
        5432  = "PostgreSQL 数据库"
        5900  = "VNC 远程控制"
        5985  = "WinRM HTTP，Windows 远程管理"
        5986  = "WinRM HTTPS，Windows 远程管理"
        6379  = "Redis 数据库"
        7001  = "WebLogic 常见端口"
        8080  = "常见 Web/代理/管理端口"
        9200  = "Elasticsearch"
        11211 = "Memcached"
        27017 = "MongoDB"
    }

    if ($map.ContainsKey($Port)) { return $map[$Port] }

    try {
        if ($script:WinIRConfig -and $script:WinIRConfig.HighRiskPorts) {
            foreach ($p in @($script:WinIRConfig.HighRiskPorts)) {
                if ([int]$p -eq [int]$Port) { return "配置文件定义的高风险端口" }
            }
        }
    }
    catch {}

    return ""
}


function Test-IsPathUnderKnownGoodRoot {
    param([string]$PathOrCommand)

    if ([string]::IsNullOrWhiteSpace($PathOrCommand)) { return $false }
    $text = $PathOrCommand.Trim()

    try {
        if ($script:WinIRConfig -and $script:WinIRConfig.IgnorePaths) {
            foreach ($root in @($script:WinIRConfig.IgnorePaths)) {
                if ([string]::IsNullOrWhiteSpace([string]$root)) { continue }
                $rootText = ([string]$root).TrimEnd('\')
                $escaped = [regex]::Escape($rootText) -replace '\\*','[^\\]+'
                if ($text -match ("(?i)^" + $escaped + "(\\|$)")) { return $true }
            }
        }
    } catch {}

    if ($text -match '(?i)C:\\Program Files \(x86\)\\Acunetix\\|C:\\ProgramData\\Acunetix\\|C:\\Program Files\\Npcap\\|C:\\Program Files\\Tenable\\|C:\\ProgramData\\Tenable\\|C:\\ProgramData\\Nessus\\|C:\\Users\\[^\\]+\\AppData\\Roaming\\BurpSuite\\') {
        return $true
    }

    return $false
}

function Test-IsKnownSecurityToolArtifact {
    param([string]$Text)

    if ([string]::IsNullOrWhiteSpace($Text)) { return $false }
    $t = $Text.Trim()

    try {
        if ($script:WinIRConfig -and $script:WinIRConfig.KnownSecurityToolKeywords) {
            foreach ($kw in @($script:WinIRConfig.KnownSecurityToolKeywords)) {
                if ([string]::IsNullOrWhiteSpace([string]$kw)) { continue }
                if ($t -match ("(?i)" + [regex]::Escape([string]$kw))) { return $true }
            }
        }
    } catch {}

    return ($t -match '(?i)Acunetix|Invicti|Nessus|Tenable|Npcap|Wireshark|BurpSuite|PortSwigger')
}

function Test-IsLocalOrPrivateIocValue {
    param([string]$Value)

    if ([string]::IsNullOrWhiteSpace($Value)) { return $true }
    $v = $Value.Trim().Trim('"',"'",',',';',')',']')
    if ([string]::IsNullOrWhiteSpace($v)) { return $true }

    if ($v -match '(?i)localhost|127\.0\.0\.1|0\.0\.0\.0|\[::1\]|^::1$') { return $true }

    try {
        $u = $null
        if ([System.Uri]::TryCreate($v, [System.UriKind]::Absolute, [ref]$u)) {
            $host = $u.Host
            if ($host -match '(?i)^(localhost|127\.0\.0\.1|0\.0\.0\.0|::1)$') { return $true }
            if (Test-IsNonPublicIP -IP $host) { return $true }
        }
    } catch {}

    # host:port 或日志中截取出来的 (host:port) 场景
    if ($v -match '(?i)(^|[\s\(\[])(localhost|127\.0\.0\.1|0\.0\.0\.0|::1):\d{1,5}') { return $true }
    if ($v -match '(?i)^https?://(localhost|127\.0\.0\.1|0\.0\.0\.0|\[::1\])') { return $true }

    return $false
}

function Test-IsProbablyMiningIoc {
    param(
        [string]$Type,
        [string]$Value,
        [string]$Context
    )

    $text = "$Type $Value $Context"
    if ([string]::IsNullOrWhiteSpace($Value)) { return $false }
    if (Test-IsLocalOrPrivateIocValue -Value $Value) { return $false }

    # stratum/tcp/ssl 是高价值矿池特征；普通 http(s) 必须同时有矿池、钱包、矿工等上下文。
    if ($Value -match '(?i)^stratum\+|^(ssl|tcp)://') { return $true }
    if ($text -match '(?i)xmrig|xmr-stak|monero|stratum|cryptonight|nanominer|cpuminer|minerd|c3pool|矿池|钱包|wallet|worker|pool|miner') { return $true }

    return $false
}

function Test-IsHashCandidatePath {
    param([string]$Path)

    if ([string]::IsNullOrWhiteSpace($Path)) { return $false }
    $p = $Path.Trim().Trim('"',"'")
    if ([string]::IsNullOrWhiteSpace($p)) { return $false }

    # 排除数据库页文件、日志目录等低价值对象，避免 Hash 建议刷屏。
    try {
        if ($script:WinIRConfig -and $script:WinIRConfig.HashIgnorePathRegex) {
            foreach ($rx in @($script:WinIRConfig.HashIgnorePathRegex)) {
                if ([string]::IsNullOrWhiteSpace([string]$rx)) { continue }
                if ($p -match [string]$rx) { return $false }
            }
        }
    } catch {}

    if ($p -match '(?i)\\db\\base\\|\\db\\global\\|\\ProgramData\\Acunetix\\db\\|\\Logs?\\') { return $false }

    $ext = ""
    try { $ext = [System.IO.Path]::GetExtension($p).ToLowerInvariant() } catch { $ext = "" }
    $allowed = @('.exe','.dll','.sys','.ps1','.bat','.cmd','.vbs','.js','.jse','.wsf','.hta','.scr','.lnk','.msi')
    try {
        if ($script:WinIRConfig -and $script:WinIRConfig.HashCandidateExtensions) {
            $allowed = @($script:WinIRConfig.HashCandidateExtensions | ForEach-Object { ([string]$_).ToLowerInvariant() })
        }
    } catch {}

    return ($allowed -contains $ext)
}

function Limit-TextForReport {
    param(
        [string]$Text,
        [int]$MaxLength = 300
    )
    if ([string]::IsNullOrWhiteSpace($Text)) { return "" }
    $clean = ($Text -replace "`r|`n", " ")
    if ($clean.Length -le $MaxLength) { return $clean }
    return ($clean.Substring(0, $MaxLength) + " ...[truncated]")
}

function Extract-ExecutablePath {
    param([string]$Command)

    if ([string]::IsNullOrWhiteSpace($Command)) { return "" }

    $c = $Command.Trim()

    if ($c -match '^\s*"([^"]+)"') {
        return $matches[1]
    }

    if ($c -match '^([A-Za-z]:\\[^\s]+)') {
        return $matches[1]
    }

    return $c.Split(" ")[0]
}

function Test-IsBuiltinTask {
    param(
        [string]$TaskPath,
        [string]$Actions
    )

    $text = "$TaskPath $Actions"

    # v0.6.6：OneDrive 用户启动任务精细白名单。
    # Get-ScheduledTask 的 TaskPath 通常只是 "\"，任务名不一定在 TaskPath 中，所以这里精确匹配官方 Action 路径。
    # 伪装 OneDrive 名称但 Action 指向 wscript/mshta/powershell/ProgramData 的任务不会被放过。
    if ($Actions -match '(?i)^"?C:\\Users\\[^\\]+\\AppData\\Local\\Microsoft\\OneDrive\\[^\\]+\\OneDriveLauncher\.exe"?\s+/startInstances\s*$') {
        return $true
    }
    if ($Actions -match '(?i)^"?C:\\Users\\[^\\]+\\AppData\\Local\\Microsoft\\OneDrive\\OneDrive\.exe"?\s+/(background|startup|startInstances)\b') {
        return $true
    }
    if ($TaskPath -match "(?i)^\\OneDrive Startup Task-" -and
        $Actions -match "(?i)\\AppData\\Local\\Microsoft\\OneDrive\\[^\\]+\\OneDriveLauncher\.exe\b|\\AppData\\Local\\Microsoft\\OneDrive\\OneDrive\.exe\b") {
        return $true
    }

    # v0.8.3：真机降噪。Npcap 与 Windows Hotpatch 的计划任务在正常环境中常见，
    # 不应仅因 .bat/.cmd 或 Microsoft\Windows 路径被归为可疑。
    if ($text -match '(?i)^\\npcapwatchdog\b' -and $Actions -match '(?i)^"?C:\\Program Files\\Npcap\\CheckStatus\.bat"?\b') {
        return $true
    }
    if ($text -match '(?i)^\\Microsoft\\Windows\\Hotpatch\\Monitoring\b' -and $Actions -match '(?i)%systemroot%\\system32\\cmd\.exe\s+/d\s+/c\s+%systemroot%\\system32\\hpatchmonTask\.cmd') {
        return $true
    }
    try {
        if ($script:WinIRConfig -and $script:WinIRConfig.KnownGoodTaskPatterns) {
            foreach ($pat in @($script:WinIRConfig.KnownGoodTaskPatterns)) {
                if ([string]::IsNullOrWhiteSpace([string]$pat)) { continue }
                if ("$TaskPath" -eq [string]$pat -or "$text" -match ("(?i)^" + [regex]::Escape([string]$pat))) { return $true }
            }
        }
    } catch {}

    # v0.6.2：先处理高置信系统任务白名单，避免 Defender / NetTrace 这类系统任务因 ProgramData 或 vbs 被误报。
    # 注意：这里是精确白名单，不会放过伪装在 Microsoft\Windows 下、但 Action 指向可疑目录或脚本链的任务。
    if ($TaskPath -match "(?i)^\\Microsoft\\Windows\\Windows Defender\\" -and
        $Actions -match "(?i)\\ProgramData\\Microsoft\\Windows Defender\\platform\\[^\\]+\\MpCmdRun\.exe\b") {
        return $true
    }

    if ($TaskPath -match "(?i)^\\Microsoft\\Windows\\NetTrace\\" -and
        $Actions -match "(?i)%windir%\\system32\\gatherNetworkInfo\.vbs\b|\\Windows\\system32\\gatherNetworkInfo\.vbs\b") {
        return $true
    }

    # v0.6.1+：不要只因为任务挂在 \Microsoft\Windows 下就直接白名单。
    # 真实攻击/挖矿常把任务伪装到 UpdateOrchestrator、WDI、Application Experience 等目录下。
    # 只要 Action 指向 ProgramData/AppData/Temp/Public/Downloads，或使用 powershell/wscript/mshta/bat/hta 等可疑执行链，必须继续分析。
    $actionLooksSuspicious = $false
    if ($Actions -match "(?i)\\ProgramData\\|\\Users\\[^\\]+\\AppData\\|\\Users\\Public\\|\\Windows\\Temp\\|\\Temp\\|\\Downloads\\") { $actionLooksSuspicious = $true }
    if ($Actions -match "(?i)\.(ps1|vbs|js|jse|wsf|hta|bat|cmd|scr)\b|powershell(\.exe)?|wscript(\.exe)?|cscript(\.exe)?|mshta(\.exe)?|-ExecutionPolicy|Bypass|WindowStyle\s+Hidden|-enc|-encodedcommand|stratum|xmrig|miner|c3pool") { $actionLooksSuspicious = $true }

    if ($actionLooksSuspicious) {
        return $false
    }

    if ($TaskPath -match "^\\Microsoft\\Windows\\") {
        if ($text -match "(?i)Windows Defender|Workplace Join|Application Experience|ApplicationData|AppxDeploymentClient|Autochk|DiskDiagnostic|NetTrace|GatherNetworkInfo|PLA|Server Manager|SharedPC|Software Inventory Logging|StateRepository|Time Zone|Windows Filtering Platform|WindowsUpdate|Shell|Registry|Bluetooth|CloudExperienceHost|Defrag|Diagnosis|Maps|MemoryDiagnostic|MobilePC|Power Efficiency Diagnostics|Ras|Servicing|Setup|Speech|TextServicesFramework|Time Synchronization|UpdateOrchestrator|WDI|WOF") {
            return $true
        }
    }

    if ($text -match "(?i)WpsUpdate|Kingsoft|ksolaunch\.exe|WPS Office") {
        return $true
    }

    return $false
}


function Test-IsTrustedServiceEvent {
    param(
        [string]$ServiceName,
        [string]$ImagePath
    )

    $text = "$ServiceName $ImagePath"

    if ($text -match "(?i)Microsoft Defender|MpDefenderCoreService|MpKsl|MicrosoftEdgeElevationService|Intel\(R\)|VMware VMCI|WPS Office Cloud Service|Printer Extensions|Kingsoft|KslD|Windows Defender") {
        return $true
    }

    # v0.8.7：Hyper-V / WSL / Docker 常见虚拟化网络组件降噪。
    # VMSMP + vmswitch.sys 是 Hyper-V 虚拟交换机相关服务，不能按随机驱动服务给出禁用建议。
    if ($ServiceName -match "(?i)^VMSMP$" -and $ImagePath -match "(?i)\\SystemRoot\\System32\\drivers\\vmswitch\.sys|\\System32\\drivers\\vmswitch\.sys") { return $true }
    if ($text -match "(?i)Hyper-V|HyperV|vmcompute|vmms|vmswitch|WSL Service|Docker Desktop Service") { return $true }

    # v0.8.3：真机环境降噪。安全扫描器、抓包驱动、已知第三方服务只在白名单路径下降噪。
    if ($text -match "(?i)Acunetix|Invicti" -and $ImagePath -match "(?i)C:\\Program Files \(x86\)\\Acunetix\\|C:\\ProgramData\\Acunetix\\") { return $true }
    if ($text -match "(?i)Nessus|Tenable" -and $ImagePath -match "(?i)C:\\Program Files\\Tenable\\|C:\\ProgramData\\Tenable\\|C:\\ProgramData\\Nessus\\") { return $true }
    if ($text -match "(?i)Npcap|npf" -and $ImagePath -match "(?i)C:\\Windows\\System32\\drivers\\npcap|C:\\Program Files\\Npcap\\") { return $true }

    try {
        if ($script:WinIRConfig -and $script:WinIRConfig.KnownGoodServices) {
            foreach ($svc in @($script:WinIRConfig.KnownGoodServices)) {
                if ([string]::IsNullOrWhiteSpace([string]$svc)) { continue }
                if ($ServiceName -eq [string]$svc -and (Test-IsPathUnderKnownGoodRoot -PathOrCommand $ImagePath)) { return $true }
            }
        }
    } catch {}

    # v0.6.3：Microsoft Update Health Tools 是 Windows 更新健康组件，避免作为新服务关注项刷屏。
    # 只对白名单路径降噪；如果同名服务出现在 ProgramData/AppData/Temp 等可疑路径，仍会进入后续风险判断。
    if ($ServiceName -match "(?i)^Microsoft Update Health Service$" -and
        $ImagePath -match "(?i)^`"?C:\\Program Files\\Microsoft Update Health Tools\\uhssvc\.exe`"?$") {
        return $true
    }

    # v0.6.6：Microsoft PC Manager Service 精细白名单。
    # 只对白名单 WindowsApps 路径降噪；同名服务若出现在 ProgramData/AppData/Temp，仍按可疑处理。
    if ($ServiceName -match "(?i)^Microsoft PC Manager Service$" -and
        $ImagePath -match "(?i)^`"?C:\\Program Files\\WindowsApps\\Microsoft\.MicrosoftPCManager_[^\\]+\\PCManager\\MSPCManagerService\.exe`"?$") {
        return $true
    }

    return $false
}


function Test-IsCoreWindowsProcess {
    param(
        [string]$Name,
        [string]$Path
    )

    if ([string]::IsNullOrWhiteSpace($Name)) { return $false }

    $coreNames = @(
        "System Idle Process","System","Registry","smss.exe","csrss.exe","wininit.exe",
        "winlogon.exe","services.exe","lsass.exe","svchost.exe","fontdrvhost.exe",
        "WUDFHost.exe","spoolsv.exe","dwm.exe","sihost.exe","ctfmon.exe","taskhostw.exe",
        "AggregatorHost.exe","conhost.exe","unsecapp.exe","WmiPrvSE.exe"
    )

    if ($Name -notin $coreNames) { return $false }

    if ([string]::IsNullOrWhiteSpace($Path)) {
        return $true
    }

    if ($Path -match "(?i)^C:\\Windows\\System32\\|^C:\\Windows\\system32\\|^C:\\Windows\\SysWOW64\\") {
        return $true
    }

    return $false
}

function Test-IsTrustedVendorCommand {
    param([string]$Command)

    if ([string]::IsNullOrWhiteSpace($Command)) { return $false }

    $c = $Command.Trim()

    # 常见可信厂商 / 常驻项降噪。这里只对白名单命令做降级，不代表完全安全。
    if ($c -match "(?i)\\Kingsoft\\WPS Office\\|ksolaunch\.exe|photolaunch\.exe|WPS Office|\\Oray\\SunLogin\\|SunloginClient\.exe|sunlogin_guard\.exe|SecurityHealthSystray\.exe|AzureArcSysTray\.exe|HipsTray\.exe") {
        return $true
    }

    # v0.8.3：开发/安全测试机常见软件降噪。仍建议报告中保留完整启动项明细，但不作为高危持久化。
    if ($c -match "(?i)\\AppData\\Local\\QuarkUpdater\\.*\\updater\.exe|\\AppData\\Local\\Programs\\Ollama\\ollama app\.exe|C:\\Program Files\\Npcap\\CheckStatus\.bat") {
        return $true
    }

    # v0.8.6：BurpSuite/PortSwigger 内置 Chromium 会包含 headless、proxy、ignore-certificate 等测试参数，
    # 不应仅因 AppData 路径和 https/proxy 参数被判为可疑进程。
    if ($c -match "(?i)\\AppData\\Roaming\\BurpSuite\\burpbrowser\\.*\\chrome\.exe|PortSwigger|--proxy-server=localhost:\d+.*\\burp\\browser\\data") {
        return $true
    }

    # OneDrive 默认启动项与升级清理 RunOnce 在干净 Windows 中很常见，避免刷屏。
    if ($c -match '(?i)\\AppData\\Local\\Microsoft\\OneDrive\\OneDrive\.exe"?\s+/background') {
        return $true
    }
    if ($c -match '(?i)^"?C:\\Users\\[^\\]+\\AppData\\Local\\Microsoft\\OneDrive\\[^\\]+\\OneDriveLauncher\.exe"?\s+/startInstances\s*$') {
        return $true
    }
    if ($c -match '(?i)\\Windows\\system32\\cmd\.exe\s+/q\s+/c\s+(del|rmdir).+\\AppData\\Local\\Microsoft\\OneDrive\\') {
        return $true
    }
    if ($c -match '(?i)\\AppData\\Local\\Microsoft\\OneDrive\\(Update|StandaloneUpdater)\\OneDriveSetup\.exe') {
        return $true
    }
    if ($c -match '(?i)\\AppData\\Local\\Microsoft\\OneDrive\\[^\\]+\\OneDriveLauncher\.exe\b|\\AppData\\Local\\Microsoft\\OneDrive\\OneDrive\.exe\b') {
        return $true
    }

    return $false
}


function Test-IsKnownPublicNetworkNoise {
    param(
        [string]$ProcessName,
        [string]$ProcessPath
    )

    $name = Safe-String $ProcessName
    $path = Safe-String $ProcessPath
    $text = "$name $path"

    try {
        if ($script:WinIRConfig) {
            foreach ($ignoreName in @($script:WinIRConfig.IgnoreProcessNames)) {
                if (-not [string]::IsNullOrWhiteSpace($ignoreName) -and $name -ieq $ignoreName) { return $true }
            }
            if (Test-IsPathUnderKnownGoodRoot -PathOrCommand $path) { return $true }
        }
    }
    catch {}

    # 常见 Windows / Microsoft 组件公网连接，默认从'公网连接明细'中降噪。
    # 这里只影响网络连接展示，不影响可疑进程、启动项、服务和挖矿配置判断。
    if ($text -match '(?i)MsMpEng\.exe|MpDefenderCoreService\.exe|SecurityHealthService\.exe|SearchApp\.exe|SkypeApp\.exe|OneDrive\.exe|MicrosoftEdge|msedge\.exe') {
        return $true
    }

    if ($path -match '(?i)^C:\\Windows\\SystemApps\\|^C:\\Program Files\\WindowsApps\\|^C:\\Program Files \(x86\)\\Microsoft\\|^C:\\Program Files\\Microsoft\\') {
        return $true
    }

    # svchost 公网连接在 Windows Update / Defender / 系统服务中较常见，默认降噪；
    # 若进程位于可疑目录或命令行可疑，会在资源异常模块中体现。
    if ($name -match '(?i)^svchost\.exe$' -and $path -match '(?i)^C:\\Windows\\') {
        return $true
    }

    return $false
}

function Test-IsScriptOrDangerPersistence {
    param([string]$Command)

    if ([string]::IsNullOrWhiteSpace($Command)) { return $false }

    if ($Command -match "(?i)\.(bat|cmd|ps1|vbs|js|jse|wsf|scr|hta)\b") { return $true }
    if ($Command -match "(?i)-enc|-encodedcommand|downloadstring|downloadfile|iex\s|invoke-expression|certutil.*-urlcache|bitsadmin|mshta|regsvr32.*scrobj|rundll32.*javascript|net\s+user|net\s+localgroup|add-localgroupmember|xmrig|miner|c3pool|stratum|monero") { return $true }

    return $false
}

function Get-ResourceTitle {
    param(
        [string]$Tags,
        [string]$RiskLevel
    )

    if ($Tags -match "挖矿|矿池|c3pool|xmrig|WinRing0") {
        return "发现疑似挖矿进程"
    }

    if ($Tags -match "CPU占用|内存占用") {
        return "发现资源占用异常进程"
    }

    return "发现可疑进程线索"
}

function Add-MiningCandidateDir {
    param(
        [System.Collections.Generic.List[string]]$List,
        [string]$Value
    )

    if ([string]::IsNullOrWhiteSpace($Value)) { return }

    try {
        $pathMatches = [regex]::Matches($Value, '[A-Za-z]:\\[^"''\s<>|]+')
        foreach ($m in $pathMatches) {
            $p = $m.Value.Trim().TrimEnd(',', ';', ')', ']')
            if ([string]::IsNullOrWhiteSpace($p)) { continue }

            $dir = ""
            if (Test-Path $p -PathType Container) {
                $dir = (Resolve-Path $p).Path
            }
            elseif (Test-Path $p -PathType Leaf) {
                $dir = Split-Path -Path (Resolve-Path $p).Path -Parent
            }
            else {
                # 文件可能已不存在，仍尝试从路径推断目录
                if ($p -match '\\') {
                    $dir = Split-Path -Path $p -Parent
                }
            }

            if (-not [string]::IsNullOrWhiteSpace($dir) -and (Test-Path $dir -PathType Container)) {
                # v0.6.2：候选目录进入队列前先做边界检查，避免把 C:\ProgramData\Microsoft\Windows、
                # Windows Defender 平台目录等过宽/系统目录拉进挖矿配置扫描。
                if (-not (Test-IsSafeMiningExpansionDir -Dir $dir)) { continue }

                if (-not $List.Contains($dir)) {
                    $List.Add($dir) | Out-Null
                }
            }
        }
    }
    catch {}
}

function Get-ShortContext {
    param(
        [string]$Text,
        [string]$Value
    )

    if ([string]::IsNullOrWhiteSpace($Text) -or [string]::IsNullOrWhiteSpace($Value)) {
        return ""
    }

    try {
        $idx = $Text.IndexOf($Value)
        if ($idx -lt 0) { return "" }
        $start = [Math]::Max(0, $idx - 60)
        $len = [Math]::Min(220, $Text.Length - $start)
        return ($Text.Substring($start, $len) -replace "`r|`n", " ")
    }
    catch { return "" }
}

function Add-MiningConfigHit {
    param(
        [System.Collections.Generic.List[object]]$List,
        [string]$Type,
        [string]$Value,
        [string]$FilePath,
        [string]$SourceDir,
        [string]$Context,
        [string]$Confidence
    )

    if ([string]::IsNullOrWhiteSpace($Value)) { return }
    $cleanValue = $Value.Trim().Trim('"', "'", ',', ';')
    if ([string]::IsNullOrWhiteSpace($cleanValue)) { return }

    # v0.8.3：localhost / 0.0.0.0 / 内网地址不进入挖矿或投放 URL 高危线索，避免 Acunetix/Nessus 等本地服务日志误报。
    if ($Type -match "矿池|钱包|下载/投放URL|IOC" -and (Test-IsLocalOrPrivateIocValue -Value $cleanValue)) { return }
    if ($cleanValue -match "(?i)^\d+\):\s*(GET|POST|PUT|DELETE|PATCH)\s+https?://(localhost|127\.0\.0\.1|0\.0\.0\.0)") { return }

    # 去重：同一个文件、同一值只保留一次，避免同一矿池同时以'矿池地址'和'矿池地址候选'重复出现。
    foreach ($x in $List) {
        if ($x.Value -eq $cleanValue -and $x.FilePath -eq $FilePath) {
            return
        }
    }

    $List.Add([PSCustomObject]@{
        Type       = $Type
        Value      = $cleanValue
        FilePath   = $FilePath
        SourceDir  = $SourceDir
        Confidence = $Confidence
        Context    = $Context
    }) | Out-Null
}


function Get-WinIRNormalizedIocValue {
    param([string]$Value)

    if ([string]::IsNullOrWhiteSpace($Value)) { return "" }
    $v = $Value.Trim().Trim('"', "'", ',', ';', ')', ']')

    # 去掉尾部路径中常见脚本/二进制下载文件名，仅用于归一化 host:port，不改变原始展示。
    try {
        if ($v -match '(?i)^(?:stratum\+(?:tcp|ssl)|ssl|tcp|http|https)://([^/\s"''<>;,]+)') {
            return $Matches[1].ToLower()
        }
        if ($v -match '(?i)^([a-z0-9][a-z0-9._-]+\.[a-z0-9.-]+:[0-9]{2,5})$') {
            return $Matches[1].ToLower()
        }
    } catch {}

    return $v.ToLower()
}

function Get-WinIRIocType {
    param(
        [string]$Value,
        [string]$Context
    )

    $v = Safe-String $Value
    $ctx = Safe-String $Context

    if ($v -match '(?i)^https?://') {
        # http(s) 默认不作为矿池，作为下载/投放 URL。后续如出现真实矿池 API，可人工研判。
        return "下载/投放URL候选"
    }

    if ($v -match '(?i)^stratum\+') { return "矿池地址" }

    if ($v -match '(?i)^(ssl|tcp)://') { return "矿池地址候选" }

    if ($ctx -match '(?i)downloadstring|downloadfile|certutil|bitsadmin|urlcache|curl|wget|invoke-webrequest|iwr|http://' -and
        $v -match '(?i)\.(exe|dll|ps1|bat|cmd|vbs|hta|js|jse|scr)(\b|$)') {
        return "下载/投放URL候选"
    }

    if ($v -match '(?i)pool|xmr|miner|relay|gateway|node|cdn|cache|sync|:[0-9]{2,5}') {
        return "矿池地址候选"
    }

    return "IOC候选"
}

function Add-WinIRIocHit {
    param(
        [System.Collections.Generic.List[object]]$List,
        [string]$Value,
        [string]$FilePath,
        [string]$SourceDir,
        [string]$Context,
        [string]$Confidence
    )

    if (Test-IsLocalOrPrivateIocValue -Value $Value) { return }
    $typ = Get-WinIRIocType -Value $Value -Context $Context

    # http(s) URL 如果没有真实下载或矿池上下文，仅作为普通本地服务/应用日志，不进入此表。
    if ($typ -match '下载/投放URL|矿池|IOC' -and -not (Test-IsProbablyMiningIoc -Type $typ -Value $Value -Context $Context) -and $Value -notmatch '(?i)\.(exe|dll|ps1|bat|cmd|vbs|hta|js|jse|scr)(\b|$)') {
        return
    }

    Add-MiningConfigHit -List $List -Type $typ -Value $Value -FilePath $FilePath -SourceDir $SourceDir -Context (Limit-TextForReport -Text $Context -MaxLength 260) -Confidence $Confidence
}


function Add-MiningHitsFromText {
    param(
        [System.Collections.Generic.List[object]]$List,
        [string]$Text,
        [string]$FilePath,
        [string]$SourceDir
    )

    if ([string]::IsNullOrWhiteSpace($Text)) { return }

    # v0.6.4：更通用的矿池/钱包/矿工标识提取。
    # 目的：覆盖 ssl://、tcp://、http(s)://、key=value、.ini、.db、.bak、无扩展配置、ADS 等边缘情况。
    # 注意：该函数只在候选目录内执行，不做全盘扫描，降低误报与性能风险。

    foreach ($m in [regex]::Matches($Text, '(?i)\b((?:stratum\+(?:tcp|ssl)|ssl|tcp|http|https)://[a-z0-9][a-z0-9._-]+(?::[0-9]{2,5})?(?:/[^\s"''<>;,)]*)?)')) {
        $v = $m.Groups[1].Value.Trim().Trim('"', "'", ',', ';', ')', ']')
        if ([string]::IsNullOrWhiteSpace($v)) { continue }

        # http(s) 太容易误报，localhost/内网/0.0.0.0 直接跳过；公网 URL 必须带下载文件或矿池/钱包/矿工上下文。
        if (Test-IsLocalOrPrivateIocValue -Value $v) { continue }
        if ($v -match '(?i)^https?://' -and $v -notmatch '(?i)pool|xmr|miner|stratum|wallet|worker|lab\.invalid|\.(exe|dll|ps1|bat|cmd|vbs|hta|js|jse|scr)(\b|$)') {
            continue
        }

        $ctx = Get-ShortContext -Text $Text -Value $v
        $confidence = if ($v -match '(?i)^stratum\+|lab\.invalid|pool|xmr|miner|relay|gateway|node|:[0-9]{2,5}|\.(exe|dll|ps1|bat|cmd|vbs|hta|js)$') { "高" } else { "中" }

        Add-WinIRIocHit -List $List -Value $v -FilePath $FilePath -SourceDir $SourceDir -Context $ctx -Confidence $confidence
    }

    # key=value / key: value / JSON 字段。覆盖 pool_primary、pool_backup、endpoint、fallback、remote、mirror_endpoint 等。
    foreach ($m in [regex]::Matches($Text, '(?im)(?:"?(pool(?:_[a-z0-9-]+)?|url|endpoint|fallback|remote|primary|backup|server|host|proxy|mirror_endpoint)"?\s*[:=]\s*"?)([^"''#;\r\n,]+)')) {
        $v = $m.Groups[2].Value.Trim().Trim('"', "'", ',', ';')
        if ([string]::IsNullOrWhiteSpace($v)) { continue }

        if (Test-IsLocalOrPrivateIocValue -Value $v) { continue }
        if ($v -match '(?i)stratum|ssl://|tcp://|pool|xmr|miner|wallet|worker|lab\.invalid|\.(exe|dll|ps1|bat|cmd|vbs|hta|js)(\b|$)') {
            $ctx = Get-ShortContext -Text $Text -Value $v
            $confidence = if ($v -match '(?i)^stratum\+|ssl://|tcp://|pool|lab\.invalid|\.(exe|dll|ps1|bat|cmd|vbs|hta|js)$') { "高" } else { "中" }
            Add-WinIRIocHit -List $List -Value $v -FilePath $FilePath -SourceDir $SourceDir -Context $ctx -Confidence $confidence
        }
    }

    # 兜底 host:port：只在候选目录内抓取带 pool/xmr/relay/gateway/node/cdn/cache/sync 等上下文的 host:port。
    foreach ($m in [regex]::Matches($Text, '(?i)\b([a-z0-9][a-z0-9._-]*(?:pool|xmr|miner|relay|gateway|node|cdn|cache|sync)[a-z0-9._-]*\.[a-z0-9.-]+:[0-9]{2,5})\b')) {
        $v = $m.Groups[1].Value.Trim().Trim('"', "'", ',', ';', ')', ']')
        Add-MiningConfigHit -List $List -Type "矿池地址候选" -Value $v -FilePath $FilePath -SourceDir $SourceDir -Context (Get-ShortContext -Text $Text -Value $v) -Confidence "中"
    }

    # 钱包/矿工账号/Token 候选。真实 XMR 钱包仍由原有高置信规则处理，这里补足实验/配置中的长标识。
    foreach ($m in [regex]::Matches($Text, '(?im)(?:"?(user|wallet|account|worker|worker_id|mirror_wallet|token)"?\s*[:=]\s*"?|--user\s+|-u\s+)([A-Za-z0-9_.+\-]{24,220})')) {
        $v = $m.Groups[2].Value.Trim().Trim('"', "'", ',', ';')
        if ([string]::IsNullOrWhiteSpace($v)) { continue }
        if ($v -match '^(true|false|null|none|default)$') { continue }

        $typ = "钱包地址候选"
        $conf = "中"
        if ($v -match '^[48][0-9AB][1-9A-HJ-NP-Za-km-z]{93}$') { $typ = "钱包地址"; $conf = "高" }

        Add-MiningConfigHit -List $List -Type $typ -Value $v -FilePath $FilePath -SourceDir $SourceDir -Context (Get-ShortContext -Text $Text -Value $v) -Confidence $conf
    }
}



function Test-IsSafeMiningExpansionDir {
    param([string]$Dir)

    if ([string]::IsNullOrWhiteSpace($Dir)) { return $false }

    try {
        $d = $Dir.Trim().TrimEnd('\')
        if ([string]::IsNullOrWhiteSpace($d)) { return $false }

        # 不扫描过宽目录，避免全盘慢扫和误报
        $blockedExact = @(
            'C:',
            'C:\',
            'C:\Windows',
            'C:\Windows\System32',
            'C:\ProgramData',
            'C:\ProgramData\Microsoft',
            'C:\ProgramData\Microsoft\Windows',
            'C:\Program Files',
            'C:\Program Files (x86)',
            'C:\Users'
        )
        foreach ($b in $blockedExact) {
            if ($d.Equals($b, [System.StringComparison]::OrdinalIgnoreCase)) { return $false }
        }

        if ($d -match '(?i)^C:\\ProgramData\\Microsoft\\Windows Defender(\\|$)') { return $false }
        if ($d -match '(?i)^C:\\ProgramData\\Microsoft\\Windows\\Start Menu(\\|$)') { return $false }
        if ($d -match '^C:\\Users\\[^\\]+$') { return $false }
        if ($d -match '^C:\\Users\\[^\\]+\\AppData$') { return $false }
        if ($d -match '^C:\\Users\\[^\\]+\\AppData\\Local$') { return $false }
        if ($d -match '^C:\\Users\\[^\\]+\\AppData\\Roaming$') { return $false }
        if ($d -match '^C:\\Users\\[^\\]+\\AppData\\Local\\Microsoft$') { return $false }
        if ($d -match '^C:\\Users\\[^\\]+\\AppData\\Roaming\\Microsoft$') { return $false }

        # 允许 C:\ProgramData\某个具体子目录，例如 C:\ProgramData\WinIRLabV2
        if ($d -match '^C:\\ProgramData\\[^\\]+$') { return $true }

        # v0.6.4：允许 Public 下具体子目录作为候选镜像目录，但不允许 C:\Users\Public 根目录。
        if ($d -match '^C:\\Users\\Public\\[^\\]+$') { return $true }
        if ($d -match '^C:\\Users\\Public\\[^\\]+\\[^\\]+') { return $true }

        # v0.6.1：允许从可疑证据命中的 ProgramData 深层目录向上扩展到具体父目录，例如 Runtime/.telemetry -> UpdateHealth。
        # 仍然禁止 C:\ProgramData、C:\ProgramData\Microsoft 这类过宽目录。
        if ($d -match '^C:\\ProgramData\\[^\\]+\\[^\\]+') { return $true }

        # 允许 Public、Temp、Downloads 下的具体子目录
        if ($d -match '^C:\\Users\\Public\\[^\\]+$') { return $true }
        if ($d -match '^C:\\Windows\\Temp\\[^\\]+$') { return $true }
        if ($d -match '^C:\\Users\\[^\\]+\\Downloads\\[^\\]+$') { return $true }

        # 允许 AppData 下的非 Microsoft 具体应用目录，避免把 OneDrive/系统组件扩大扫描
        if ($d -match '^C:\\Users\\[^\\]+\\AppData\\(Local|Roaming)\\(?!Microsoft\\b)[^\\]+$') { return $true }

        return $false
    }
    catch { return $false }
}

function Test-IsSuspiciousPersistencePath {
    param([string]$PathOrCommand)

    if ([string]::IsNullOrWhiteSpace($PathOrCommand)) { return $false }
    $text = $PathOrCommand.Trim()

    # v0.8.3：先做已知安全工具/厂商路径降噪，避免 ProgramData 目录一刀切误报。
    if (Test-IsPathUnderKnownGoodRoot -PathOrCommand $text) { return $false }

    # 脚本/LOLBin 执行链本身仍然需要关注。
    if ($text -match "(?i)\.(ps1|vbs|js|jse|wsf|scr|hta)\b|powershell(\.exe)?|wscript(\.exe)?|cscript(\.exe)?|mshta(\.exe)?|-enc|-encodedcommand|downloadstring|invoke-expression") {
        return $true
    }

    # 可写目录中的可执行/脚本文件才按路径升权；普通数据目录、数据库目录不直接当持久化后门。
    if ($text -match "(?i)\\Users\\[^\\]+\\AppData\\|\\Users\\Public\\|\\Windows\\Temp\\|\\Temp\\|\\Downloads\\") {
        return $true
    }
    if ($text -match "(?i)\\ProgramData\\" -and $text -match "(?i)\.(exe|dll|sys|bat|cmd|ps1|vbs|js|jse|wsf|scr|hta)\b") {
        return $true
    }

    return $false
}


function Format-FileSize {
    param([Int64]$Bytes)

    if ($Bytes -ge 1GB) { return ("{0:N2} GB" -f ($Bytes / 1GB)) }
    if ($Bytes -ge 1MB) { return ("{0:N2} MB" -f ($Bytes / 1MB)) }
    if ($Bytes -ge 1KB) { return ("{0:N2} KB" -f ($Bytes / 1KB)) }
    return "$Bytes B"
}

function Add-HashTarget {
    param(
        [System.Collections.Generic.List[string]]$Targets,
        [string]$InputPath
    )

    if ([string]::IsNullOrWhiteSpace($InputPath)) { return }

    $p = $InputPath.Trim().Trim('"', "'")
    if ([string]::IsNullOrWhiteSpace($p)) { return }

    try {
        $resolvedItems = @(Resolve-Path -Path $p -ErrorAction Stop)
        foreach ($ri in $resolvedItems) {
            $full = $ri.Path
            if (Test-Path $full -PathType Leaf) {
                if (-not $Targets.Contains($full)) { $Targets.Add($full) | Out-Null }
            }
        }
    }
    catch {
        Write-Warn "Hash 目标不存在或无法访问：$InputPath"
    }
}

function Invoke-HashCalculator {
    Write-Info "进入独立文件 Hash 计算模式..."

    Ensure-OutputDir

    $targets = New-Object System.Collections.Generic.List[string]

    foreach ($hf in $HashFile) {
        if ([string]::IsNullOrWhiteSpace($hf)) { continue }

        # 支持用户用分号分隔多个路径，也支持拖入带引号路径。
        foreach ($part in ($hf -split ';')) {
            Add-HashTarget -Targets $targets -InputPath $part
        }
    }

    if (-not [string]::IsNullOrWhiteSpace($HashFolder)) {
        $folder = $HashFolder.Trim().Trim('"', "'")
        if (Test-Path $folder -PathType Container) {
            try {
                $gciParams = @{
                    Path        = $folder
                    File        = $true
                    ErrorAction = 'SilentlyContinue'
                }
                if ($HashRecurse) { $gciParams['Recurse'] = $true }

                foreach ($f in (Get-ChildItem @gciParams)) {
                    if (-not $targets.Contains($f.FullName)) { $targets.Add($f.FullName) | Out-Null }
                }
            }
            catch {
                Write-Warn "读取目录失败：$folder"
            }
        }
        else {
            Write-Warn "HashFolder 不是有效目录：$HashFolder"
        }
    }

    if ($HashOnly -and $targets.Count -eq 0) {
        Write-Host ""
        Write-Host "请粘贴或拖入要计算 Hash 的文件路径。" -ForegroundColor Cyan
        Write-Host "多个文件可以用英文分号 ; 分隔。直接回车结束。" -ForegroundColor DarkCyan
        $line = Read-Host "文件路径"
        if (-not [string]::IsNullOrWhiteSpace($line)) {
            foreach ($part in ($line -split ';')) {
                Add-HashTarget -Targets $targets -InputPath $part
            }
        }
    }

    if ($targets.Count -eq 0) {
        Write-Warn "未提供任何有效文件，Hash 计算结束。"
        return
    }

    $results = New-Object System.Collections.Generic.List[object]

    foreach ($file in $targets) {
        try {
            $item = Get-Item -Path $file -ErrorAction Stop
            foreach ($algo in $HashAlgorithm) {
                try {
                    $hash = (Get-FileHash -Path $item.FullName -Algorithm $algo -ErrorAction Stop).Hash
                    $results.Add([PSCustomObject]@{
                        FileName      = $item.Name
                        FullPath      = $item.FullName
                        SizeBytes     = $item.Length
                        SizeReadable  = Format-FileSize -Bytes $item.Length
                        CreationTime  = $item.CreationTime
                        LastWriteTime = $item.LastWriteTime
                        Algorithm     = $algo
                        HashUpper     = $hash.ToUpper()
                        HashLower     = $hash.ToLower()
                    }) | Out-Null
                }
                catch {
                    Write-Warn "计算失败：$($item.FullName) / $algo"
                }
            }
        }
        catch {
            Write-Warn "无法读取文件：$file"
        }
    }

    if ($results.Count -eq 0) {
        Write-Warn "没有成功生成 Hash 结果。"
        return
    }

    $csvPath = Join-Path $script:OutputDir "文件Hash计算结果.csv"
    $txtPath = Join-Path $script:OutputDir "文件Hash计算结果.txt"

    try {
        $results | Export-Csv -Path $csvPath -NoTypeInformation -Encoding UTF8
    }
    catch {
        Write-Warn "导出 CSV 失败：$csvPath"
    }

    try {
        $lines = New-Object System.Collections.Generic.List[string]
        $lines.Add("WinIR-Helper $Version 文件 Hash 计算结果") | Out-Null
        $lines.Add("生成时间：$(Get-Date)") | Out-Null
        $lines.Add("文件数量：$($targets.Count)") | Out-Null
        $lines.Add("") | Out-Null

        foreach ($r in $results) {
            $lines.Add("文件名：$($r.FileName)") | Out-Null
            $lines.Add("路径：$($r.FullPath)") | Out-Null
            $lines.Add("大小：$($r.SizeReadable) ($($r.SizeBytes) bytes)") | Out-Null
            $lines.Add("算法：$($r.Algorithm)") | Out-Null
            $lines.Add("Hash 大写：$($r.HashUpper)") | Out-Null
            $lines.Add("hash 小写：$($r.HashLower)") | Out-Null
            $lines.Add("创建时间：$($r.CreationTime)") | Out-Null
            $lines.Add("修改时间：$($r.LastWriteTime)") | Out-Null
            $lines.Add("-" * 80) | Out-Null
        }

        $lines | Out-File -FilePath $txtPath -Encoding UTF8
    }
    catch {
        Write-Warn "导出 TXT 失败：$txtPath"
    }

    Write-Host ""
    Write-Ok "Hash 计算完成。"
    Write-Host "CSV：$csvPath"
    Write-Host "TXT：$txtPath"
    Write-Host ""
    $results | Format-Table FileName, Algorithm, SizeReadable, HashUpper -AutoSize
}


