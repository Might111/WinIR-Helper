﻿# WinIR-Helper v0.8.8-beta module: 26-Analyze-MiningConfig.ps1
# This module is dot-sourced by WinIR-Helper.ps1.

# 模块 7：挖矿配置提取
# =========================================================

Write-Info "正在提取挖矿配置文件中的矿池和钱包线索..."

$MiningCandidateDirs = New-Object System.Collections.Generic.List[string]

# 1. 从已经命中的资源异常/服务/计划任务/启动项中提取目录
#    v0.5.2 关键改进：不再只信 xmrig/miner 等关键词。
#    只要进程、服务、计划任务或启动项已经被判为可疑，就将其所在目录加入轻量扫描队列，
#    再从目录内提取 stratum / pool / wallet / user 等配置证据。
$MiningCandidateSources = New-Object System.Collections.Generic.List[object]

function Add-MiningCandidateFromEvidence {
    param(
        [string]$SourceType,
        [string]$EvidenceName,
        [string]$Value,
        [string]$Reason
    )

    if ([string]::IsNullOrWhiteSpace($Value)) { return }

    $beforeCount = $MiningCandidateDirs.Count
    Add-MiningCandidateDir -List $MiningCandidateDirs -Value $Value
    $afterCount = $MiningCandidateDirs.Count

    $MiningCandidateSources.Add([PSCustomObject]@{
        SourceType   = $SourceType
        EvidenceName = $EvidenceName
        Value        = $Value
        Reason       = $Reason
        AddedDir     = if ($afterCount -gt $beforeCount) { "Yes" } else { "MaybeExistingOrInvalid" }
    }) | Out-Null
}

foreach ($r in $ResourceAnomalies) {
    $resourceText = "$($r.Name) $($r.ExecutablePath) $($r.CommandLine) $($r.Tags)"
    $shouldTrace = $false
    $traceReason = @()

    if ($resourceText -match "(?i)xmrig|miner|c3pool|monero|stratum|WinRing0|nssm") { $shouldTrace = $true; $traceReason += "命中挖矿/驱动/服务特征" }
    if ($r.Score -ge 4 -and $r.ExecutablePath -match $SuspiciousPathRegex) { $shouldTrace = $true; $traceReason += "资源异常且位于可疑目录" }
    if ($r.CpuPercent -ge $CpuHighPercent -and $r.ExecutablePath -match $SuspiciousPathRegex) { $shouldTrace = $true; $traceReason += "高 CPU 且位于可疑目录" }
    if ($r.PublicConnections -ge 1 -and $r.ExecutablePath -match $SuspiciousPathRegex) { $shouldTrace = $true; $traceReason += "可疑目录进程存在公网连接" }
    if ($r.CommandLine -match "(?i)--config\s+|\s-c\s+|/config\s+|config\.json|\.conf\b") { $shouldTrace = $true; $traceReason += "命令行疑似指定配置文件" }

    if ($shouldTrace) {
        Add-MiningCandidateFromEvidence -SourceType "资源异常进程" -EvidenceName $r.Name -Value $r.ExecutablePath -Reason ($traceReason -join ";")
        Add-MiningCandidateFromEvidence -SourceType "资源异常进程命令行" -EvidenceName $r.Name -Value $r.CommandLine -Reason ($traceReason -join ";")
    }
}

foreach ($s in $ServiceEvents) {
    if ($s.Level -eq "正常") { continue }
    $serviceText = "$($s.ServiceName) $($s.ImagePath) $($s.Reason)"
    $shouldTrace = $false
    $traceReason = @()

    if ($serviceText -match "(?i)xmrig|miner|c3pool|monero|stratum|WinRing0|nssm") { $shouldTrace = $true; $traceReason += "服务命中挖矿/驱动/持久化特征" }
    if (Test-IsSuspiciousPersistencePath -PathOrCommand $s.ImagePath) { $shouldTrace = $true; $traceReason += "服务路径位于可疑目录" }
    if ($s.Reason -match "可疑路径|用户目录|临时目录|挖矿|持久化") { $shouldTrace = $true; $traceReason += "服务安装原因可疑" }
    if ($s.ImagePath -match "(?i)--config\s+|\s-c\s+|/config\s+|config\.json|\.conf\b") { $shouldTrace = $true; $traceReason += "服务命令疑似指定配置文件" }

    if ($shouldTrace) {
        Add-MiningCandidateFromEvidence -SourceType "服务安装" -EvidenceName $s.ServiceName -Value $s.ImagePath -Reason ($traceReason -join ";")
    }
}

foreach ($t in $SuspiciousTasks) {
    Add-MiningCandidateFromEvidence -SourceType "可疑计划任务" -EvidenceName $t.TaskName -Value $t.Actions -Reason $t.Reason
}

foreach ($s in $SuspiciousStartup) {
    Add-MiningCandidateFromEvidence -SourceType "可疑启动项" -EvidenceName $s.Name -Value $s.Command -Reason $s.Reason
}

# 对全部启动项做一次轻量补充：如果持久化命令本身位于可疑目录，但由于签名/厂商规则没有进入重点关注，也加入候选目录池。
foreach ($s in $StartupItems) {
    if ((Test-IsSuspiciousPersistencePath -PathOrCommand $s.Command) -and (-not (Test-IsTrustedVendorCommand -Command $s.Command))) {
        Add-MiningCandidateFromEvidence -SourceType "启动项补充" -EvidenceName $s.Name -Value $s.Command -Reason "启动项命令位于可疑目录，加入配置扫描候选"
    }
}


# 1.5. 候选目录向上轻量扩展：
# 如果命中的是 C:\ProgramData\WinIRLabV2\Runtime 这类子目录，配置文件可能放在兄弟目录 Cache / Conf / Logs 中。
# 因此只在安全边界内补充父目录，例如 C:\ProgramData\WinIRLabV2；禁止补充 C:\ProgramData、C:\Windows 等过宽目录。
try {
    $currentDirs = @($MiningCandidateDirs)
    foreach ($dir in $currentDirs) {
        if ([string]::IsNullOrWhiteSpace($dir)) { continue }
        if (-not (Test-Path $dir -PathType Container)) { continue }

        $parent = Split-Path -Path $dir -Parent
        if ((Test-IsSafeMiningExpansionDir -Dir $parent) -and (Test-Path $parent -PathType Container)) {
            if (-not $MiningCandidateDirs.Contains($parent)) {
                $MiningCandidateDirs.Add($parent) | Out-Null
                $MiningCandidateSources.Add([PSCustomObject]@{
                    SourceType   = "候选父目录补充"
                    EvidenceName = (Split-Path -Path $dir -Leaf)
                    Value        = $dir
                    Reason       = "可疑文件位于子目录，补充扫描安全范围内父目录以发现兄弟目录中的配置/日志"
                    AddedDir     = "Yes"
                }) | Out-Null
            }
        }
    }
}
catch {}


# 1.6. 兄弟目录定向补充：
# 如果只命中 Runtime 或 .telemetry，配置常在同级 Cache/Config/Conf/Data/Logs 中。
# 这里仅补充少量高价值目录名，不做全盘搜索。
try {
    $siblingNames = @('Cache','Config','Conf','Configs','Data','Logs','Log','Profile','Profiles','Runtime','Scripts','.telemetry')
    $baseDirsForSibling = @($MiningCandidateDirs)
    foreach ($dir in $baseDirsForSibling) {
        if ([string]::IsNullOrWhiteSpace($dir)) { continue }
        if (-not (Test-Path $dir -PathType Container)) { continue }

        $parent = Split-Path -Path $dir -Parent
        if (-not (Test-IsSafeMiningExpansionDir -Dir $parent)) { continue }

        foreach ($sn in $siblingNames) {
            $sib = Join-Path $parent $sn
            if ((Test-Path $sib -PathType Container) -and (-not $MiningCandidateDirs.Contains($sib))) {
                $MiningCandidateDirs.Add($sib) | Out-Null
                $MiningCandidateSources.Add([PSCustomObject]@{
                    SourceType   = "候选兄弟目录补充"
                    EvidenceName = $sn
                    Value        = $sib
                    Reason       = "可疑目录存在同级高价值配置目录，补充扫描以发现隐藏配置/日志"
                    AddedDir     = "Yes"
                }) | Out-Null
            }
        }
    }
}
catch {}

# 2. 补充常见挖矿目录候选，不做大范围全盘扫描，避免太慢
try {
    $commonRoots = @("C:\Users", "C:\ProgramData", "C:\Windows\Temp")
    foreach ($root in $commonRoots) {
        if (Test-Path $root -PathType Container) {
            Get-ChildItem -Path $root -Directory -Force -ErrorAction SilentlyContinue | ForEach-Object {
                if ($_.Name -match "(?i)c3pool|xmrig|miner|xmr|monero") {
                    if (-not $MiningCandidateDirs.Contains($_.FullName)) {
                        $MiningCandidateDirs.Add($_.FullName) | Out-Null
                    }
                    $MiningCandidateSources.Add([PSCustomObject]@{
                        SourceType   = "常见挖矿目录名"
                        EvidenceName = $_.Name
                        Value        = $_.FullName
                        Reason       = "目录名命中挖矿关键词"
                        AddedDir     = "Yes"
                    }) | Out-Null
                }
            }
        }
    }
}
catch {}

# v0.6.4：补充 Public/Libraries 下的可疑镜像目录。
# 不扫描整个 Public，只挑选目录名带 WinIRLab/miner/xmr/cache/update/runtime 等可疑上下文的具体目录。
try {
    $publicRoots = @("C:\Users\Public", "C:\Users\Public\Libraries", "C:\Users\Public\Documents")
    foreach ($root in $publicRoots) {
        if (Test-Path $root -PathType Container) {
            Get-ChildItem -Path $root -Directory -Force -ErrorAction SilentlyContinue | ForEach-Object {
                if ($_.Name -match "(?i)winirlab|xmrig|miner|xmr|monero|cache|update|runtime|telemetry") {
                    if (Test-IsSafeMiningExpansionDir -Dir $_.FullName) {
                        if (-not $MiningCandidateDirs.Contains($_.FullName)) {
                            $MiningCandidateDirs.Add($_.FullName) | Out-Null
                        }
                        $MiningCandidateSources.Add([PSCustomObject]@{
                            SourceType   = "Public可疑镜像目录"
                            EvidenceName = $_.Name
                            Value        = $_.FullName
                            Reason       = "Public/Libraries 下目录名带可疑缓存/挖矿上下文，加入轻量配置扫描"
                            AddedDir     = "Yes"
                        }) | Out-Null
                    }
                }
            }
        }
    }
}
catch {}

$MiningConfigs = New-Object System.Collections.Generic.List[object]
$MiningConfigFiles = @()
# v0.6.6：ADS 备用数据流显式结果。即使 IOC 与普通文件重复，也单独导出并进入关注项。
$AdsFindings = @()
$MiningTextExt = @(".json", ".conf", ".config", ".txt", ".bat", ".cmd", ".ps1", ".ini", ".yml", ".yaml", ".xml")

foreach ($dir in $MiningCandidateDirs) {
    if (-not (Test-Path $dir -PathType Container)) { continue }
    if (Test-IsPathUnderKnownGoodRoot -PathOrCommand $dir) { continue }

    try {
        $files = Get-ChildItem -Path $dir -Recurse -File -Force -ErrorAction SilentlyContinue |
            Where-Object {
                $ext = $_.Extension.ToLower()
                $full = $_.FullName
                $isKnownGoodPath = Test-IsPathUnderKnownGoodRoot -PathOrCommand $full
                $isNoisePath = ($full -match '(?i)\\db\\base\\|\\db\\global\\|\\ProgramData\\Acunetix\\db\\|\\Logs?\\')
                (-not $isKnownGoodPath) -and (-not $isNoisePath) -and $_.Length -gt 0 -and $_.Length -lt 2MB -and (
                    ($MiningTextExt -contains $ext) -or
                    $_.Name -match '(?i)config|profile|route|policy|wallet|pool|worker|endpoint'
                )
            } |
            Sort-Object @{Expression={ if ($_.Name -match '(?i)config|runtime|profile|pool|wallet|fallback|remote|log') { 0 } else { 1 } }}, LastWriteTime -Descending |
            Select-Object -First 160

        foreach ($f in $files) {
            $MiningConfigFiles += [PSCustomObject]@{
                SourceDir     = $dir
                FilePath      = $f.FullName
                Length        = $f.Length
                LastWriteTime = $f.LastWriteTime
            }

            $content = ""
            try { $content = Get-Content -Path $f.FullName -Raw -ErrorAction Stop } catch { continue }
            if ([string]::IsNullOrWhiteSpace($content)) { continue }

            # v0.6.4：先做通用协议/字段扫描，再走原有高置信专项规则。
            Add-MiningHitsFromText -List $MiningConfigs -Text $content -FilePath $f.FullName -SourceDir $dir

            # v0.6.6：轻量扫描 NTFS Alternate Data Stream（ADS），并显式输出 ADS 证据。
            # 只扫描已经进入候选文件列表的小文件，避免全盘 ADS 扫描造成性能和误报问题。
            try {
                $streams = Get-Item -Path $f.FullName -Stream * -ErrorAction SilentlyContinue |
                    Where-Object { $_.Stream -and $_.Length -gt 0 -and $_.Length -lt 2MB }

                foreach ($st in $streams) {
                    $streamName = [string]$st.Stream
                    if ([string]::IsNullOrWhiteSpace($streamName)) { continue }

                    if ($streamName -eq '$DATA' -or $streamName -eq ':$DATA') { continue }
                    $streamNameClean = ($streamName -replace ':\$DATA$','')
                    if ([string]::IsNullOrWhiteSpace($streamNameClean) -or $streamNameClean -eq '$DATA') { continue }

                    $adsContent = ""
                    try { $adsContent = Get-Content -Path $f.FullName -Stream $streamNameClean -Raw -ErrorAction Stop } catch { $adsContent = "" }

                    if (-not [string]::IsNullOrWhiteSpace($adsContent)) {
                        $adsPath = "$($f.FullName):$streamNameClean"
                        $adsFlat = ($adsContent -replace '\s+', ' ')
                        $adsLooksInteresting = $adsFlat -match '(?i)stratum|ssl://|tcp://|https?://|wallet|worker|token|pool|relay|gateway|node|lab\.invalid|fake_src_ip|source_ip'

                        $MiningConfigFiles += [PSCustomObject]@{
                            SourceDir     = $dir
                            FilePath      = $adsPath
                            Length        = $st.Length
                            LastWriteTime = $f.LastWriteTime
                        }

                        Add-MiningHitsFromText -List $MiningConfigs -Text $adsContent -FilePath $adsPath -SourceDir $dir

                        if ($adsLooksInteresting) {
                            $AdsFindings += [PSCustomObject]@{
                                HostFile      = $f.FullName
                                StreamName    = $streamNameClean
                                AdsPath       = $adsPath
                                Length        = $st.Length
                                LastWriteTime = $f.LastWriteTime
                                SourceDir     = $dir
                                Context       = $adsFlat.Substring(0, [Math]::Min(260, $adsFlat.Length))
                                Note          = "候选目录文件存在 ADS 备用数据流，且流内容命中 IOC/认证/配置上下文关键词"
                            }
                        }
                    }
                }
            } catch {}

            # 如果脚本/批处理里引用了同一安全父目录下的配置/日志文件，补充读取该文件。
            # 这用于识别：服务/计划任务 -> loader.ps1 -> Cache\runtime-profile.json 这种真实常见布局。
            try {
                foreach ($pm in [regex]::Matches($content, '[A-Za-z]:\\[^"''<>|\r\n]+\.(json|conf|config|txt|log|ini|yml|yaml|xml|ps1|bat|cmd|db|bak|dat)')) {
                    $refPath = $pm.Value.Trim().Trim('"', "'", ',', ';')
                    if ((Test-Path $refPath -PathType Leaf)) {
                        $refFile = Get-Item -Path $refPath -ErrorAction SilentlyContinue
                        if ($null -ne $refFile -and $refFile.Length -gt 0 -and $refFile.Length -lt 2MB -and (-not (Test-IsPathUnderKnownGoodRoot -PathOrCommand $refFile.FullName)) -and ($MiningTextExt -contains $refFile.Extension.ToLower())) {
                            $refDir = Split-Path -Path $refFile.FullName -Parent
                            $sameSafeParent = $false
                            try {
                                $parentA = Split-Path -Path $dir -Parent
                                $parentB = Split-Path -Path $refDir -Parent
                                if ($parentA -eq $parentB -or $dir -eq $parentB -or $refDir.StartsWith($dir, [System.StringComparison]::OrdinalIgnoreCase)) { $sameSafeParent = $true }
                                if (Test-IsSafeMiningExpansionDir -Dir $parentB) { $sameSafeParent = $true }
                            } catch {}

                            if ($sameSafeParent) {
                                $MiningConfigFiles += [PSCustomObject]@{
                                    SourceDir     = $dir
                                    FilePath      = $refFile.FullName
                                    Length        = $refFile.Length
                                    LastWriteTime = $refFile.LastWriteTime
                                }

                                $refContent = ""
                                try { $refContent = Get-Content -Path $refFile.FullName -Raw -ErrorAction Stop } catch { $refContent = "" }
                                if (-not [string]::IsNullOrWhiteSpace($refContent)) {
                                    Add-MiningHitsFromText -List $MiningConfigs -Text $refContent -FilePath $refFile.FullName -SourceDir $refDir

                                    foreach ($sm in [regex]::Matches($refContent, '(?i)stratum\+(tcp|ssl)://[^\s"''<>]+')) {
                                        Add-MiningConfigHit -List $MiningConfigs -Type "矿池地址" -Value $sm.Value -FilePath $refFile.FullName -SourceDir $refDir -Context (Get-ShortContext -Text $refContent -Value $sm.Value) -Confidence "高"
                                    }
                                    foreach ($um in [regex]::Matches($refContent, '(?i)"(url|endpoint|fallback|remote)"\s*:\s*"([^"]+)"|(?im)^\s*(endpoint|fallback|remote)\s*=\s*([^\r\n#]+)')) {
                                        $v = if ($um.Groups[2].Success) { $um.Groups[2].Value } else { $um.Groups[4].Value }
                                        $v = $v.Trim().Trim('"', "'", ',', ';')
                                        if ($v -match '(?i)stratum|pool|relay|gateway|:[0-9]{2,5}') {
                                            Add-MiningConfigHit -List $MiningConfigs -Type "矿池地址候选" -Value $v -FilePath $refFile.FullName -SourceDir $refDir -Context (Get-ShortContext -Text $refContent -Value $v) -Confidence "中"
                                        }
                                    }
                                    foreach ($wm in [regex]::Matches($refContent, '(?i)("user"\s*:\s*"|"wallet"\s*:\s*"|"account"\s*:\s*"|account\s*=\s*|wallet\s*=\s*|token\s*=\s*)([A-Za-z0-9_.+\-]{32,180})')) {
                                        $wv = $wm.Groups[2].Value.Trim().Trim('"', "'", ',', ';')
                                        if ($wv -notmatch '^(true|false|null)$') {
                                            Add-MiningConfigHit -List $MiningConfigs -Type "钱包地址候选" -Value $wv -FilePath $refFile.FullName -SourceDir $refDir -Context (Get-ShortContext -Text $refContent -Value $wv) -Confidence "中"
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch {}

            # 矿池地址：stratum 协议最可靠
            foreach ($m in [regex]::Matches($content, '(?i)stratum\+(tcp|ssl)://[^\s"''<>]+')) {
                Add-MiningConfigHit -List $MiningConfigs -Type "矿池地址" -Value $m.Value -FilePath $f.FullName -SourceDir $dir -Context (Get-ShortContext -Text $content -Value $m.Value) -Confidence "高"
            }

            # JSON / 配置中的 url / endpoint / fallback / remote 字段
            foreach ($m in [regex]::Matches($content, '(?i)"(url|endpoint|fallback|remote)"\s*:\s*"([^"]+)"')) {
                $v = $m.Groups[2].Value
                if ($v -match '(?i)stratum|pool|relay|gateway|:[0-9]{2,5}') {
                    $hitType = if ($v -match '(?i)^stratum\+') { "矿池地址" } else { "矿池地址候选" }
                    Add-MiningConfigHit -List $MiningConfigs -Type $hitType -Value $v -FilePath $f.FullName -SourceDir $dir -Context (Get-ShortContext -Text $content -Value $v) -Confidence "高"
                }
            }

            # 命令行 -o / --url 指定矿池
            foreach ($m in [regex]::Matches($content, '(?i)(--url|-o)\s+([^\s"'']+)')) {
                $v = $m.Groups[2].Value
                if ($v -match '(?i)stratum|pool|:[0-9]{2,5}') {
                    Add-MiningConfigHit -List $MiningConfigs -Type "矿池地址" -Value $v -FilePath $f.FullName -SourceDir $dir -Context (Get-ShortContext -Text $content -Value $v) -Confidence "高"
                }
            }

            # pool 域名/IP:端口 兜底提取
            foreach ($m in [regex]::Matches($content, '(?i)([a-z0-9.-]*pool[a-z0-9.-]*|[a-z0-9.-]*xmr[a-z0-9.-]*)\.[a-z]{2,}:[0-9]{2,5}')) {
                Add-MiningConfigHit -List $MiningConfigs -Type "矿池地址候选" -Value $m.Value -FilePath $f.FullName -SourceDir $dir -Context (Get-ShortContext -Text $content -Value $m.Value) -Confidence "中"
            }

            # XMR 钱包地址常见格式：95 个 Base58 字符，以 4 或 8 开头
            foreach ($m in [regex]::Matches($content, '\b[48][0-9AB][1-9A-HJ-NP-Za-km-z]{93}\b')) {
                Add-MiningConfigHit -List $MiningConfigs -Type "钱包地址" -Value $m.Value -FilePath $f.FullName -SourceDir $dir -Context (Get-ShortContext -Text $content -Value $m.Value) -Confidence "高"
            }

            # user / wallet / account / token / -u 后面的长字符串，作为钱包或矿工用户名候选
            foreach ($m in [regex]::Matches($content, '(?i)("user"\s*:\s*"|"wallet"\s*:\s*"|"account"\s*:\s*"|account\s*=\s*|wallet\s*=\s*|token\s*=\s*|--user\s+|-u\s+)([A-Za-z0-9_.+\-]{32,180})')) {
                $v = $m.Groups[2].Value
                if ($v -notmatch '^(true|false|null)$') {
                    $typ = "钱包地址候选"
                    $conf = "中"
                    if ($v -match '^[48][0-9AB][1-9A-HJ-NP-Za-km-z]{93}$') { $typ = "钱包地址"; $conf = "高" }
                    Add-MiningConfigHit -List $MiningConfigs -Type $typ -Value $v -FilePath $f.FullName -SourceDir $dir -Context (Get-ShortContext -Text $content -Value $v) -Confidence $conf
                }
            }
        }
    }
    catch {}
}

$MiningConfigsArrayRaw = @()
foreach ($mc in $MiningConfigs) {
    $MiningConfigsArrayRaw += $mc
}

# v0.6.5：IOC 归一化去重。
# 如果已经存在带协议的 ssl://host:port、tcp://host:port、stratum+tcp://host:port，
# 就不再重复展示同一 host:port 裸值；URL 下载项也从矿池中拆分出来。
$protocolHostPorts = New-Object 'System.Collections.Generic.HashSet[string]'
foreach ($mc in $MiningConfigsArrayRaw) {
    $norm = Get-WinIRNormalizedIocValue -Value $mc.Value
    if ($mc.Value -match '(?i)^(?:stratum\+(?:tcp|ssl)|ssl|tcp)://' -and -not [string]::IsNullOrWhiteSpace($norm)) {
        [void]$protocolHostPorts.Add($norm)
    }
}

$MiningConfigsArray = @()
foreach ($mc in $MiningConfigsArrayRaw) {
    $norm = Get-WinIRNormalizedIocValue -Value $mc.Value

    if ($mc.Value -notmatch '(?i)://' -and $protocolHostPorts.Contains($norm)) {
        continue
    }

    # http(s) 下载/投放 URL 不算矿池，但仍作为 IOC 输出。
    if ($mc.Value -match '(?i)^https?://' -and $mc.Type -match '矿池') {
        $mc.Type = "下载/投放URL候选"
    }

    $MiningConfigsArray += $mc
}

$MiningConfigsGroupedArray = @()
foreach ($g in ($MiningConfigsArray | Where-Object { $_.Value } | Group-Object Value)) {
    $items = @($g.Group)
    $first = $items | Select-Object -First 1
    $types = (($items.Type | Where-Object { $_ } | Sort-Object -Unique) -join ";")
    $sourceFiles = (($items.FilePath | Where-Object { $_ } | Sort-Object -Unique) -join "`n")
    $sourceDirs = (($items.SourceDir | Where-Object { $_ } | Sort-Object -Unique) -join "`n")
    $confidence = if (@($items | Where-Object { $_.Confidence -eq "高" }).Count -gt 0) { "高" } else { "中" }

    $MiningConfigsGroupedArray += [PSCustomObject]@{
        Type       = $types
        Value      = $g.Name
        Confidence = $confidence
        HitCount   = $items.Count
        SourceFiles = $sourceFiles
        SourceDirs  = $sourceDirs
        Context     = $first.Context
    }
}

$MiningCandidateSourcesArray = @()
foreach ($src in $MiningCandidateSources) { $MiningCandidateSourcesArray += $src }

Export-DetailCsv -Name "挖矿配置扫描目录来源.csv" -Data $MiningCandidateSourcesArray
Export-DetailCsv -Name "挖矿配置文件候选.csv" -Data $MiningConfigFiles
Export-DetailCsv -Name "挖矿配置提取.csv" -Data $MiningConfigsArray
Export-DetailCsv -Name "挖矿配置按Value聚合.csv" -Data $MiningConfigsGroupedArray
Export-DetailCsv -Name "ADS备用数据流线索.csv" -Data $AdsFindings

if ($AdsFindings.Count -gt 0) {
    $adsPreview = (($AdsFindings | Select-Object -First 5 | ForEach-Object { $_.AdsPath }) -join "`n")
    Add-Finding -Level "中危" -Category "ADS" -Title "候选目录中发现可疑 ADS 备用数据流" `
        -Evidence "ADS数量=$($AdsFindings.Count)，示例=$adsPreview" `
        -Suggestion "ADS 可能被用于隐藏配置或脚本片段。建议使用 Get-Item -Stream *、Get-Content -Stream、Sysinternals streams.exe 复核，并结合文件 Hash/时间线判断是否需要隔离。"
}

# v0.6.4：候选目录内的自定义认证失败日志关联。
# 真实 Windows Security 4625 的来源 IP 仍以系统日志为准；这里用于补充应用/代理/实验日志中的 src/client_ip/fake_src_ip 线索。
$CustomAuthLogHits = @()
try {
    foreach ($dir in $MiningCandidateDirs) {
        if (-not (Test-Path $dir -PathType Container)) { continue }
        if (Test-IsPathUnderKnownGoodRoot -PathOrCommand $dir) { continue }

        $logFiles = Get-ChildItem -Path $dir -Recurse -File -Force -ErrorAction SilentlyContinue |
            Where-Object { $_.Length -gt 0 -and $_.Length -lt 2MB -and (-not (Test-IsPathUnderKnownGoodRoot -PathOrCommand $_.FullName)) -and ($_.Extension.ToLower() -in @(".log",".txt",".conf",".ini")) } |
            Select-Object -First 80

        foreach ($lf in $logFiles) {
            $logText = ""
            try { $logText = Get-Content -Path $lf.FullName -Raw -ErrorAction Stop } catch { $logText = "" }
            if ([string]::IsNullOrWhiteSpace($logText)) { continue }
            if ($logText -notmatch "(?i)fail|failed|brute|auth|login|rdp|smb|4625") { continue }

            foreach ($m in [regex]::Matches($logText, '(?i)\b(?:fake_src_ip|src|source_ip|client_ip|remote_ip)\s*=\s*((?:\d{1,3}\.){3}\d{1,3})\b')) {
                $ip = $m.Groups[1].Value
                $CustomAuthLogHits += [PSCustomObject]@{
                    SourceFile = $lf.FullName
                    SourceDir  = $dir
                    SourceIP   = $ip
                    Context    = (Get-ShortContext -Text $logText -Value $ip)
                    Note       = "自定义/应用日志中的来源 IP 线索；需与 Windows Security 4625、网络设备或真实远程登录场景交叉验证"
                }
            }
        }
    }
} catch {}

Export-DetailCsv -Name "自定义认证日志IP线索.csv" -Data $CustomAuthLogHits

if ($CustomAuthLogHits.Count -gt 0) {
    $ipPreview = (($CustomAuthLogHits.SourceIP | Sort-Object -Unique | Select-Object -First 10) -join ";")
    Add-Finding -Level "关注" -Category "认证日志" -Title "候选目录中发现自定义认证失败来源 IP 线索" `
        -Evidence "IP线索=$ipPreview，命中文件数=$(@($CustomAuthLogHits.SourceFile | Sort-Object -Unique).Count)" `
        -Suggestion "这类 IP 来自应用/实验/代理日志，不等同于 Windows Security 4625 的真实 Source IP；请结合真实远程登录、网关、防火墙或双机测试验证。"
}

if ($MiningConfigsGroupedArray.Count -gt 0) {
    $confirmedConfigForFinding = @($MiningConfigsGroupedArray | Where-Object { Test-IsProbablyMiningIoc -Type $_.Type -Value $_.Value -Context $_.Context })
    $poolCount = @($confirmedConfigForFinding | Where-Object { $_.Type -match "矿池" }).Count
    $walletCount = @($confirmedConfigForFinding | Where-Object { $_.Type -match "钱包" }).Count
    $urlCount = @($MiningConfigsGroupedArray | Where-Object { $_.Type -match "下载/投放URL" -and -not (Test-IsLocalOrPrivateIocValue -Value $_.Value) }).Count

    if ($confirmedConfigForFinding.Count -gt 0) {
        Add-Finding -Level "高危" -Category "挖矿配置" -Title "发现矿池或钱包配置线索" `
            -Evidence "矿池线索=$poolCount，钱包线索=$walletCount，公网投放URL线索=$urlCount，候选目录=$($MiningCandidateDirs -join ';')" `
            -Suggestion "优先打开配置文件确认矿池地址、钱包地址和启动脚本；结合进程、服务、计划任务判断挖矿程序如何启动。"
    }
    elseif ($urlCount -gt 0) {
        Add-Finding -Level "关注" -Category "配置线索" -Title "发现公网下载或投放 URL 候选" `
            -Evidence "公网投放URL线索=$urlCount，候选目录=$($MiningCandidateDirs -join ';')" `
            -Suggestion "这类 URL 只是投放链路候选，不等同于挖矿配置；需结合脚本内容、文件 Hash 和执行链复核。"
    }
}

# =========================================================
