﻿# WinIR-Helper v0.8.8-beta module: 25-Collect-ProcessesNetwork.ps1
# This module is dot-sourced by WinIR-Helper.ps1.

# 模块 6：进程、网络、危险端口、资源异常
# =========================================================

Write-Info "正在检查进程、网络连接与资源异常..."
Write-Info "正在采样进程 CPU，占用约 $CpuSampleSeconds 秒..."

$CpuPercentMap = Get-ProcessCpuPercentMap -SampleSeconds $CpuSampleSeconds
$TotalMemoryMB = Get-TotalPhysicalMemoryMB

$MiningProcRegex = "(?i)xmrig|xmr-stak|monero|stratum|cryptonight|nanominer|cpuminer|minerd|miner|c3pool"
$SensitiveToolRegex = "(?i)^(powershell\.exe|pwsh\.exe|cmd\.exe|certutil\.exe|bitsadmin\.exe|mshta\.exe|rundll32\.exe|regsvr32\.exe|wscript\.exe|cscript\.exe|wmic\.exe|curl\.exe|wget\.exe|nc\.exe|ncat\.exe)$"

$Processes = @()
try {
    $cimProcs = Get-CimInstance Win32_Process -ErrorAction Stop
    foreach ($p in $cimProcs) {
        $path = Safe-String $p.ExecutablePath
        $cmd  = Safe-String $p.CommandLine
        $memMB = Get-ProcessMemoryMB -ProcessId $p.ProcessId
        $memPercent = 0
        if ($TotalMemoryMB -gt 0) { $memPercent = [Math]::Round(($memMB / $TotalMemoryMB) * 100, 2) }

        $cpuPercent = 0
        if ($CpuPercentMap.ContainsKey([int]$p.ProcessId)) { $cpuPercent = $CpuPercentMap[[int]$p.ProcessId] }

        $riskReasons = @()
        $cmdForTrust = "$path $cmd"
        $isTrustedVendorCmd = Test-IsTrustedVendorCommand -Command $cmdForTrust
        if ("$($p.Name) $path $cmd" -match $MiningProcRegex) { $riskReasons += "命中挖矿相关命名/路径/命令特征" }
        if ($cmd -match $DangerCommandRegex -and -not (Test-IsSelfToolText $cmd) -and -not $isTrustedVendorCmd) { $riskReasons += "命令行命中危险特征" }
        if ((Test-IsSuspiciousPersistencePath -PathOrCommand $path) -and -not (Test-IsPathUnderKnownGoodRoot -PathOrCommand $path) -and -not $isTrustedVendorCmd) { $riskReasons += "进程位于可疑路径" }
        if ($cpuPercent -ge $CpuHighPercent) { $riskReasons += "CPU占用异常" }
        if ($memMB -ge $MemoryHighMB -or $memPercent -ge $MemoryHighPercent) { $riskReasons += "内存占用异常" }

        $Processes += [PSCustomObject]@{
            ProcessId       = $p.ProcessId
            ParentProcessId = $p.ParentProcessId
            Name            = $p.Name
            ExecutablePath  = $path
            CommandLine     = $cmd
            CpuPercent      = $cpuPercent
            MemoryMB        = $memMB
            MemoryPercent   = $memPercent
            PublicConnections = 0
            SHA256          = Get-SHA256Safe -Path $path
            RiskReasons     = ($riskReasons -join ";")
        }
    }
}
catch {}

$NetConns = @()
try {
    $tcp = Get-NetTCPConnection -ErrorAction Stop | Where-Object { $_.State -in @("Established","Listen","SynSent","CloseWait") }

    foreach ($c in $tcp) {
        $proc = $Processes | Where-Object { $_.ProcessId -eq $c.OwningProcess } | Select-Object -First 1
        $remote = Safe-String $c.RemoteAddress
        $isPublic = $false

        if ($c.State -ne "Listen" -and $remote -and -not (Test-IsNonPublicIP $remote)) {
            $isPublic = $true
        }

        $NetConns += [PSCustomObject]@{
            LocalAddress  = $c.LocalAddress
            LocalPort     = $c.LocalPort
            RemoteAddress = $c.RemoteAddress
            RemotePort    = $c.RemotePort
            State         = $c.State
            ProcessId     = $c.OwningProcess
            ProcessName   = $proc.Name
            ProcessPath   = $proc.ExecutablePath
            IsPublicIP    = $isPublic
        }
    }
}
catch {}

$publicByPid = @{}
foreach ($n in ($NetConns | Where-Object { $_.IsPublicIP -eq $true })) {
    $procIdKey = [int]$n.ProcessId
    if (-not $publicByPid.ContainsKey($procIdKey)) { $publicByPid[$procIdKey] = 0 }
    $publicByPid[$procIdKey] += 1
}

$ResourceAnomalies = @()
foreach ($proc in $Processes) {
    $procIdKey = [int]$proc.ProcessId
    $publicCount = 0
    if ($publicByPid.ContainsKey($procIdKey)) { $publicCount = $publicByPid[$procIdKey] }
    $proc.PublicConnections = $publicCount

    $score = 0
    $tags = @()

    $isCoreWindowsProcess = Test-IsCoreWindowsProcess -Name $proc.Name -Path $proc.ExecutablePath
    $hasMiningFeature = ("$($proc.Name) $($proc.ExecutablePath) $($proc.CommandLine)" -match $MiningProcRegex)
    $isKnownPublicNoise = Test-IsKnownPublicNetworkNoise -ProcessName $proc.Name -ProcessPath $proc.ExecutablePath
    $isTrustedVendorCommand = Test-IsTrustedVendorCommand -Command "$($proc.ExecutablePath) $($proc.CommandLine)"
    $hasDangerCommand = ($proc.CommandLine -match $DangerCommandRegex -and -not (Test-IsSelfToolText $proc.CommandLine) -and -not $isTrustedVendorCommand)
    $hasSuspiciousPath = ((Test-IsSuspiciousPersistencePath -PathOrCommand $proc.ExecutablePath) -and -not (Test-IsPathUnderKnownGoodRoot -PathOrCommand $proc.ExecutablePath) -and -not $isTrustedVendorCommand)

    # v0.6.5：OneDrive / Edge / Defender 等常见组件如果只是 AppData 路径 + 公网连接，
    # 且没有资源压力、危险命令或挖矿特征，则不进入资源异常。
    if (($isKnownPublicNoise -or $isTrustedVendorCommand) -and
        -not ($hasMiningFeature -or $hasDangerCommand) -and
        $proc.CpuPercent -lt $CpuHighPercent -and
        $proc.MemoryMB -lt $MemoryHighMB -and
        $proc.MemoryPercent -lt $MemoryHighPercent) {
        continue
    }

    if ($proc.CpuPercent -ge 70) { $score += 4; $tags += "CPU占用极高" }
    elseif ($proc.CpuPercent -ge $CpuHighPercent) { $score += 2; $tags += "CPU占用偏高" }

    if ($proc.MemoryPercent -ge 40 -or $proc.MemoryMB -ge 2048) { $score += 3; $tags += "内存占用极高" }
    elseif ($proc.MemoryPercent -ge $MemoryHighPercent -or $proc.MemoryMB -ge $MemoryHighMB) { $score += 2; $tags += "内存占用偏高" }

    # 公网连接只作为辅助证据，不再单独触发资源异常。
    if ($publicCount -ge 20) { $score += 2; $tags += "公网连接很多" }
    elseif ($publicCount -ge 5 -and ($hasMiningFeature -or $hasDangerCommand -or $hasSuspiciousPath)) { $score += 1; $tags += "存在多个公网连接" }

    if ($hasSuspiciousPath) { $score += 2; $tags += "位于高风险目录" }
    if ($hasMiningFeature) { $score += 4; $tags += "命中挖矿命名/路径特征" }
    if ($hasDangerCommand) { $score += 2; $tags += "命令行可疑" }

    # 过滤低资源、系统核心进程、仅公网连接造成的噪音。
    $hasResourcePressure = ($proc.CpuPercent -ge $CpuHighPercent -or $proc.MemoryMB -ge $MemoryHighMB -or $proc.MemoryPercent -ge $MemoryHighPercent)
    $hasRealSuspiciousEvidence = ($hasMiningFeature -or $hasDangerCommand -or $hasSuspiciousPath -or $hasResourcePressure)

    if (-not $hasRealSuspiciousEvidence) { continue }
    if ($isCoreWindowsProcess -and -not ($hasResourcePressure -or $hasDangerCommand -or $hasMiningFeature)) { continue }
    if ($score -lt 3) { continue }

    $level = if ($score -ge 7) { "高危" } elseif ($score -ge 4) { "中危" } else { "关注" }
    $tagText = ($tags -join ";")
    $title = Get-ResourceTitle -Tags $tagText -RiskLevel $level

    $ResourceAnomalies += [PSCustomObject]@{
        Level             = $level
        Score             = $score
        ProcessId         = $proc.ProcessId
        Name              = $proc.Name
        CpuPercent        = $proc.CpuPercent
        MemoryMB          = $proc.MemoryMB
        MemoryPercent     = $proc.MemoryPercent
        PublicConnections = $publicCount
        Tags              = $tagText
        ExecutablePath    = $proc.ExecutablePath
        CommandLine       = $proc.CommandLine
        SHA256            = $proc.SHA256
    }

    Add-Finding -Level $level -Category "资源异常" -Title $title `
        -Evidence "PID=$($proc.ProcessId)，进程=$($proc.Name)，CPU=$($proc.CpuPercent)%，内存=$($proc.MemoryMB)MB($($proc.MemoryPercent)%)，公网连接=$publicCount，评分=$score，标签=$tagText，路径=$($proc.ExecutablePath)" `
        -Suggestion "资源异常不等于一定是挖矿。请结合 CPU/内存持续占用、外联地址、进程路径、计划任务/服务/启动项和文件 Hash 进行研判。"
}

$DangerPorts = @()
try {
    $listens = Get-NetTCPConnection -State Listen -ErrorAction SilentlyContinue

    $groups = $listens | Group-Object LocalPort
    foreach ($g in $groups) {
        $port = [int]$g.Name
        $info = Get-DangerousPortInfo -Port $port
        if (-not $info) { continue }

        $items = @($g.Group)
        $addrs = (($items.LocalAddress | Sort-Object -Unique) -join ";")
        $first = $items | Select-Object -First 1
        $proc = $Processes | Where-Object { $_.ProcessId -eq $first.OwningProcess } | Select-Object -First 1

        $level = "关注"
        if ($port -in @(3389,445,5985,5986,6379,9200,27017,3306,1433,23)) { $level = "高危" }
        elseif ($port -in @(21,22,135,139,5900,11211,7001,8080)) { $level = "中危" }

        $addrList = @($items.LocalAddress | Sort-Object -Unique)
        $isLoopbackOnly = $true
        foreach ($a in $addrList) {
            if ($a -notin @('127.0.0.1','::1','localhost')) { $isLoopbackOnly = $false; break }
        }
        if ($isLoopbackOnly) { $level = "关注" }

        $DangerPorts += [PSCustomObject]@{
            Level        = $level
            LocalPort    = $port
            LocalAddress = $addrs
            ServiceRisk  = $info
            ProcessId    = $first.OwningProcess
            ProcessName  = $proc.Name
            ProcessPath  = $proc.ExecutablePath
        }

        Add-Finding -Level $level -Category "暴露面风险" -Title "发现危险监听端口" `
            -Evidence "本地监听端口=$port，监听地址=$addrs，说明=$info，进程=$($proc.Name)" `
            -Suggestion "监听不代表公网可访问。请结合 Windows 防火墙、云安全组、路由/NAT 策略确认是否对外暴露。"
    }
}
catch {}

Export-DetailCsv -Name "进程明细.csv" -Data $Processes
Export-DetailCsv -Name "网络连接.csv" -Data $NetConns
Export-DetailCsv -Name "资源异常进程.csv" -Data $ResourceAnomalies
Export-DetailCsv -Name "危险监听端口.csv" -Data $DangerPorts

# =========================================================
