﻿# WinIR-Helper v0.8.8-beta module: 20-Collect-SecurityEvents.ps1
# This module is dot-sourced by WinIR-Helper.ps1.

# =========================================================
# 模块 1：Windows 安全事件
# =========================================================

Write-Info "正在分析 Windows 安全事件..."

$SecurityEventIds = @(
    4624,4625,4634,4648,4672,4688,
    4720,4722,4723,4724,4725,4726,
    4728,4729,4732,4733,4738,4739,4740,
    4698,4702,1102
)

if ($SecurityProfile -eq "Full") {
    Write-Warn "安全事件使用 Full 全量模式，日志较大时可能耗时较久。建议日常使用默认 Fast 模式，或缩短 -Days。"
    $SecurityEventsRaw = Get-EventsById -LogName "Security" -Ids $SecurityEventIds -Label "Windows 安全事件 Full"
}
else {
    Write-Info "安全事件使用 Fast 分段模式：优先读取关键事件和最近登录事件，避免在 Security 日志过大时长时间无响应。"
    $SecurityEventsRaw = Get-SecurityEventsFast -MaxTotalEvents $SecurityMaxEvents
}

$SecurityEvents = @()

# v0.8.5：日志读取健康检查。Security 日志如果有记录但关注事件全部为 0，不能简单当成“安全”。
try {
    $secProbe = Get-EventLogProbe -LogName "Security"
    if (@($SecurityEventsRaw).Count -eq 0 -and $script:RunMode -eq "Live") {
        $recordCountNum = 0
        try { $recordCountNum = [int64]$secProbe.RecordCount } catch { $recordCountNum = 0 }
        if ($secProbe.Status -eq "异常") {
            Add-Finding -Level "关注" -Category "数据完整性" -Title "Security 日志读取异常" `
                -Evidence "Security 日志探测状态=$($secProbe.Status)，错误=$($secProbe.Message)" `
                -Suggestion "请确认是否以管理员权限运行、事件日志服务是否正常，以及是否能手工执行 Get-WinEvent -LogName Security -MaxEvents 1。"
        }
        elseif ($recordCountNum -gt 0) {
            Add-Finding -Level "关注" -Category "数据完整性" -Title "Security 日志存在记录但关注事件读取为 0" `
                -Evidence "Security 日志 RecordCount=$recordCountNum，LatestEventId=$($secProbe.LatestEventId)，LatestEventTime=$($secProbe.LatestEventTime)，EventReadMode=$EventReadMode" `
                -Suggestion "这通常不是攻击结论，而是读取方式、时间窗口或审计策略问题。建议手工执行 Get-WinEvent -FilterHashtable @{LogName='Security'; Id=4624; StartTime=(Get-Date).AddDays(-7)} -MaxEvents 5；若手工有结果而工具无结果，请反馈数据完整性表。"
        }
    }
} catch {}

foreach ($evt in $SecurityEventsRaw) {
    try {
        [xml]$xml = $evt.ToXml()
        $msg = $evt.Message

        $subjectUser = Get-EventDataValue -Xml $xml -Name "SubjectUserName"
        $targetUser  = Get-EventDataValue -Xml $xml -Name "TargetUserName"
        $memberName  = Get-EventDataValue -Xml $xml -Name "MemberName"
        $targetSid   = Get-EventDataValue -Xml $xml -Name "TargetSid"
        $memberSid   = Get-EventDataValue -Xml $xml -Name "MemberSid"
        $ip          = Get-EventDataValue -Xml $xml -Name "IpAddress"
        $port        = Get-EventDataValue -Xml $xml -Name "IpPort"
        $logonType   = Get-EventDataValue -Xml $xml -Name "LogonType"
        $status      = Get-EventDataValue -Xml $xml -Name "Status"
        $subStatus   = Get-EventDataValue -Xml $xml -Name "SubStatus"
        $authPackage = Get-EventDataValue -Xml $xml -Name "AuthenticationPackageName"
        $targetDomain = Get-EventDataValue -Xml $xml -Name "TargetDomainName"
        $workstation  = Get-EventDataValue -Xml $xml -Name "WorkstationName"
        if (-not $workstation) { $workstation = Get-EventDataValue -Xml $xml -Name "Workstation" }

        if ([string]::IsNullOrWhiteSpace($targetUser)) { $targetUser = $subjectUser }

        $failureReason = ""
        if ($evt.Id -eq 4625) {
            $failureReason = Get-EventMessageValue -Message $msg -FieldName "Failure Reason"
        }

        $eventType = switch ($evt.Id) {
            4624 { "登录成功" }
            4625 { "登录失败" }
            4634 { "账户注销" }
            4648 { "显式凭据登录" }
            4672 { "特权登录" }
            4688 { "进程创建" }
            4720 { "创建用户" }
            4722 { "启用用户" }
            4723 { "修改密码尝试" }
            4724 { "重置密码" }
            4725 { "禁用用户" }
            4726 { "删除用户" }
            4728 { "加入全局组" }
            4729 { "移出全局组" }
            4732 { "加入本地组" }
            4733 { "移出本地组" }
            4738 { "用户账户变更" }
            4739 { "域策略变更" }
            4740 { "账户锁定" }
            4698 { "创建计划任务" }
            4702 { "更新计划任务" }
            1102 { "安全日志被清除" }
            default { "安全事件" }
        }

        $SecurityEvents += [PSCustomObject]@{
            TimeCreated   = $evt.TimeCreated
            EventID       = $evt.Id
            EventType     = $eventType
            RecordID      = $evt.RecordId
            Computer      = $evt.MachineName
            SubjectUser   = $subjectUser
            TargetUser    = $targetUser
            TargetDomain  = $targetDomain
            WorkstationName = $workstation
            MemberName    = $memberName
            TargetSid     = $targetSid
            MemberSid     = $memberSid
            LogonType     = $logonType
            LogonTypeDesc = Get-LogonTypeDesc -LogonType $logonType
            SourceIP      = $ip
            SourcePort    = $port
            FailureReason = $failureReason
            Status        = $status
            SubStatus     = $subStatus
            AuthPackage   = $authPackage
        }
    }
    catch {}
}

$SecuritySummary = $SecurityEvents |
    Group-Object EventID, EventType |
    Sort-Object Count -Descending |
    ForEach-Object {
        $first = $_.Group | Select-Object -First 1
        [PSCustomObject]@{
            EventID   = $first.EventID
            EventType = $first.EventType
            Count     = $_.Count
        }
    }

Export-DetailCsv -Name "安全事件明细.csv" -Data $SecurityEvents
Export-DetailCsv -Name "安全事件统计.csv" -Data $SecuritySummary

# 登录失败与成功
$FailedLogons = $SecurityEvents | Where-Object { $_.EventID -eq 4625 }
$SuccessfulLogons = $SecurityEvents | Where-Object { $_.EventID -eq 4624 }

# 4625 有时没有标准来源 IP，尤其是本机 IPC$、本地服务或部分虚拟机测试场景。
# 因此除 IP Top 外，额外生成登录失败明细与'来源/用户/类型'聚合，避免用户误以为没有失败登录。
$FailedLogonDetails = @()
foreach ($f in ($FailedLogons | Sort-Object TimeCreated)) {
    $srcIp = Safe-String $f.SourceIP
    $workstationName = Safe-String $f.WorkstationName
    $srcDisplay = ""

    if ($srcIp -and $srcIp -notin @("-","127.0.0.1","::1")) {
        $srcDisplay = "IP:$srcIp"
    }
    elseif ($workstationName -and $workstationName -ne "-") {
        $srcDisplay = "Workstation:$workstationName"
    }
    elseif ($srcIp -in @("127.0.0.1","::1")) {
        $srcDisplay = "Localhost:$srcIp"
    }
    else {
        $srcDisplay = "NoSourceIP"
    }

    $detailNote = ""
    if ($f.TargetUser -match '\$\{jndi:') { $detailNote = "疑似 Log4Shell/Nessus 等漏洞扫描 payload，不按口令爆破直接计分。" }

    $FailedLogonDetails += [PSCustomObject]@{
        TimeCreated     = $f.TimeCreated
        Source          = $srcDisplay
        SourceIP        = $f.SourceIP
        WorkstationName = $f.WorkstationName
        TargetUser      = $f.TargetUser
        TargetDomain    = $f.TargetDomain
        LogonType       = $f.LogonType
        LogonTypeDesc   = $f.LogonTypeDesc
        SourcePort      = $f.SourcePort
        FailureReason   = $f.FailureReason
        Status          = $f.Status
        SubStatus       = $f.SubStatus
        AuthPackage     = $f.AuthPackage
        RecordID        = $f.RecordID
        Note            = $detailNote
    }
}

$FailedByIdentity = $FailedLogonDetails |
    Group-Object Source,TargetUser,LogonTypeDesc |
    Sort-Object Count -Descending |
    ForEach-Object {
        $items = $_.Group | Sort-Object TimeCreated
        $first = $items | Select-Object -First 1
        $last  = $items | Select-Object -Last 1
        [PSCustomObject]@{
            Source          = $first.Source
            FailedCount     = $_.Count
            AttackStartTime = $first.TimeCreated
            LastFailTime    = $last.TimeCreated
            DurationMinutes = [Math]::Round((New-TimeSpan -Start $first.TimeCreated -End $last.TimeCreated).TotalMinutes, 2)
            TargetUser      = $first.TargetUser
            TargetDomain    = $first.TargetDomain
            LogonTypeDesc   = $first.LogonTypeDesc
            FailureReasons  = (($items.FailureReason | Where-Object { $_ } | Sort-Object -Unique) -join ";")
            StatusCodes     = (($items.Status | Where-Object { $_ } | Sort-Object -Unique) -join ";")
            Workstations    = (($items.WorkstationName | Where-Object { $_ } | Sort-Object -Unique) -join ";")
            Note            = if ($first.TargetUser -match '\$\{jndi:') { "疑似漏洞扫描 payload，不按口令爆破直接计分。" } elseif ($first.Source -eq "NoSourceIP") { "4625 未解析到来源 IP，建议结合 WorkstationName、LogonType 和安全日志原文复核。" } else { "" }
        }
    }

$FailedByIP = $FailedLogons |
    Where-Object { $_.SourceIP -and $_.SourceIP -ne "-" -and $_.SourceIP -ne "::1" -and $_.SourceIP -ne "127.0.0.1" } |
    Group-Object SourceIP |
    Sort-Object Count -Descending |
    ForEach-Object {
        $currentIP = $_.Name
        $items = $_.Group | Sort-Object TimeCreated
        $firstFail = $items | Select-Object -First 1
        $lastFail  = $items | Select-Object -Last 1

        $ports = $items.SourcePort | Where-Object { $_ -match "^\d+$" } | ForEach-Object { [int]$_ }
        $minPort = ""
        $maxPort = ""
        if ($ports.Count -gt 0) {
            $minPort = ($ports | Measure-Object -Minimum).Minimum
            $maxPort = ($ports | Measure-Object -Maximum).Maximum
        }

        $topMethod = ($items | Group-Object LogonTypeDesc | Sort-Object Count -Descending | Select-Object -First 1).Name

        $successAfter = $SuccessfulLogons |
            Where-Object { $_.SourceIP -eq $currentIP -and $_.TimeCreated -ge $firstFail.TimeCreated } |
            Sort-Object TimeCreated |
            Select-Object -First 1

        [PSCustomObject]@{
            SourceIP          = $currentIP
            FailedCount       = $_.Count
            AttackStartTime   = $firstFail.TimeCreated
            LastFailTime      = $lastFail.TimeCreated
            DurationMinutes   = [Math]::Round((New-TimeSpan -Start $firstFail.TimeCreated -End $lastFail.TimeCreated).TotalMinutes, 2)
            TargetUsers       = (($items.TargetUser | Where-Object { $_ } | Sort-Object -Unique) -join ";")
            TargetUserCount   = ($items.TargetUser | Where-Object { $_ } | Sort-Object -Unique).Count
            MainLogonMethod   = $topMethod
            LogonMethods      = (($items.LogonTypeDesc | Where-Object { $_ } | Sort-Object -Unique) -join ";")
            SourcePortRange   = if ($minPort -ne "" -and $maxPort -ne "") { "$minPort-$maxPort" } else { "" }
            Reasons           = (($items.FailureReason | Where-Object { $_ } | Sort-Object -Unique) -join ";")
            FirstSuccessTime  = if ($successAfter) { $successAfter.TimeCreated } else { "" }
            FirstSuccessUser  = if ($successAfter) { $successAfter.TargetUser } else { "" }
            FirstSuccessType  = if ($successAfter) { $successAfter.LogonTypeDesc } else { "" }
            AttackJudgement   = if ($successAfter) { "失败后出现同源登录成功，疑似爆破成功，需要重点复核" } else { "仅发现失败登录，疑似爆破尝试" }
        }
    }

Export-DetailCsv -Name "登录失败来源IP统计.csv" -Data $FailedByIP
Export-DetailCsv -Name "登录失败明细.csv" -Data $FailedLogonDetails
Export-DetailCsv -Name "登录失败按来源用户聚合.csv" -Data $FailedByIdentity

# 减少 4648 / 4672 噪音，只保留有实际意义的事件
foreach ($evt in ($SecurityEvents | Where-Object { $_.EventID -in @(1102,4720,4726,4732,4698,4648,4672) })) {
    # 重点关注项默认只展示最近 FocusDays 天内的安全事件，避免 -Days 1000 时历史事件刷屏。
    if (-not (Test-IsInFocusWindow -Time $evt.TimeCreated)) { continue }

    if ($evt.EventID -eq 4672) {
        if (Test-IsNoiseUser -User $evt.TargetUser) { continue }
        if ([string]::IsNullOrWhiteSpace($evt.SourceIP) -or $evt.SourceIP -eq "-") { continue }
    }

    if ($evt.EventID -eq 4648) {
        if (Test-IsNoiseUser -User $evt.TargetUser) { continue }
        if ($evt.SourceIP -in @("-","127.0.0.1","::1")) { continue }
    }

    if ($evt.EventID -eq 4720) {
        if ($evt.TargetUser -in @("WDAGUtilityAccount","DefaultAccount")) { continue }
    }

    if ($evt.EventID -eq 4732) {
        # 只将管理员组 / 远程桌面组变更放入重点关注；Users / IIS_IUSRS 这类普通组不刷屏
        if ($evt.TargetUser -notmatch "(?i)Administrators|Remote Desktop Users|管理员|远程桌面用户") {
            continue
        }
    }

    $level = switch ($evt.EventID) {
        1102 { "高危" }
        4720 { "高危" }
        4732 { "高危" }
        4726 { "中危" }
        4698 { "中危" }
        4648 { "关注" }
        4672 { "关注" }
        default { "关注" }
    }

    $detail = "时间=$($evt.TimeCreated)，EventID=$($evt.EventID)，用户=$($evt.TargetUser)"
    if ($evt.MemberName) { $detail += "，成员=$($evt.MemberName)" }
    if ($evt.SubjectUser) { $detail += "，操作者=$($evt.SubjectUser)" }
    if ($evt.SourceIP) { $detail += "，来源IP=$($evt.SourceIP)" }

    Add-Finding -Level $level -Category "Windows 安全事件" -Title $evt.EventType `
        -Evidence $detail `
        -Suggestion "结合事件上下文、登录来源、管理员组成员、计划任务和服务安装记录进行人工复核。"
}

