﻿# WinIR-Helper v0.8.8-beta module: 10-Initialize.ps1
# This module is dot-sourced by WinIR-Helper.ps1.

# =========================================================
# 初始化
# =========================================================

$IsAdmin = Test-IsAdmin

if (-not $IsAdmin -and -not $AllowNonAdmin) {
    Write-Warn "当前 PowerShell 不是管理员权限，部分日志和系统信息可能无法读取。"
    Write-Warn "建议右键 PowerShell，选择「以管理员身份运行」。"
    Write-Warn "如确实要继续，可运行：.\$ScriptName -AllowNonAdmin"
    exit
}

Get-TimeWindow
Ensure-OutputDir

if ($Mode -eq "Offline" -or -not [string]::IsNullOrWhiteSpace($LogFolder)) {
    $script:RunMode = "Offline"
}
else {
    $script:RunMode = "Live"
}

if ($script:RunMode -eq "Offline" -and ([string]::IsNullOrWhiteSpace($LogFolder) -or -not (Test-Path $LogFolder))) {
    Write-Warn "离线 EVTX 分析模式需要指定有效的 -LogFolder。"
    exit
}

$Findings = New-Object System.Collections.Generic.List[object]
$Scenarios = New-Object System.Collections.Generic.List[object]
$script:EventLogReadIssues = New-Object System.Collections.Generic.List[object]
$script:EventLogQuerySummary = New-Object System.Collections.Generic.List[object]
$script:EventLogProbeCache = @{}

Write-Host ""
Write-Host "=============================================" -ForegroundColor DarkCyan
Write-Host " WinIR-Helper $Version" -ForegroundColor Green
Write-Host " v0.8 模块化重构版" -ForegroundColor Green
Write-Host "=============================================" -ForegroundColor DarkCyan
Write-Host "扫描范围：$StartTime ~ $EndTime"
Write-Host "重点排查：$FocusStartTime ~ $EndTime"
Write-Host "运行模式：$script:RunMode"
Write-Host "事件读取：$EventReadMode（RecentScan 上限：$EventRecentScanMaxEvents）"
if ($script:RunMode -eq "Offline") { Write-Host "离线日志目录：$LogFolder" }
Write-Host "输出目录：$OutputDir"
Write-Host "详细 CSV：$($ExportDetails.IsPresent)"
Write-Host ""

