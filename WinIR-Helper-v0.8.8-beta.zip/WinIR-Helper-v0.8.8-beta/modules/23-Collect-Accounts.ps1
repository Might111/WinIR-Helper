﻿# WinIR-Helper v0.8.8-beta module: 23-Collect-Accounts.ps1
# This module is dot-sourced by WinIR-Helper.ps1.

# 模块 4：账户、管理员组、远程桌面组、隐藏账户
# =========================================================

Write-Info "正在检查本地用户、管理员组、远程桌面用户组与隐藏账户..."

function Test-AccountNameInMembers {
    param(
        [string]$AccountName,
        [object[]]$Members
    )

    if ([string]::IsNullOrWhiteSpace($AccountName)) { return $false }

    $escaped = [regex]::Escape($AccountName)
    foreach ($m in $Members) {
        $n = [string]$m.Name
        if ($n -match "(?i)(^|\\)$escaped$") { return $true }
        if ($n -ieq $AccountName) { return $true }
    }

    return $false
}

function Get-AccountRid {
    param([object]$Sid)
    try {
        $s = [string]$Sid
        if ($s -match '-(\d+)$') { return [int]$Matches[1] }
    } catch {}
    return $null
}

$CurrentUserName = [Environment]::UserName

$LocalUsers = @()
try {
    $LocalUsers = Get-LocalUser -ErrorAction Stop | ForEach-Object {
        [PSCustomObject]@{
            Name                   = $_.Name
            Enabled                = $_.Enabled
            SID                    = $_.SID
            RID                    = Get-AccountRid -Sid $_.SID
            LastLogon              = $_.LastLogon
            PasswordLastSet        = $_.PasswordLastSet
            PasswordExpires        = $_.PasswordExpires
            PasswordRequired       = $_.PasswordRequired
            PasswordNeverExpires   = $_.PasswordNeverExpires
            UserMayChangePassword = $_.UserMayChangePassword
            AccountExpires         = $_.AccountExpires
            Description            = $_.Description
        }
    }
}
catch {}

$AdminMembers = @()
foreach ($g in @("Administrators","管理员")) {
    try {
        $AdminMembers = Get-LocalGroupMember -Group $g -ErrorAction Stop | ForEach-Object {
            [PSCustomObject]@{
                Group           = $g
                Name            = $_.Name
                ObjectClass     = $_.ObjectClass
                PrincipalSource = $_.PrincipalSource
                SID             = $_.SID
            }
        }
        if ($AdminMembers.Count -gt 0) { break }
    }
    catch {}
}

$RdpMembers = @()
foreach ($g in @("Remote Desktop Users","远程桌面用户")) {
    try {
        $RdpMembers = Get-LocalGroupMember -Group $g -ErrorAction Stop | ForEach-Object {
            [PSCustomObject]@{
                Group           = $g
                Name            = $_.Name
                ObjectClass     = $_.ObjectClass
                PrincipalSource = $_.PrincipalSource
                SID             = $_.SID
            }
        }
        if ($RdpMembers.Count -gt 0) { break }
    }
    catch {}
}

$HiddenAccounts = @()
try {
    $regPath = "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon\SpecialAccounts\UserList"
    if (Test-Path $regPath) {
        $props = Get-ItemProperty -Path $regPath
        foreach ($p in $props.PSObject.Properties) {
            if ($p.Name -notmatch "^PS") {
                $HiddenAccounts += [PSCustomObject]@{
                    Account  = $p.Name
                    Value    = $p.Value
                    RegPath  = $regPath
                    Meaning  = if ([int]$p.Value -eq 0) { "隐藏登录界面账户" } else { "显示/非隐藏或异常值，需复核" }
                }

                Add-Finding -Level "高危" -Category "账户检查" -Title "发现 Winlogon 隐藏账户注册表项" `
                    -Evidence "账户=$($p.Name)，值=$($p.Value)，路径=$regPath" `
                    -Suggestion "确认该账户是否为攻击者隐藏账户；检查管理员组、远程桌面用户组、登录日志与创建账户事件。"
            }
        }
    }
}
catch {}

$AccountSecurityEvents = $SecurityEvents |
    Where-Object { $_.EventID -in @(4720,4722,4723,4724,4725,4726,4728,4732,4738,4739,4740,4648,4672,1102) } |
    Sort-Object TimeCreated |
    Select-Object TimeCreated,EventID,EventType,SubjectUser,TargetUser,MemberName,TargetDomain,TargetSid,MemberSid,LogonTypeDesc,SourceIP,WorkstationName,Status,SubStatus

$SuspiciousUsers = @()
foreach ($u in $LocalUsers) {
    $reasons = New-Object System.Collections.Generic.List[string]
    $score = 0

    $isHidden = $false
    foreach ($h in $HiddenAccounts) {
        if ($h.Account -ieq $u.Name) { $isHidden = $true; break }
    }

    $isAdmin = Test-AccountNameInMembers -AccountName $u.Name -Members $AdminMembers
    $isRdp   = Test-AccountNameInMembers -AccountName $u.Name -Members $RdpMembers
    $isCurrentUser = ($u.Name -ieq $CurrentUserName)
    $rid = Get-AccountRid -Sid $u.SID
    $isBuiltInAdministrator = ($rid -eq 500 -or $u.Name -match '(?i)^administrator$')
    $isBuiltInGuestOrSystem = ($rid -in @(501,503,504) -or $u.Name -match '(?i)^(Guest|DefaultAccount|WDAGUtilityAccount)$')
    $suspiciousName = ($u.Name -match '(?i)(hack|hacker|backdoor|shadow|shell|support|backup|svc_|admin\d+|system\d+|\$$)')

    # v0.6.8：本地管理员组成员本身不是恶意。Might 这种当前用户属于管理员组属于正常场景，只在'管理员组成员'表展示。
    # 只有和隐藏账户、可疑命名、远程桌面组、异常密码策略等组合出现时，才进入'可疑本地账户'。
    if ($suspiciousName) {
        $reasons.Add("用户名命中可疑模式") | Out-Null
        $score += 3
    }

    if ($isHidden) {
        $reasons.Add("存在 Winlogon SpecialAccounts\\UserList 隐藏账户项") | Out-Null
        $score += 6
    }

    if ($isRdp -and -not $isCurrentUser) {
        $reasons.Add("属于远程桌面用户组") | Out-Null
        $score += 3
    }

    if ($isAdmin -and ($suspiciousName -or $isHidden -or $isRdp)) {
        $reasons.Add("可疑账户同时属于本地管理员组") | Out-Null
        $score += 4
    }

    if ($isBuiltInAdministrator -and $u.Enabled -eq $true) {
        $reasons.Add("内置 Administrator 账户已启用") | Out-Null
        $score += 2
    }

    if ($u.Enabled -eq $true -and $u.PasswordNeverExpires -eq $true -and ($suspiciousName -or $isHidden -or $isRdp -or ($isAdmin -and -not $isCurrentUser -and -not $isBuiltInAdministrator))) {
        $reasons.Add("可疑账户启用且密码永不过期") | Out-Null
        $score += 1
    }

    if ($u.Enabled -eq $true -and $u.UserMayChangePassword -eq $false -and ($suspiciousName -or $isHidden -or $isRdp)) {
        $reasons.Add("可疑账户启用且用户不可改密码") | Out-Null
        $score += 1
    }

    # 过滤常见内置/正常账户：
    # 1. 禁用的内置 Administrator 不进入可疑账户；
    # 2. 当前登录用户仅因管理员组或描述为空不进入可疑账户；
    # 3. Guest / DefaultAccount / WDAGUtilityAccount 等系统账户不因内置属性进入可疑账户。
    if ($isBuiltInAdministrator -and $u.Enabled -eq $false -and -not $isHidden) {
        $reasons.Clear()
        $score = 0
    }

    if ($isCurrentUser -and -not $isHidden -and -not $suspiciousName -and -not $isRdp) {
        $reasons.Clear()
        $score = 0
    }

    if ($isBuiltInGuestOrSystem -and -not $isHidden -and -not $suspiciousName) {
        $reasons.Clear()
        $score = 0
    }

    if ($reasons.Count -gt 0) {
        $level = if ($isHidden -or ($isAdmin -and $suspiciousName)) { "高危" }
                 elseif ($isRdp -or $score -ge 4) { "中危" }
                 else { "关注" }

        $SuspiciousUsers += [PSCustomObject]@{
            Level                  = $level
            Name                   = $u.Name
            Enabled                = $u.Enabled
            Score                  = $score
            Reasons                = ($reasons -join ";")
            IsHidden               = $isHidden
            IsAdmin                = $isAdmin
            IsRemoteDesktopUser    = $isRdp
            IsCurrentUser          = $isCurrentUser
            IsBuiltIn              = ($isBuiltInAdministrator -or $isBuiltInGuestOrSystem)
            LastLogon              = $u.LastLogon
            PasswordLastSet        = $u.PasswordLastSet
            PasswordNeverExpires   = $u.PasswordNeverExpires
            UserMayChangePassword = $u.UserMayChangePassword
            Description            = $u.Description
            SID                    = $u.SID
        }

        Add-Finding -Level $level -Category "账户检查" -Title "发现可疑本地账户 / 权限组合" `
            -Evidence "用户=$($u.Name)，评分=$score，原因=$($reasons -join ';')，隐藏=$isHidden，管理员组=$isAdmin，远程桌面组=$isRdp，当前用户=$isCurrentUser，最近登录=$($u.LastLogon)，描述=$($u.Description)" `
            -Suggestion "确认账户来源、创建时间、所属组、最近登录和业务归属。若为未知账户且属于管理员或远程桌面用户组，应优先禁用、留证并复核创建事件。"
    }
}

# v0.6.8：如果 SpecialAccounts\UserList 中存在账户名，但 Get-LocalUser 未枚举到，也要作为'隐藏账户残留/幽灵项'单独进入可疑账户表。
foreach ($h in $HiddenAccounts) {
    $exists = $false
    foreach ($u in $LocalUsers) {
        if ($u.Name -ieq $h.Account) { $exists = $true; break }
    }

    if (-not $exists) {
        $SuspiciousUsers += [PSCustomObject]@{
            Level                  = "高危"
            Name                   = $h.Account
            Enabled                = "Unknown"
            Score                  = 6
            Reasons                = "Winlogon 隐藏账户注册表项存在，但 Get-LocalUser 未枚举到账户；可能是残留项、创建失败或异常隐藏痕迹"
            IsHidden               = $true
            IsAdmin                = "Unknown"
            IsRemoteDesktopUser    = "Unknown"
            IsCurrentUser          = $false
            IsBuiltIn              = $false
            LastLogon              = ""
            PasswordLastSet        = ""
            PasswordNeverExpires   = ""
            UserMayChangePassword = ""
            Description            = ""
            SID                    = ""
        }

        Add-Finding -Level "高危" -Category "账户检查" -Title "发现隐藏账户注册表残留 / 未枚举账户" `
            -Evidence "账户=$($h.Account)，路径=$($h.RegPath)，Get-LocalUser 未枚举到该账户" `
            -Suggestion "复核该隐藏账户是否已被删除但注册表残留，或是否存在异常隐藏/枚举绕过情况；建议导出注册表项并检查 SAM、事件日志和管理员组变化。"
    }
}

Export-DetailCsv -Name "本地用户.csv" -Data $LocalUsers
Export-DetailCsv -Name "管理员组成员.csv" -Data $AdminMembers
Export-DetailCsv -Name "远程桌面用户组成员.csv" -Data $RdpMembers
Export-DetailCsv -Name "Winlogon隐藏账户.csv" -Data $HiddenAccounts
Export-DetailCsv -Name "可疑本地账户.csv" -Data $SuspiciousUsers
Export-DetailCsv -Name "账户相关安全事件.csv" -Data $AccountSecurityEvents

# =========================================================
