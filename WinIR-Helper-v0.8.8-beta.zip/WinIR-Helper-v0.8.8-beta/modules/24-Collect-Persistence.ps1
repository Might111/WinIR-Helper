﻿# WinIR-Helper v0.8.8-beta module: 24-Collect-Persistence.ps1
# This module is dot-sourced by WinIR-Helper.ps1.

# 模块 5：计划任务、启动项
# =========================================================

Write-Info "正在检查计划任务与启动项..."

$SuspiciousPathRegex = "(?i)\\Users\\[^\\]+\\AppData\\|\\Users\\Public\\|\\Windows\\Temp\\|\\Temp\\|\\ProgramData\\|\\Downloads\\"
$DangerCommandRegex  = "(?i)-enc|-encodedcommand|frombase64string|downloadstring|downloadfile|iex\s|invoke-expression|invoke-webrequest|\biwr\b|invoke-restmethod|\birm\b|new-object\s+net\.webclient|certutil.*-urlcache|bitsadmin|mshta|regsvr32.*scrobj|rundll32.*javascript|schtasks\s+/create|net\s+user|net\s+localgroup|add-localgroupmember|set-mppreference|disableantispyware|bypass|hidden|nop|http://|https://|xmrig|miner|c3pool|stratum|monero"

$Tasks = @()
try {
    $Tasks = Get-ScheduledTask -ErrorAction Stop | ForEach-Object {
        $actions = ($_.Actions | ForEach-Object { "$($_.Execute) $($_.Arguments)" }) -join " || "
        [PSCustomObject]@{
            TaskName = $_.TaskName
            TaskPath = $_.TaskPath
            State    = $_.State
            Author   = $_.Author
            Actions  = $actions
        }
    }
}
catch {}

$SuspiciousTasks = @()
foreach ($t in $Tasks) {
    if (Test-IsBuiltinTask -TaskPath $t.TaskPath -Actions $t.Actions) { continue }
    if (Test-IsTrustedVendorCommand -Command $t.Actions) { continue }

    $reason = @()
    if ($t.Actions -match $DangerCommandRegex) { $reason += "命令行动作可疑" }
    if (Test-IsSuspiciousPersistencePath -PathOrCommand $t.Actions) { $reason += "执行路径位于可疑目录或脚本类型" }
    if ("$($t.TaskPath)$($t.TaskName)" -match "(?i)^\\Microsoft\\Windows\\(UpdateOrchestrator|WDI|Application Experience)\\" -and
        $t.TaskName -notmatch "(?i)^(Schedule Scan|Schedule Retry Scan|USO_UxBroker|Reboot|Refresh Settings|Maintenance Install|PcaPatchDbTask|ProgramDataUpdater|Microsoft Compatibility Appraiser)$") {
        $reason += "任务伪装在 Microsoft\\Windows 系统路径下但名称/动作需要复核"
    }

    if ($reason.Count -gt 0) {
        $level = if ($t.Actions -match "(?i)xmrig|miner|c3pool|net\s+user|add-localgroupmember|downloadstring|-enc|-encodedcommand") { "高危" } else { "中危" }
        if ($reason -contains "任务伪装在 Microsoft\\Windows 系统路径下但名称/动作需要复核" -and $t.Actions -match "(?i)\\ProgramData\\|powershell|wscript|cscript|mshta|\.(ps1|vbs|hta|bat|cmd)\b") { $level = "中危" }

        $obj = [PSCustomObject]@{
            Level    = $level
            TaskName = "$($t.TaskPath)$($t.TaskName)"
            State    = $t.State
            Actions  = $t.Actions
            Reason   = ($reason -join ";")
        }

        $SuspiciousTasks += $obj

        Add-Finding -Level $level -Category "计划任务" -Title "发现可疑计划任务" `
            -Evidence "任务=$($obj.TaskName)，动作=$($obj.Actions)，原因=$($obj.Reason)" `
            -Suggestion "检查任务创建时间、执行文件签名、Hash、是否与挖矿/后门/下载执行有关。"
    }
}

Export-DetailCsv -Name "可疑计划任务.csv" -Data $SuspiciousTasks

$StartupItems = @()
try {
    $startupRegPaths = @(
        "HKLM:\Software\Microsoft\Windows\CurrentVersion\Run",
        "HKLM:\Software\Microsoft\Windows\CurrentVersion\RunOnce",
        "HKCU:\Software\Microsoft\Windows\CurrentVersion\Run",
        "HKCU:\Software\Microsoft\Windows\CurrentVersion\RunOnce",
        "HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Run"
    )

    foreach ($rp in $startupRegPaths) {
        if (Test-Path $rp) {
            $props = Get-ItemProperty -Path $rp
            foreach ($p in $props.PSObject.Properties) {
                if ($p.Name -notmatch "^PS") {
                    $cmd = [string]$p.Value
                    $exe = Extract-ExecutablePath -Command $cmd
                    $sigStatus = ""
                    try {
                        if (Test-Path $exe -PathType Leaf) {
                            $sigStatus = (Get-AuthenticodeSignature -FilePath $exe -ErrorAction SilentlyContinue).Status
                        }
                    }
                    catch {}

                    $StartupItems += [PSCustomObject]@{
                        Location  = $rp
                        Name      = $p.Name
                        Command   = $cmd
                        FilePath  = $exe
                        Signature = $sigStatus
                    }
                }
            }
        }
    }

    $startupFolders = @(
        "$env:APPDATA\Microsoft\Windows\Start Menu\Programs\Startup",
        "$env:ProgramData\Microsoft\Windows\Start Menu\Programs\Startup"
    )

    foreach ($sf in $startupFolders) {
        if (Test-Path $sf) {
            Get-ChildItem -Path $sf -File -Force -ErrorAction SilentlyContinue | Where-Object { $_.Name -notmatch '(?i)^desktop\.ini$' } | ForEach-Object {
                $cmd = $_.FullName
                $filePath = $_.FullName
                $sigStatus = ""

                # v0.6.4：解析 Startup 目录中的 .lnk 快捷方式。
                # 攻击者经常用快捷方式隐藏真实 TargetPath + Arguments；原来只看到 .lnk 文件本身，容易漏掉 wscript/mshta/powershell 等动作。
                if ($_.Extension -match '(?i)^\.lnk$') {
                    try {
                        $shell = New-Object -ComObject WScript.Shell
                        $shortcut = $shell.CreateShortcut($_.FullName)
                        $target = [string]$shortcut.TargetPath
                        $args = [string]$shortcut.Arguments
                        if (-not [string]::IsNullOrWhiteSpace($target)) {
                            $cmd = ($target + " " + $args).Trim()
                            $filePath = $target
                        }
                    } catch {}
                }

                try {
                    if (Test-Path $filePath -PathType Leaf) {
                        $sigStatus = (Get-AuthenticodeSignature -FilePath $filePath -ErrorAction SilentlyContinue).Status
                    }
                } catch {}

                $StartupItems += [PSCustomObject]@{
                    Location  = $sf
                    Name      = $_.Name
                    Command   = $cmd
                    FilePath  = $filePath
                    Signature = $sigStatus
                }
            }
        }
    }
}
catch {}

$SuspiciousStartup = @()
foreach ($s in $StartupItems) {
    if ($s.Name -match '(?i)^desktop\.ini$') { continue }
    $reason = @()
    $isTrustedVendor = Test-IsTrustedVendorCommand -Command $s.Command
    $isDangerScriptOrCommand = Test-IsScriptOrDangerPersistence -Command $s.Command

    $isSuspiciousPath = Test-IsSuspiciousPersistencePath -PathOrCommand $s.Command

    # v0.5.2 调整：持久化启动项只要落在 ProgramData / Public / Temp / Downloads / AppData 等高风险位置，
    # 即使文件带有效签名也进入关注。真实攻击中常见'复制系统签名程序到可写目录后持久化'的伪装方式。
    if ($isSuspiciousPath -and (-not $isTrustedVendor)) {
        $reason += "启动项执行路径位于可疑目录"
        if ([string]::IsNullOrWhiteSpace($s.Signature) -or $s.Signature -ne "Valid") {
            $reason += "启动项位于可疑目录且缺少可信签名"
        }
    }

    if ($isDangerScriptOrCommand) {
        $reason += "启动项命令命中危险脚本或命令特征"
    }

    if ($s.Signature -and $s.Signature -notin @("Valid","NotSigned") -and (-not $isTrustedVendor)) {
        $reason += "签名状态异常：$($s.Signature)"
    }

    if ($reason.Count -gt 0) {
        $level = if ($s.Command -match "(?i)\.(bat|cmd|ps1|vbs|js|hta)\b|wscript(\.exe)?|cscript(\.exe)?|mshta(\.exe)?|powershell(\.exe)?|xmrig|miner|c3pool|stratum|monero|downloadstring|-enc|-encodedcommand") { "高危" } else { "中危" }

        $obj = [PSCustomObject]@{
            Level     = $level
            Location  = $s.Location
            Name      = $s.Name
            Command   = $s.Command
            FilePath  = $s.FilePath
            Signature = $s.Signature
            Reason    = ($reason -join ";")
        }

        $SuspiciousStartup += $obj

        Add-Finding -Level $level -Category "启动项" -Title "发现可疑启动项持久化" `
            -Evidence "位置=$($obj.Location)，名称=$($obj.Name)，命令=$($obj.Command)，签名=$($obj.Signature)，原因=$($obj.Reason)" `
            -Suggestion "重点检查 AppData/Public/Temp/ProgramData 下的 bat、ps1、vbs、exe 启动项；确认是否为后门或挖矿持久化。"
    }
}

Export-DetailCsv -Name "启动项.csv" -Data $StartupItems
Export-DetailCsv -Name "可疑启动项.csv" -Data $SuspiciousStartup

# =========================================================
