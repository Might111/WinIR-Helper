﻿# WinIR-Helper v0.8.8-beta module: 03-Configuration.ps1
# 负责加载可选 JSON 配置。当前配置以“降噪/可维护”为主，保持对 v0.7.1 行为的兼容。

function New-WinIRDefaultConfig {
    return [PSCustomObject]@{
        IgnoreProcessNames = @(
            "OneDrive.exe",
            "msedge.exe",
            "SearchApp.exe"
        )
        IgnorePaths = @(
            "C:\\Program Files\\Microsoft",
            "C:\\Program Files (x86)\\Microsoft",
            "C:\\Program Files\\WindowsApps",
            "C:\\Windows\\SystemApps",
            "C:\\ProgramData\\Acunetix",
            "C:\\Program Files (x86)\\Acunetix",
            "C:\\Program Files\\Tenable",
            "C:\\Program Files\\Npcap",
            "C:\\Users\\*\\AppData\\Roaming\\BurpSuite"
        )
        KnownGoodServices = @(
            "WinDefend",
            "Sense",
            "Acunetix Database",
            "Acunetix",
            "Tenable Nessus",
            "npcap",
            "npf",
            "OWNeac",
            "VMSMP",
            "vmcompute",
            "vmms",
            "WSL Service",
            "Docker Desktop Service"
        )
        KnownGoodHashes = @()
        HighRiskPorts = @(
            21,22,23,135,139,445,1433,3306,3389,5432,5900,5985,5986,6379,7001,8080,9200,11211,27017
        )
        ScoreWeights = [PSCustomObject]@{
            HiddenAccount = 35
            MiningConfig = 30
            HighCpuProcess = 25
            SuspiciousPersistence = 25
            CredentialAttack = 20
        }
        KnownGoodTaskPatterns = @(
            "\\npcapwatchdog",
            "\\Microsoft\\Windows\\Hotpatch\\Monitoring"
        )
        KnownSecurityToolKeywords = @("Acunetix","Invicti","Nessus","Tenable","Npcap","Wireshark","BurpSuite","PortSwigger","Hyper-V","HyperV","vmswitch","WSL","Docker")
        MiningIgnoreUrlHosts = @("localhost","127.0.0.1","0.0.0.0","::1")
        HashCandidateExtensions = @(
            ".exe",".dll",".sys",".ps1",".bat",".cmd",".vbs",".js",".jse",".wsf",".hta",".scr",".lnk",".msi"
        )
        HashIgnorePathRegex = @(
            "(?i)\\db\\base\\",
            "(?i)\\db\\global\\",
            "(?i)\\Logs?\\",
            "(?i)\\ProgramData\\Acunetix\\db\\"
        )
    }
}

function Initialize-WinIRConfig {
    param([string]$ConfigPath)

    $script:WinIRConfig = New-WinIRDefaultConfig

    if ([string]::IsNullOrWhiteSpace($ConfigPath)) {
        return
    }

    try {
        if (Test-Path $ConfigPath -PathType Leaf) {
            $json = Get-Content -LiteralPath $ConfigPath -Raw -ErrorAction Stop
            $loaded = $json | ConvertFrom-Json -ErrorAction Stop
            if ($null -ne $loaded) { $script:WinIRConfig = $loaded }
            Write-Info "已加载配置文件：$ConfigPath"
        }
        else {
            Write-Warn "未找到配置文件，使用默认配置：$ConfigPath"
        }
    }
    catch {
        Write-Warn "配置文件解析失败，已回退默认配置：$ConfigPath"
        $script:WinIRConfig = New-WinIRDefaultConfig
    }
}
