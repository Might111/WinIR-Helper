﻿# WinIR-Helper v0.8.8-beta module: 90-Export-Report.ps1
# This module is dot-sourced by WinIR-Helper.ps1.

# =========================================================
# 输出报告
# =========================================================

Write-Info "正在生成报告..."

$FindingsArray = @()
foreach ($f in $Findings) { $FindingsArray += $f }

$ScenariosArray = @()
foreach ($s in $Scenarios) { $ScenariosArray += $s }

$FindingPath = Join-Path $OutputDir "重点关注项.csv"
$ScenarioPath = Join-Path $OutputDir "攻击场景判断.csv"

$FindingsArray | Export-Csv -Path $FindingPath -NoTypeInformation -Encoding UTF8
$ScenariosArray | Export-Csv -Path $ScenarioPath -NoTypeInformation -Encoding UTF8

# v0.8.5：把“入侵/威胁线索”和“暴露面风险”分开统计。
# 监听 3306/445 这类端口是暴露面问题，不应直接让首页看起来像“已发现高危入侵”。
$ThreatFindingsArray = @($FindingsArray | Where-Object { $_.Category -ne "暴露面风险" })
$ExposureFindingsArray = @($FindingsArray | Where-Object { $_.Category -eq "暴露面风险" })

$HighCount = @($ThreatFindingsArray | Where-Object { $_.Level -eq "高危" }).Count
$MidCount = @($ThreatFindingsArray | Where-Object { $_.Level -eq "中危" }).Count
$WatchCount = @($ThreatFindingsArray | Where-Object { $_.Level -eq "关注" }).Count
$ExposureCount = @($ExposureFindingsArray).Count
$ExposureHighCount = @($ExposureFindingsArray | Where-Object { $_.Level -eq "高危" }).Count

$DataIntegrityStatus = "正常"
$DataIntegrityClass = "ok"
$DataIntegrityMessage = "日志读取未发现明显异常。"
try {
    $secProbe = Get-EventLogProbe -LogName "Security"
    $issueCount = 0
    try {
        if ($null -ne $script:EventLogReadIssues) { $issueCount = [int]$script:EventLogReadIssues.Count }
    } catch { $issueCount = @($script:EventLogReadIssues).Count }

    $queryFailureCount = 0
    try {
        if ($null -ne $script:EventLogQuerySummary) {
            $queryFailureCount = @($script:EventLogQuerySummary | Where-Object { $_.Status -eq "失败" }).Count
        }
    } catch { $queryFailureCount = 0 }

    $secRecordCount = 0
    try { $secRecordCount = [int64]$secProbe.RecordCount } catch { $secRecordCount = 0 }

    if (($issueCount + $queryFailureCount) -gt 0) {
        $DataIntegrityStatus = "异常"
        $DataIntegrityClass = "high"
        $DataIntegrityMessage = "存在事件日志读取失败：读取异常 $issueCount 条，查询失败 $queryFailureCount 条。"
    }
    elseif ($script:RunMode -eq "Live" -and @($SecurityEvents).Count -eq 0 -and $secProbe.Status -eq "可读取" -and $secRecordCount -gt 0) {
        $DataIntegrityStatus = "需确认"
        $DataIntegrityClass = "mid"
        $DataIntegrityMessage = "Security 日志有记录，但关注事件读取为 0，需确认读取模式、审计策略或时间窗口。"
    }
} catch {
    $DataIntegrityStatus = "需确认"
    $DataIntegrityClass = "mid"
    $DataIntegrityMessage = "数据完整性状态计算异常：$($_.Exception.Message)"
}

$SummaryPath = Join-Path $OutputDir "WinIR_Summary.txt"

$summaryLines = @()
$summaryLines += "WinIR-Helper $Version 应急响应摘要"
$summaryLines += "生成时间：$(Get-Date)"
$summaryLines += "扫描范围：$StartTime ~ $EndTime"
$summaryLines += "重点排查：$FocusStartTime ~ $EndTime"
$summaryLines += "输出目录：$OutputDir"
$summaryLines += ""
$summaryLines += "一、攻击场景判断"
foreach ($s in $ScenariosArray) {
    $summaryLines += "[$($s.Level)] $($s.Scenario)：$($s.Conclusion)"
    $summaryLines += "证据：$($s.Evidence)"
}
$summaryLines += ""
$summaryLines += "一-补充、v0.7 证据链评分"
foreach ($es in ($EvidenceScoresArray | Select-Object -First 8)) {
    $summaryLines += "[$($es.Level)] $($es.Scenario)：评分=$($es.Score)，优先级=$($es.Priority)"
    $summaryLines += "证据：$($es.Evidence)"
}
$summaryLines += ""
$summaryLines += "一-补充、处置建议预览"
foreach ($ca in ($CleanupAdvicesArray | Select-Object -First 10)) {
    $summaryLines += "[$($ca.Priority)] $($ca.RiskType)：$($ca.Target)；建议=$($ca.SuggestedCommand)"
}
$summaryLines += ""
$summaryLines += "二、风险统计"
$summaryLines += "威胁高危：$HighCount"
$summaryLines += "威胁中危：$MidCount"
$summaryLines += "威胁关注：$WatchCount"
$summaryLines += "暴露面风险：$ExposureCount（高危端口=$ExposureHighCount）"
$summaryLines += "数据完整性：$DataIntegrityStatus - $DataIntegrityMessage"
$summaryLines += ""
$summaryLines += "二-补充、账户与恶意用户排查"
$summaryLines += "可疑账户数：$($SuspiciousUsers.Count)，隐藏账户数：$($HiddenAccounts.Count)，管理员组成员数：$($AdminMembers.Count)，远程桌面用户组成员数：$($RdpMembers.Count)"
foreach ($au in ($SuspiciousUsers | Select-Object -First 10)) {
    $summaryLines += "[$($au.Level)] 用户=$($au.Name)，评分=$($au.Score)，原因=$($au.Reasons)，隐藏=$($au.IsHidden)，管理员组=$($au.IsAdmin)，远程桌面组=$($au.IsRemoteDesktopUser)"
}
$summaryLines += ""
$summaryLines += "三、登录失败 Top IP"
foreach ($ip in ($FailedByIP | Select-Object -First 10)) {
    $summaryLines += "$($ip.SourceIP)：疑似开始时间=$($ip.AttackStartTime)，失败=$($ip.FailedCount)，目标账户=$($ip.TargetUsers)，方式=$($ip.MainLogonMethod)，首次成功=$($ip.FirstSuccessTime)，判断=$($ip.AttackJudgement)"
}
$summaryLines += ""
$summaryLines += "三-补充、登录失败按来源/用户聚合（含无来源 IP）"
foreach ($fg in ($FailedByIdentity | Select-Object -First 10)) {
    $summaryLines += "$($fg.Source)：失败=$($fg.FailedCount)，目标账户=$($fg.TargetUser)，方式=$($fg.LogonTypeDesc)，开始=$($fg.AttackStartTime)，结束=$($fg.LastFailTime)"
}
$summaryLines += ""
$summaryLines += "四、危险监听端口"
foreach ($p in ($DangerPorts | Select-Object -First 20)) {
    $summaryLines += "[$($p.Level)] $($p.LocalPort) $($p.ServiceRisk) 监听地址=$($p.LocalAddress)"
}
$summaryLines += ""
$summaryLines += "五、挖矿配置提取"
$summaryLines += "配置扫描候选来源数：$($MiningCandidateSourcesArray.Count)，候选文件数：$($MiningConfigFiles.Count)，原始提取线索数：$($MiningConfigsArray.Count)，聚合后线索数：$($MiningConfigsGroupedArray.Count)"
foreach ($m in ($MiningConfigsGroupedArray | Select-Object -First 20)) {
    $summaryLines += "[$($m.Type)] $($m.Value) 出现=$($m.HitCount) 来源=$($m.SourceFiles) 置信度=$($m.Confidence)"
}
$summaryLines += ""
$summaryLines += "六、攻击时间线预览"
foreach ($tl in ($AttackTimelineArray | Select-Object -First 15)) {
    $summaryLines += "$($tl.EvidenceId) [$($tl.Level)] $($tl.TimeCreated) $($tl.Phase) - $($tl.Action) - $($tl.TechniqueId) $($tl.TechniqueName)"
}
$summaryLines += ""
$summaryLines += "七、ATT&CK 技术映射"
foreach ($tech in ($AttackTechniques | Select-Object -First 15)) {
    $summaryLines += "$($tech.TechniqueId) $($tech.TechniqueName)：命中=$($tech.Count)，战术=$($tech.Tactic)，证据=$($tech.EvidenceIds)"
}
$summaryLines += ""
$summaryLines += "八、建议"
$summaryLines += "1. 优先查看 WinIR_Report.html 的「攻击场景判断」和「攻击时间线」。"
$summaryLines += "2. 再查看「重点关注项」和「资源异常进程」。重点关注项默认突出最近 $FocusDays 天内事件。"
$summaryLines += "3. v0.6 新增 ATT&CK 映射和证据链编号，可用于报告复盘，但最终结论仍需人工复核。"
$summaryLines += "4. 登录失败 Top IP 为空时，请优先查看「登录失败明细 / 无 IP 聚合」；本机测试通常只能得到 127.0.0.1 或空来源，真实来源 IP 需两台机器或真实远程登录场景验证。"
$summaryLines += "5. 若「自定义认证日志IP线索」存在，请把它作为应用/实验日志辅助证据，不要直接等同于 Windows 4625 的真实来源 IP。"
$summaryLines += "6. 下载/投放 URL 与矿池地址已分开展示：前者用于追踪投放链路，后者用于研判资源劫持/挖矿配置。"
$summaryLines += "7. 若「ADS备用数据流线索」存在，请把 ADS 作为隐藏配置/规避痕迹优先复核；若无 ADS，不代表系统不存在 ADS，只代表候选文件轻量扫描未命中。"
$summaryLines += "8. 若「账户与恶意用户排查」出现隐藏账户、可疑命名账户、远程桌面用户组异常成员或非预期管理员账户，请优先留证、确认来源并结合 4720/4732/4624/4625 事件复核。普通管理员组成员会在成员表展示，但不会仅因'属于管理员组'被判为可疑账户。"
$summaryLines += "9. v0.8.8 作为 v0.8 模块化收口修正版：修复 v0.8.7 摘要建议文本换行导致的 ParserError；事件读取将无匹配与失败分开统计；Hyper-V/WSL/Docker/vmswitch 等虚拟化组件默认降噪；威胁项与暴露面风险分开统计。处置命令只作为人工复核建议，不会自动执行；生产环境请先留证、确认业务归属和变更窗口。"

$summaryLines | Out-File -FilePath $SummaryPath -Encoding UTF8

$scenarioForHtml = $ScenariosArray | Select-Object Level,Scenario,Conclusion,Evidence,Suggestion
$evidenceScoreForHtml = $EvidenceScoresArray | Select-Object Level,Scenario,Score,Priority,Conclusion,Evidence,EvidenceIds,RecommendedAction
$cleanupAdviceForHtml = $CleanupAdvicesArray | Select-Object Priority,RiskType,Target,Evidence,SuggestedCommand,SafetyNote
$hashTargetsForHtml = $HighRiskHashTargetsArray | Select-Object FilePath,Exists,SuggestedCommand,Note
$findingsForHtml = $FindingsArray | Select-Object Level,Category,Title,Evidence,Suggestion
$securityForHtml = $SecuritySummary | Select-Object EventID,EventType,Count
$suspiciousUsersForHtml = $SuspiciousUsers | Select-Object Level,Name,Enabled,Score,Reasons,IsHidden,IsAdmin,IsRemoteDesktopUser,IsCurrentUser,IsBuiltIn,LastLogon,PasswordLastSet,PasswordNeverExpires,UserMayChangePassword,Description,SID
$localUsersForHtml = $LocalUsers | Select-Object Name,Enabled,RID,LastLogon,PasswordLastSet,PasswordNeverExpires,UserMayChangePassword,Description,SID
$adminMembersForHtml = $AdminMembers | Select-Object Group,Name,ObjectClass,PrincipalSource,SID
$rdpMembersForHtml = $RdpMembers | Select-Object Group,Name,ObjectClass,PrincipalSource,SID
$hiddenAccountsForHtml = $HiddenAccounts | Select-Object Account,Value,Meaning,RegPath
$accountEventsForHtml = $AccountSecurityEvents | Select-Object TimeCreated,EventID,EventType,SubjectUser,TargetUser,MemberName,TargetDomain,LogonTypeDesc,SourceIP,WorkstationName
$failedForHtml = $FailedByIP | Select-Object SourceIP,FailedCount,AttackStartTime,LastFailTime,DurationMinutes,TargetUsers,TargetUserCount,MainLogonMethod,SourcePortRange,FirstSuccessTime,FirstSuccessUser,AttackJudgement,Reasons
$failedIdentityForHtml = $FailedByIdentity | Select-Object Source,FailedCount,AttackStartTime,LastFailTime,DurationMinutes,TargetUser,TargetDomain,LogonTypeDesc,FailureReasons,StatusCodes,Workstations,Note
$failedDetailsForHtml = $FailedLogonDetails | Select-Object TimeCreated,Source,SourceIP,WorkstationName,TargetUser,TargetDomain,LogonTypeDesc,FailureReason,Status,SubStatus,AuthPackage,Note
$rdpForHtml = $RdpEvents | Select-Object TimeCreated,EventID,UserName,Domain,Address,Description
$serviceForHtml = $ServiceEvents | Where-Object { $_.Level -ne "正常" } | Select-Object Level,TimeCreated,ServiceName,ImagePath,AccountName,Reason
$startupForHtml = $SuspiciousStartup | Select-Object Level,Location,Name,Command,Signature,Reason
$taskForHtml = $SuspiciousTasks | Select-Object Level,TaskName,State,Actions,Reason
$portForHtml = $DangerPorts | Select-Object Level,LocalPort,LocalAddress,ServiceRisk,ProcessId,ProcessName,ProcessPath
$resourceForHtml = $ResourceAnomalies | Select-Object Level,Score,ProcessId,Name,CpuPercent,MemoryMB,MemoryPercent,PublicConnections,Tags,ExecutablePath,CommandLine
$netForHtml = $NetConns | Where-Object { $_.IsPublicIP -eq $true -and -not (Test-IsKnownPublicNetworkNoise -ProcessName $_.ProcessName -ProcessPath $_.ProcessPath) } | Select-Object LocalAddress,LocalPort,RemoteAddress,RemotePort,State,ProcessId,ProcessName,ProcessPath
$publicNetAggForHtml = $netForHtml | Group-Object ProcessName,ProcessId,ProcessPath | Sort-Object Count -Descending | ForEach-Object {
    $items = @($_.Group)
    $first = $items | Select-Object -First 1
    [PSCustomObject]@{
        ProcessName       = $first.ProcessName
        ProcessId         = $first.ProcessId
        ConnectionCount   = $_.Count
        RemoteIpCount     = @($items.RemoteAddress | Sort-Object -Unique).Count
        RemotePorts       = (($items.RemotePort | Sort-Object -Unique | Select-Object -First 12) -join ',')
        States            = (($items.State | Sort-Object -Unique) -join ',')
        ProcessPath       = $first.ProcessPath
    }
}
$eventLogProbeForHtml = @()
try { $eventLogProbeForHtml = @($script:EventLogProbeCache.Values | Select-Object LogName,Mode,Status,IsEnabled,RecordCount,LatestEventTime,LatestEventId,Message) } catch {}
$eventLogQueryForHtml = @()
try { $eventLogQueryForHtml = @($script:EventLogQuerySummary | Select-Object LogName,Label,Method,Ids,Count,Status,Message) } catch {}
$eventReadIssueForHtml = @()
try { $eventReadIssueForHtml = @($script:EventLogReadIssues | Select-Object TimeCreated,LogName,Stage,Message) } catch {}
$miningConfigForHtml = $MiningConfigsGroupedArray | Select-Object Type,Value,Confidence,HitCount,SourceFiles,SourceDirs,Context
$miningCandidateForHtml = $MiningCandidateSourcesArray | Select-Object SourceType,EvidenceName,Value,Reason,AddedDir
$psForHtml = $PowerShellFindings | Select-Object TimeCreated,EventID,Summary
$timelineForHtml = $AttackTimelineArray | Select-Object EvidenceId,TimeCreated,Phase,Action,Level,EvidenceType,Source,Target,TechniqueId,TechniqueName,Tactic,Evidence,Suggestion
$attackForHtml = $AttackTechniques | Select-Object Tactic,TechniqueId,TechniqueName,Count,EvidenceIds,ExampleEvidence,Suggestion
$chainForHtml = $EvidenceChain | Select-Object EvidenceId,TimeCreated,Phase,Brief,Source,Target

$ReportPath = Join-Path $OutputDir "WinIR_Report.html"

$css = @"
<style>
body { margin:0; padding:0; background:#0f172a; color:#e5e7eb; font-family:"Microsoft YaHei","Segoe UI",Arial,sans-serif; }
.container { max-width:1320px; margin:0 auto; padding:28px; }
.header { background:linear-gradient(135deg,#1e293b,#0f766e); border-radius:18px; padding:28px; box-shadow:0 10px 30px rgba(0,0,0,.25); }
.header h1 { margin:0 0 10px 0; font-size:30px; }
.header p { margin:4px 0; color:#d1fae5; }
.cards { display:grid; grid-template-columns:repeat(4,minmax(0,1fr)); gap:16px; margin:22px 0; }
.card { background:#111827; border:1px solid #334155; border-radius:16px; padding:18px; }
.card .num { font-size:30px; font-weight:700; }
.card .label { color:#94a3b8; margin-top:6px; }
.high { color:#f87171; } .mid { color:#fbbf24; } .watch { color:#60a5fa; } .ok { color:#34d399; }
.section { margin-top:22px; background:#111827; border:1px solid #334155; border-radius:16px; padding:20px; overflow-x:auto; }
.section h2 { margin-top:0; color:#93c5fd; border-bottom:1px solid #334155; padding-bottom:10px; }
table { width:100%; border-collapse:collapse; font-size:13px; }
th,td { border-bottom:1px solid #334155; padding:8px 10px; text-align:left; vertical-align:top; }
th { color:#bfdbfe; background:#1f2937; white-space:nowrap; }
td { color:#e5e7eb; word-break:break-all; }
.badge { display:inline-block; padding:3px 8px; border-radius:999px; font-size:12px; font-weight:700; white-space:nowrap; }
.badge-high { background:rgba(248,113,113,.15); color:#f87171; }
.badge-mid { background:rgba(251,191,36,.15); color:#fbbf24; }
.badge-watch { background:rgba(96,165,250,.15); color:#60a5fa; }
.empty { color:#94a3b8; }
.footer { color:#94a3b8; margin-top:22px; font-size:13px; }
code { color:#a7f3d0; }
.hash-toolbar { display:flex; flex-wrap:wrap; gap:10px; align-items:center; margin:12px 0 14px 0; }
.hash-file { background:#0f172a; border:1px dashed #475569; border-radius:12px; padding:10px; color:#e5e7eb; min-width:280px; }
.hash-options { display:flex; flex-wrap:wrap; gap:10px; color:#cbd5e1; }
.hash-options label { background:#0f172a; border:1px solid #334155; border-radius:999px; padding:7px 10px; cursor:pointer; }
.hash-btn { border:0; border-radius:12px; padding:10px 14px; background:#2563eb; color:white; cursor:pointer; font-weight:700; }
.hash-btn.secondary { background:#334155; }
.hash-btn:disabled { opacity:.55; cursor:not-allowed; }
.hash-note { color:#a7f3d0; background:rgba(20,184,166,.08); border:1px solid rgba(45,212,191,.25); border-radius:12px; padding:10px 12px; }
.hash-status { color:#bfdbfe; margin:8px 0; }
.hash-actions { display:flex; gap:8px; flex-wrap:wrap; }
.hash-actions button { border:1px solid #475569; background:#0f172a; color:#dbeafe; border-radius:10px; padding:6px 8px; cursor:pointer; }
.hash-small { color:#94a3b8; font-size:12px; }
</style>
"@

$hashToolHtml = @'
    <div class="section" id="offline-hash-tool">
        <h2>零、离线文件 Hash 计算器</h2>
        <p class="hash-note">选择本地文件后，Hash 在当前浏览器中离线计算，文件不会上传到服务器，也不会写入报告目录。适合快速计算样本 Hash 后复制到 VirusTotal、微步、EDR 或情报平台中检索。</p>

        <div class="hash-toolbar">
            <input class="hash-file" id="hashFiles" type="file" multiple />
            <div class="hash-options" aria-label="Hash 算法选择">
                <label><input type="checkbox" name="hashAlgo" value="SHA-1" checked /> SHA-1</label>
                <label><input type="checkbox" name="hashAlgo" value="SHA-256" checked /> SHA-256</label>
                <label><input type="checkbox" name="hashAlgo" value="SHA-384" /> SHA-384</label>
                <label><input type="checkbox" name="hashAlgo" value="SHA-512" /> SHA-512</label>
            </div>
            <button class="hash-btn" id="hashCalcBtn" type="button">开始计算</button>
            <button class="hash-btn secondary" id="hashClearBtn" type="button">清空结果</button>
            <button class="hash-btn secondary" id="hashCsvBtn" type="button" disabled>导出 CSV</button>
        </div>

        <div class="hash-small">说明：浏览器原生 Web Crypto API 不支持 MD5。应急检索建议优先使用 SHA-256；如确需 MD5，可在 PowerShell 中使用 <code>Get-FileHash -Algorithm MD5</code>。</div>
        <div class="hash-status" id="hashStatus">尚未选择文件。</div>
        <div id="hashResultWrap"><p class="empty">计算结果会显示在这里。</p></div>
    </div>

    <script>
    (function () {
        var hashRows = [];
        var fileInput = document.getElementById('hashFiles');
        var calcBtn = document.getElementById('hashCalcBtn');
        var clearBtn = document.getElementById('hashClearBtn');
        var csvBtn = document.getElementById('hashCsvBtn');
        var statusBox = document.getElementById('hashStatus');
        var resultWrap = document.getElementById('hashResultWrap');

        function escapeHtml(value) {
            return String(value == null ? '' : value)
                .replace(/&/g, '&amp;')
                .replace(/</g, '&lt;')
                .replace(/>/g, '&gt;')
                .replace(/"/g, '&quot;')
                .replace(/'/g, '&#39;');
        }

        function bytesToHex(buffer) {
            var bytes = new Uint8Array(buffer);
            var hex = [];
            for (var i = 0; i < bytes.length; i++) {
                hex.push(bytes[i].toString(16).padStart(2, '0'));
            }
            return hex.join('');
        }

        function formatBytes(bytes) {
            if (bytes === 0) return '0 B';
            var units = ['B', 'KB', 'MB', 'GB', 'TB'];
            var i = Math.floor(Math.log(bytes) / Math.log(1024));
            if (i < 0) i = 0;
            if (i >= units.length) i = units.length - 1;
            return (bytes / Math.pow(1024, i)).toFixed(i === 0 ? 0 : 2) + ' ' + units[i];
        }

        function getSelectedAlgorithms() {
            var checked = document.querySelectorAll('input[name="hashAlgo"]:checked');
            var arr = [];
            for (var i = 0; i < checked.length; i++) arr.push(checked[i].value);
            return arr;
        }

        function setBusy(isBusy) {
            calcBtn.disabled = isBusy;
            clearBtn.disabled = isBusy;
            csvBtn.disabled = isBusy || hashRows.length === 0;
        }

        async function calculateHashes() {
            if (!window.crypto || !window.crypto.subtle) {
                statusBox.textContent = '当前浏览器不支持 crypto.subtle。建议使用新版 Edge、Chrome 或 Firefox 打开本报告。';
                return;
            }

            var files = fileInput.files;
            var algorithms = getSelectedAlgorithms();

            if (!files || files.length === 0) {
                statusBox.textContent = '请先选择一个或多个文件。';
                return;
            }
            if (algorithms.length === 0) {
                statusBox.textContent = '请至少选择一种 Hash 算法。';
                return;
            }

            hashRows = [];
            resultWrap.innerHTML = '<p class="empty">正在计算，请勿关闭页面。大文件需要更多时间。</p>';
            setBusy(true);

            try {
                for (var f = 0; f < files.length; f++) {
                    var file = files[f];
                    statusBox.textContent = '正在读取：' + file.name + '（' + (f + 1) + '/' + files.length + '）';
                    var buffer = await file.arrayBuffer();

                    for (var a = 0; a < algorithms.length; a++) {
                        var algo = algorithms[a];
                        statusBox.textContent = '正在计算：' + file.name + ' / ' + algo;
                        var digest = await crypto.subtle.digest(algo, buffer);
                        var lower = bytesToHex(digest);
                        hashRows.push({
                            fileName: file.name,
                            fileSizeBytes: file.size,
                            fileSize: formatBytes(file.size),
                            lastModified: file.lastModified ? new Date(file.lastModified).toLocaleString() : '',
                            algorithm: algo,
                            hashUpper: lower.toUpperCase(),
                            hashLower: lower.toLowerCase()
                        });
                    }
                }
                statusBox.textContent = '计算完成：' + files.length + ' 个文件，' + hashRows.length + ' 条 Hash 结果。';
                renderTable();
            } catch (err) {
                statusBox.textContent = '计算失败：' + (err && err.message ? err.message : err);
                resultWrap.innerHTML = '<p class="empty">计算失败，请更换浏览器或减少单次选择的大文件数量后重试。</p>';
            } finally {
                setBusy(false);
            }
        }

        function renderTable() {
            if (hashRows.length === 0) {
                resultWrap.innerHTML = '<p class="empty">暂无计算结果。</p>';
                csvBtn.disabled = true;
                return;
            }

            var html = '<table><thead><tr>' +
                '<th>文件名</th><th>大小</th><th>修改时间</th><th>算法</th><th>Hash 大写</th><th>hash 小写</th><th>操作</th>' +
                '</tr></thead><tbody>';

            for (var i = 0; i < hashRows.length; i++) {
                var r = hashRows[i];
                html += '<tr>' +
                    '<td>' + escapeHtml(r.fileName) + '</td>' +
                    '<td>' + escapeHtml(r.fileSize) + '</td>' +
                    '<td>' + escapeHtml(r.lastModified) + '</td>' +
                    '<td>' + escapeHtml(r.algorithm) + '</td>' +
                    '<td><code>' + escapeHtml(r.hashUpper) + '</code></td>' +
                    '<td><code>' + escapeHtml(r.hashLower) + '</code></td>' +
                    '<td><div class="hash-actions">' +
                    '<button type="button" data-copy="upper" data-index="' + i + '">复制大写</button>' +
                    '<button type="button" data-copy="lower" data-index="' + i + '">复制小写</button>' +
                    '</div></td>' +
                    '</tr>';
            }

            html += '</tbody></table>';
            resultWrap.innerHTML = html;
            csvBtn.disabled = false;
        }

        function copyText(text) {
            if (navigator.clipboard && navigator.clipboard.writeText) {
                navigator.clipboard.writeText(text).then(function () {
                    statusBox.textContent = '已复制到剪贴板。';
                }).catch(function () {
                    fallbackCopy(text);
                });
            } else {
                fallbackCopy(text);
            }
        }

        function fallbackCopy(text) {
            var ta = document.createElement('textarea');
            ta.value = text;
            document.body.appendChild(ta);
            ta.select();
            try {
                document.execCommand('copy');
                statusBox.textContent = '已复制到剪贴板。';
            } catch (e) {
                statusBox.textContent = '复制失败，请手动选中 Hash 复制。';
            }
            document.body.removeChild(ta);
        }

        function toCsvCell(value) {
            return '"' + String(value == null ? '' : value).replace(/"/g, '""') + '"';
        }

        function exportCsv() {
            if (hashRows.length === 0) return;
            var lines = [];
            lines.push(['FileName', 'FileSizeBytes', 'FileSize', 'LastModified', 'Algorithm', 'HashUpper', 'HashLower'].map(toCsvCell).join(','));
            for (var i = 0; i < hashRows.length; i++) {
                var r = hashRows[i];
                lines.push([r.fileName, r.fileSizeBytes, r.fileSize, r.lastModified, r.algorithm, r.hashUpper, r.hashLower].map(toCsvCell).join(','));
            }
            var blob = new Blob(['\ufeff' + lines.join('\r\n')], { type: 'text/csv;charset=utf-8' });
            var url = URL.createObjectURL(blob);
            var a = document.createElement('a');
            a.href = url;
            a.download = 'WinIR_Offline_File_Hash.csv';
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
            statusBox.textContent = 'CSV 已导出。';
        }

        calcBtn.addEventListener('click', calculateHashes);
        clearBtn.addEventListener('click', function () {
            hashRows = [];
            fileInput.value = '';
            statusBox.textContent = '已清空结果。';
            resultWrap.innerHTML = '<p class="empty">计算结果会显示在这里。</p>';
            csvBtn.disabled = true;
        });
        csvBtn.addEventListener('click', exportCsv);
        resultWrap.addEventListener('click', function (event) {
            var target = event.target;
            if (!target || !target.getAttribute) return;
            var mode = target.getAttribute('data-copy');
            var index = parseInt(target.getAttribute('data-index'), 10);
            if (!mode || isNaN(index) || !hashRows[index]) return;
            copyText(mode === 'upper' ? hashRows[index].hashUpper : hashRows[index].hashLower);
        });
    })();
    </script>
'@

$html = @"
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8" />
<title>WinIR-Helper $Version 应急响应报告</title>
$css
</head>
<body>
<div class="container">
    <div class="header">
        <h1>WinIR-Helper $Version 应急响应报告</h1>
        <p>生成时间：$(HtmlEncode (Get-Date))</p>
        <p>扫描范围：$(HtmlEncode $StartTime) ~ $(HtmlEncode $EndTime)</p>
        <p>重点排查窗口：$(HtmlEncode $FocusStartTime) ~ $(HtmlEncode $EndTime)</p>
        <p>说明：默认扫描最近 7 天，重点关注最近 3 天；如需长周期历史排查，可使用 <code>-Days 1000</code>。</p>
        <p>工具定位：辅助取证与线索整理，不做查杀，不替代专业安全工具。</p>
        <p>v0.8 说明：主脚本只负责装配流程，采集、分析、评分、报告导出已拆分到 modules 目录。</p>
        <p>v0.8.8 说明：将“无匹配事件”与“读取失败”分开处理；Hyper-V/WSL/Docker 虚拟化网络组件默认降噪；系统驱动服务不再直接生成禁用建议。</p>
    </div>

    <div class="cards">
        <div class="card"><div class="num high">$HighCount</div><div class="label">威胁高危项</div></div>
        <div class="card"><div class="num mid">$MidCount</div><div class="label">威胁中危项</div></div>
        <div class="card"><div class="num watch">$ExposureCount</div><div class="label">暴露面风险</div></div>
        <div class="card"><div class="num $DataIntegrityClass">$DataIntegrityStatus</div><div class="label">数据完整性</div></div>
    </div>

$hashToolHtml

    <div class="section">
        <h2>零-补充、数据完整性与事件日志读取状态</h2>
        <p class="empty">$DataIntegrityMessage 当前事件读取模式：$(HtmlEncode $EventReadMode)。如果 Security 事件异常为 0，请优先看本节，而不是直接把“无事件”理解为“安全”。</p>
        <h3 style="color:#bfdbfe; margin-top:18px;">日志通道探测</h3>
        $(ConvertTo-HtmlTable -Data $eventLogProbeForHtml -MaxRows 20)
        <h3 style="color:#bfdbfe; margin-top:18px;">事件查询过程</h3>
        $(ConvertTo-HtmlTable -Data $eventLogQueryForHtml -MaxRows 50)
        <h3 style="color:#bfdbfe; margin-top:18px;">读取异常</h3>
        $(ConvertTo-HtmlTable -Data $eventReadIssueForHtml -MaxRows 30)
    </div>

    <div class="section">
        <h2>一、攻击场景判断</h2>
        $(ConvertTo-HtmlTable -Data $scenarioForHtml -MaxRows 50)
    </div>

    <div class="section">
        <h2>一-补充、v0.7 证据链评分与处置建议</h2>
        <p class="empty">本节为 v0.7 新增能力。评分用于帮助判断处置优先级，不会自动执行清理命令；所有建议命令均需人工复核后再使用。</p>
        <h3 style="color:#bfdbfe; margin-top:18px;">证据链评分</h3>
        $(ConvertTo-HtmlTable -Data $evidenceScoreForHtml -MaxRows 30)
        <h3 style="color:#bfdbfe; margin-top:18px;">处置建议生成器</h3>
        $(ConvertTo-HtmlTable -Data $cleanupAdviceForHtml -MaxRows 100)
        <h3 style="color:#bfdbfe; margin-top:18px;">高危文件 Hash 建议</h3>
        $(ConvertTo-HtmlTable -Data $hashTargetsForHtml -MaxRows 50)
    </div>

    <div class="section">
        <h2>二、重点关注项（近 $FocusDays 天事件 + 当前持久化/进程/配置痕迹）</h2>
        $(ConvertTo-HtmlTable -Data $findingsForHtml -MaxRows 100)
    </div>

    <div class="section">
        <h2>三、Windows 安全事件统计</h2>
        $(ConvertTo-HtmlTable -Data $securityForHtml -MaxRows 30)
    </div>

    <div class="section">
        <h2>三-补充、账户与恶意用户排查</h2>
        <p class="empty">本节显式展示本地用户、管理员组、远程桌面用户组、Winlogon 隐藏账户和账户相关安全事件。可疑账户会综合用户名、隐藏注册表、管理员组、远程桌面组、密码策略等特征打分。</p>

        <h3 style="color:#bfdbfe; margin-top:18px;">可疑本地账户</h3>
        $(ConvertTo-HtmlTable -Data $suspiciousUsersForHtml -MaxRows 80)

        <h3 style="color:#bfdbfe; margin-top:18px;">Winlogon 隐藏账户</h3>
        $(ConvertTo-HtmlTable -Data $hiddenAccountsForHtml -MaxRows 50)

        <h3 style="color:#bfdbfe; margin-top:18px;">管理员组成员</h3>
        $(ConvertTo-HtmlTable -Data $adminMembersForHtml -MaxRows 80)

        <h3 style="color:#bfdbfe; margin-top:18px;">远程桌面用户组成员</h3>
        $(ConvertTo-HtmlTable -Data $rdpMembersForHtml -MaxRows 80)

        <h3 style="color:#bfdbfe; margin-top:18px;">本地用户列表</h3>
        $(ConvertTo-HtmlTable -Data $localUsersForHtml -MaxRows 120)

        <h3 style="color:#bfdbfe; margin-top:18px;">账户相关安全事件</h3>
        $(ConvertTo-HtmlTable -Data $accountEventsForHtml -MaxRows 120)
    </div>

    <div class="section">
        <h2>四、登录失败来源 IP Top（含疑似攻击开始时间）</h2>
        $(ConvertTo-HtmlTable -Data $failedForHtml -MaxRows 50)
    </div>

    <div class="section">
        <h2>四-补充、登录失败明细 / 无 IP 聚合</h2>
        <p class="empty">部分 4625 事件可能没有来源 IP。本节按来源、用户和登录类型聚合，便于识别本机 IPC$、内网或字段缺失导致的失败登录。</p>
        $(ConvertTo-HtmlTable -Data $failedIdentityForHtml -MaxRows 50)
        <h3 style="color:#bfdbfe; margin-top:18px;">登录失败明细</h3>
        $(ConvertTo-HtmlTable -Data $failedDetailsForHtml -MaxRows 80)
    </div>

    <div class="section">
        <h2>五、RDP 相关事件</h2>
        $(ConvertTo-HtmlTable -Data $rdpForHtml -MaxRows 50)
    </div>

    <div class="section">
        <h2>六、危险监听端口</h2>
        <p class="empty">监听不等于公网可访问，需要结合 Windows 防火墙、云安全组、NAT/端口映射判断。</p>
        $(ConvertTo-HtmlTable -Data $portForHtml -MaxRows 50)
    </div>

    <div class="section">
        <h2>七、资源异常进程综合评分（已过滤低占用噪音）</h2>
        $(ConvertTo-HtmlTable -Data $resourceForHtml -MaxRows 50)
    </div>

    <div class="section">
        <h2>八、挖矿配置提取（矿池 / 钱包，按 Value 聚合）</h2>
        <p class="empty">该模块不做全盘深度扫描。v0.6.5 在 v0.6.4 的对抗样本覆盖基础上，继续优化 OneDrive/desktop.ini 降噪、WinIR 自身 PowerShell 噪音过滤、IOC 类型拆分、协议与 host:port 归一化去重，并增强 Startup LNK、ADS、Public 镜像目录与自定义认证日志关联。当前表格按 Value 聚合，HitCount 表示同一线索在多少处出现。</p>
        $(ConvertTo-HtmlTable -Data $miningConfigForHtml -MaxRows 80)
    </div>

    <div class="section">
        <h2>八-补充、挖矿配置扫描目录来源</h2>
        <p class="empty">用于解释为什么某个目录会被继续扫描，便于复核'资源异常 → 目录追踪 → 配置提取'的证据链。</p>
        $(ConvertTo-HtmlTable -Data $miningCandidateForHtml -MaxRows 80)
    </div>

    <div class="section">
        <h2>九、服务安装线索</h2>
        $(ConvertTo-HtmlTable -Data $serviceForHtml -MaxRows 80)
    </div>

    <div class="section">
        <h2>十、可疑启动项</h2>
        $(ConvertTo-HtmlTable -Data $startupForHtml -MaxRows 50)
    </div>

    <div class="section">
        <h2>十一、可疑计划任务</h2>
        $(ConvertTo-HtmlTable -Data $taskForHtml -MaxRows 50)
    </div>

    <div class="section">
        <h2>十二、公网网络连接（已降噪）</h2>
        <p class="empty">v0.8.5 默认先按进程聚合公网连接，避免代理、微信、浏览器等连接刷屏。详细连接仍在下方保留少量预览，完整明细可用 -ExportDetails 导出 CSV。</p>
        <h3 style="color:#bfdbfe; margin-top:18px;">公网连接进程聚合</h3>
        $(ConvertTo-HtmlTable -Data $publicNetAggForHtml -MaxRows 30)
        <h3 style="color:#bfdbfe; margin-top:18px;">公网连接明细预览</h3>
        $(ConvertTo-HtmlTable -Data $netForHtml -MaxRows 30)
    </div>

    <div class="section">
        <h2>十三、PowerShell 高危痕迹</h2>
        $(ConvertTo-HtmlTable -Data $psForHtml -MaxRows 50)
    </div>

    <div class="section">
        <h2>十四、攻击时间线（v0.6）</h2>
        <p class="empty">将登录失败、RDP、PowerShell、服务安装、计划任务、启动项、资源异常、挖矿配置等线索按时间顺序整理，并生成 EvidenceId，便于复盘攻击过程。</p>
        $(ConvertTo-HtmlTable -Data $timelineForHtml -MaxRows 120)
    </div>

    <div class="section">
        <h2>十五、MITRE ATT&CK 映射（v0.6）</h2>
        <p class="empty">将本次命中的行为映射到常见 ATT&CK 技术。映射用于辅助报告标准化，不代表最终定性。</p>
        $(ConvertTo-HtmlTable -Data $attackForHtml -MaxRows 80)
    </div>

    <div class="section">
        <h2>十六、证据链概览</h2>
        <p class="empty">按 EvidenceId 串联关键证据，可作为后续人工复核和报告写作的骨架。</p>
        $(ConvertTo-HtmlTable -Data $chainForHtml -MaxRows 120)
    </div>

    <div class="section">
        <h2>十七、处置建议</h2>
        <ol>
            <li>优先查看「攻击场景判断」，不要只看单条事件。</li>
            <li>RDP 判断需要结合 4625/4624、1149/21/25、3389 监听和来源 IP 是否一致。</li>
            <li>挖矿判断需要结合资源占用、路径、服务、计划任务、启动项、矿池/钱包配置和 Hash。</li>
            <li>启动项中 AppData/Public/Temp/ProgramData 下的 bat、ps1、vbs、exe 应重点复核。</li>
            <li>本工具仅做辅助线索整理，最终结论需要人工复核。</li>
        </ol>
    </div>

    <div class="footer">
        <p>报告文件：$(HtmlEncode $ReportPath)</p>
        <p>本工具仅用于合法授权的蓝队应急响应、靶场复盘与安全学习。</p>
    </div>
</div>
</body>
</html>
"@

$html | Out-File -FilePath $ReportPath -Encoding UTF8

Write-Host ""
Write-Ok "分析完成！"
Write-Host ""
Write-Host "优先查看：" -ForegroundColor Cyan
Write-Host "1. $ReportPath"
Write-Host "2. $SummaryPath"
Write-Host "3. $ScenarioPath"
Write-Host "4. $FindingPath"
Write-Host ""

try { Start-Process $ReportPath } catch {}
