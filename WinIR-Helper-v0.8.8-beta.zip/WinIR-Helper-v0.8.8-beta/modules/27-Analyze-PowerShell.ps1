﻿# WinIR-Helper v0.8.8-beta module: 27-Analyze-PowerShell.ps1
# This module is dot-sourced by WinIR-Helper.ps1.

# 模块 7：PowerShell 痕迹
# =========================================================

Write-Info "正在检查 PowerShell 高危痕迹..."

$PowerShellFindings = @()
$psEvents = Get-EventsById -LogName "Microsoft-Windows-PowerShell/Operational" -Ids @(4103,4104)

foreach ($evt in $psEvents) {
    $msg = $evt.Message
    if (Test-IsSelfToolText $msg) { continue }

    if ($msg -match $DangerCommandRegex) {
        $psLevel = "中危"
        $psReason = "命中 PowerShell 高危命令特征"
        $psSuggestion = "重点检查是否存在下载执行、编码命令、绕过策略、禁用防护、创建账户或添加管理员行为。"

        if (Test-IsAdminExecutionPolicyOnly $msg) {
            $psLevel = "关注"
            $psReason = "仅发现当前进程级 ExecutionPolicy Bypass，可能是管理员临时运行脚本"
            $psSuggestion = "若该记录与管理员运行 WinIR/测试脚本时间一致，可作为低优先级关注；若出现在未知时间段或伴随下载执行、编码命令、账户变更，应升级复核。"
        }

        $PowerShellFindings += [PSCustomObject]@{
            Level       = $psLevel
            TimeCreated = $evt.TimeCreated
            EventID     = $evt.Id
            RecordID    = $evt.RecordId
            Reason      = $psReason
            Summary     = $msg.Substring(0, [Math]::Min(400, $msg.Length))
        }

        Add-Finding -Level $psLevel -Category "PowerShell" -Title "PowerShell 事件日志命中高危命令特征" `
            -Evidence "时间=$($evt.TimeCreated)，EventID=$($evt.Id)，原因=$psReason，摘要=$($msg.Substring(0, [Math]::Min(300, $msg.Length)))" `
            -Suggestion $psSuggestion
    }
}

Export-DetailCsv -Name "PowerShell高危痕迹.csv" -Data $PowerShellFindings

# =========================================================
