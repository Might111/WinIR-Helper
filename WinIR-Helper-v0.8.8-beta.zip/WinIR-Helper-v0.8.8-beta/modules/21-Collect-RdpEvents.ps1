﻿# WinIR-Helper v0.8.8-beta module: 21-Collect-RdpEvents.ps1
# This module is dot-sourced by WinIR-Helper.ps1.

# =========================================================
# 模块 2：RDP 事件
# =========================================================

Write-Info "正在分析 RDP 相关事件..."

$RdpEvents = @()

$rdpRaw1 = Get-EventsById -LogName "Microsoft-Windows-TerminalServices-RemoteConnectionManager/Operational" -Ids @(1149)
$rdpRaw2 = Get-EventsById -LogName "Microsoft-Windows-TerminalServices-LocalSessionManager/Operational" -Ids @(21,24,25)

foreach ($evt in @($rdpRaw1 + $rdpRaw2)) {
    try {
        [xml]$xml = $evt.ToXml()
        $msg = $evt.Message

        $user = Get-EventDataValue -Xml $xml -Name "User"
        if (-not $user) { $user = Get-EventDataByIndex -Xml $xml -Index 0 }

        $domain = Get-EventDataValue -Xml $xml -Name "Domain"
        if (-not $domain) { $domain = Get-EventDataByIndex -Xml $xml -Index 1 }

        $addr = Get-EventDataValue -Xml $xml -Name "Address"
        if (-not $addr) { $addr = Get-EventDataValue -Xml $xml -Name "ClientAddress" }
        if (-not $addr) { $addr = Get-EventDataByIndex -Xml $xml -Index 2 }

        if ($msg -match "(\d{1,3}\.){3}\d{1,3}") {
            $addr = $matches[0]
        }

        $desc = switch ($evt.Id) {
            1149 { "RDP_Auth_Success" }
            21   { "RDP_Connect_Success" }
            24   { "RDP_Disconnect" }
            25   { "RDP_Reconnect_Success" }
            default { "RDP_Event" }
        }

        $RdpEvents += [PSCustomObject]@{
            TimeCreated = $evt.TimeCreated
            EventID     = $evt.Id
            UserName    = $user
            Domain      = $domain
            Address     = $addr
            Description = $desc
            Message     = $msg
        }
    }
    catch {}
}

Export-DetailCsv -Name "RDP事件.csv" -Data $RdpEvents

