﻿# WinIR-Helper v0.8.8-beta module: 01-EventParsing.ps1
# This module is dot-sourced by WinIR-Helper.ps1.

# =========================================================
# 事件解析函数
# =========================================================

function Get-EventDataValue {
    param(
        [xml]$Xml,
        [string]$Name
    )

    try {
        $node = $Xml.Event.EventData.Data | Where-Object { $_.Name -eq $Name } | Select-Object -First 1
        if ($null -eq $node) { return "" }
        return Safe-String $node.'#text'
    }
    catch { return "" }
}

function Get-EventDataByIndex {
    param(
        [xml]$Xml,
        [int]$Index
    )

    try {
        $data = @($Xml.Event.EventData.Data)
        if ($data.Count -gt $Index) {
            return Safe-String $data[$Index].'#text'
        }
    }
    catch {}
    return ""
}

function Get-EventMessageValue {
    param(
        [string]$Message,
        [string]$FieldName
    )

    if ([string]::IsNullOrWhiteSpace($Message)) { return "" }

    $pattern = [regex]::Escape($FieldName) + ":\s*(.+)"
    if ($Message -match $pattern) {
        return ($matches[1]).Trim()
    }
    return ""
}

function Get-LogonTypeDesc {
    param([string]$LogonType)

    switch ($LogonType) {
        "2"  { return "2-本地交互登录/控制台" }
        "3"  { return "3-网络登录/SMB、NTLM 或 RDP-NLA 认证阶段" }
        "4"  { return "4-批处理登录" }
        "5"  { return "5-服务登录" }
        "7"  { return "7-解锁登录" }
        "8"  { return "8-网络明文登录" }
        "9"  { return "9-新凭据登录/RunAs 或横向移动线索" }
        "10" { return "10-远程交互登录/RDP" }
        "11" { return "11-缓存交互登录" }
        default {
            if ([string]::IsNullOrWhiteSpace($LogonType)) { return "未知" }
            return "$LogonType-未知类型"
        }
    }
}

function Test-IsNoiseUser {
    param([string]$User)

    if ([string]::IsNullOrWhiteSpace($User)) { return $true }

    $u = $User.Trim()
    if ($u -in @("-","SYSTEM","LOCAL SERVICE","NETWORK SERVICE")) { return $true }
    if ($u -match "^DWM-\d+$") { return $true }
    if ($u -match "^UMFD-\d+$") { return $true }

    return $false
}

function Test-IsSelfToolText {
    param([string]$Text)

    if ([string]::IsNullOrWhiteSpace($Text)) { return $false }

    # v0.6.5-hotfix：修复自噪音正则字符串引号导致的 PowerShell 解析错误。
    # v0.6.2：过滤 WinIR 自身运行和报告生成造成的 4103/4104 噪音。
    # 只影响 PowerShell 事件展示与时间线，不影响进程、服务、计划任务、启动项和挖矿配置扫描。
    if ($Text -match '(?i)WinIR-Helper|WinIR_Output_|重点关注项\.csv|WinIR_Report\.html|WinIR_Summary\.txt|SuspiciousCmdRegex|MiningProcRegex|Cmdletization|Microsoft\.PowerShell\.Cmdletization|ConvertTo-HtmlTable|miningConfigForHtml|MiningCandidate|MiningConfigsGrouped|AttackTimeline|AttackTechnique|EvidenceChain|FailedByIP|failedDetailsForHtml|Get-DangerousPortInfo|ResourceAnomalies|resourceAbnormal|Export-DetailCsv|离线文件 Hash 计算器|Write-Ok\s+["'']?分析完成|分析完成！|优先查看：|\$ReportPath|\$SummaryPath|\$ScenarioPath|\$FindingPath|Set-Content\s+-Path\s+\$ReportPath|Start-Process\s+\$ReportPath|WinIR_Offline_File_Hash|hashCalcBtn|hashResultWrap') {
        return $true
    }

    return $false
}

function Test-IsAdminExecutionPolicyOnly {
    param([string]$Text)

    if ([string]::IsNullOrWhiteSpace($Text)) { return $false }

    # v0.6.3：单独 Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
    # 常见于管理员临时运行应急脚本。保留为关注项，但不再当作强攻击执行证据。
    $normalized = ($Text -replace "\s+", " ").Trim()

    if ($normalized -match "(?i)Set-ExecutionPolicy\s+-Scope\s+Process\s+-ExecutionPolicy\s+Bypass" -and
        $normalized -notmatch "(?i)downloadstring|downloadfile|frombase64string|-enc|-encodedcommand|invoke-expression|\biex\b|new-object\s+net\.webclient|certutil|bitsadmin|schtasks\s+/create|net\s+user|add-localgroupmember|set-mppreference|disableantispyware|http://|https://|stratum|xmrig|miner|c3pool") {
        return $true
    }

    return $false
}

function Test-EvtxFileMatchesLogName {
    param(
        [string]$FileName,
        [string]$LogName
    )

    $name = Safe-String $FileName
    $log  = Safe-String $LogName

    if ([string]::IsNullOrWhiteSpace($name) -or [string]::IsNullOrWhiteSpace($log)) { return $true }

    switch -Regex ($log) {
        '^Security$' { return ($name -match '(?i)^Security\.evtx$') }
        '^System$' { return ($name -match '(?i)^System\.evtx$') }
        'TerminalServices-RemoteConnectionManager' { return ($name -match '(?i)TerminalServices-RemoteConnectionManager') }
        'TerminalServices-LocalSessionManager' { return ($name -match '(?i)TerminalServices-LocalSessionManager') }
        'PowerShell' { return ($name -match '(?i)PowerShell') }
        default { return $true }
    }
}


function Register-EventLogReadIssue {
    param(
        [string]$LogName,
        [string]$Stage,
        [string]$Message
    )
    if ($null -eq $script:EventLogReadIssues) { $script:EventLogReadIssues = New-Object System.Collections.Generic.List[object] }
    $script:EventLogReadIssues.Add([PSCustomObject]@{
        TimeCreated = Get-Date
        LogName     = $LogName
        Stage       = $Stage
        Message     = $Message
    }) | Out-Null
}


function Test-IsNoMatchEventQueryMessage {
    param([string]$Message)
    if ([string]::IsNullOrWhiteSpace($Message)) { return $false }
    # Get-WinEvent -ErrorAction Stop throws when no event matches the filter.
    # That is a valid "no matching event" result, not a log-read failure.
    return ($Message -match "(?i)No events were found|No matching events|cannot find any events|找不到任何与指定的选择条件匹配的事件|没有与指定的选择条件匹配")
}

function Get-EventLogProbe {
    param([string]$LogName)

    if ($null -eq $script:EventLogProbeCache) { $script:EventLogProbeCache = @{} }
    if ($script:EventLogProbeCache.ContainsKey($LogName)) { return $script:EventLogProbeCache[$LogName] }

    $probe = [PSCustomObject]@{
        LogName          = $LogName
        Mode             = $script:RunMode
        Status           = "未知"
        IsEnabled        = ""
        RecordCount      = ""
        LatestEventTime  = ""
        LatestEventId    = ""
        Message          = ""
    }

    try {
        if ($script:RunMode -eq "Offline" -or -not [string]::IsNullOrWhiteSpace($LogFolder)) {
            if ([string]::IsNullOrWhiteSpace($LogFolder) -or -not (Test-Path $LogFolder)) {
                $probe.Status = "异常"
                $probe.Message = "离线日志目录不存在。"
            }
            else {
                $files = @(Get-ChildItem -Path $LogFolder -Recurse -File -Filter "*.evtx" -ErrorAction SilentlyContinue | Where-Object { Test-EvtxFileMatchesLogName -FileName $_.Name -LogName $LogName })
                $probe.Status = if ($files.Count -gt 0) { "可读取" } else { "未找到EVTX" }
                $probe.RecordCount = $files.Count
                $probe.Message = "匹配 EVTX 文件数=$($files.Count)"
            }
        }
        else {
            $logInfo = Get-WinEvent -ListLog $LogName -ErrorAction Stop
            $probe.IsEnabled = $logInfo.IsEnabled
            $probe.RecordCount = $logInfo.RecordCount
            $probe.Status = if ($logInfo.IsEnabled) { "可读取" } else { "日志未启用" }

            try {
                $latest = Get-WinEvent -LogName $LogName -MaxEvents 1 -ErrorAction Stop | Select-Object -First 1
                if ($latest) {
                    $probe.LatestEventTime = $latest.TimeCreated
                    $probe.LatestEventId = $latest.Id
                }
            } catch {}
        }
    }
    catch {
        $probe.Status = "异常"
        $probe.Message = $_.Exception.Message
        Register-EventLogReadIssue -LogName $LogName -Stage "Probe" -Message $_.Exception.Message
    }

    $script:EventLogProbeCache[$LogName] = $probe
    return $probe
}

function Add-EventLogQuerySummary {
    param(
        [string]$LogName,
        [string]$Label,
        [string]$Method,
        [string]$IdsText,
        [int]$Count,
        [string]$Status,
        [string]$Message
    )
    if ($null -eq $script:EventLogQuerySummary) { $script:EventLogQuerySummary = New-Object System.Collections.Generic.List[object] }
    $script:EventLogQuerySummary.Add([PSCustomObject]@{
        LogName = $LogName
        Label   = $Label
        Method  = $Method
        Ids     = $IdsText
        Count   = $Count
        Status  = $Status
        Message = $Message
    }) | Out-Null
}

function New-EventXPath {
    param(
        [int[]]$Ids,
        [datetime]$QueryStartTime,
        [datetime]$QueryEndTime
    )

    $idParts = @()
    foreach ($id in $Ids) { $idParts += "EventID=$id" }
    $idClause = if ($idParts.Count -gt 1) { "(" + ($idParts -join " or ") + ")" } else { $idParts[0] }
    $startUtc = $QueryStartTime.ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ss.fffZ")
    $endUtc   = $QueryEndTime.ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ss.fffZ")
    return "*[System[$idClause and TimeCreated[@SystemTime>='$startUtc' and @SystemTime<='$endUtc']]]"
}

function Invoke-EventQueryHashtable {
    param(
        [string]$LogName,
        [int[]]$Ids,
        [datetime]$QueryStartTime,
        [datetime]$QueryEndTime,
        [int]$MaxEvents
    )
    $filter = @{ LogName = $LogName; Id = $Ids; StartTime = $QueryStartTime; EndTime = $QueryEndTime }
    if ($MaxEvents -gt 0) { return @(Get-WinEvent -FilterHashtable $filter -MaxEvents $MaxEvents -ErrorAction Stop) }
    return @(Get-WinEvent -FilterHashtable $filter -ErrorAction Stop)
}

function Invoke-EventQueryXPath {
    param(
        [string]$LogName,
        [int[]]$Ids,
        [datetime]$QueryStartTime,
        [datetime]$QueryEndTime,
        [int]$MaxEvents
    )
    $xpath = New-EventXPath -Ids $Ids -QueryStartTime $QueryStartTime -QueryEndTime $QueryEndTime
    if ($MaxEvents -gt 0) { return @(Get-WinEvent -LogName $LogName -FilterXPath $xpath -MaxEvents $MaxEvents -ErrorAction Stop) }
    return @(Get-WinEvent -LogName $LogName -FilterXPath $xpath -ErrorAction Stop)
}

function Invoke-EventQueryRecentScan {
    param(
        [string]$LogName,
        [int[]]$Ids,
        [datetime]$QueryStartTime,
        [datetime]$QueryEndTime,
        [int]$MaxEvents
    )
    $scanLimit = $EventRecentScanMaxEvents
    if ($scanLimit -le 0) { $scanLimit = 50000 }
    if ($MaxEvents -gt 0) { $scanLimit = [Math]::Max($scanLimit, $MaxEvents) }
    $recent = @(Get-WinEvent -LogName $LogName -MaxEvents $scanLimit -ErrorAction Stop)
    $set = @{}
    foreach ($id in $Ids) { $set[[int]$id] = $true }
    $matched = @($recent | Where-Object { $set.ContainsKey([int]$_.Id) -and $_.TimeCreated -ge $QueryStartTime -and $_.TimeCreated -le $QueryEndTime })
    if ($MaxEvents -gt 0) { return @($matched | Select-Object -First $MaxEvents) }
    return $matched
}

function Get-EventsById {
    param(
        [string]$LogName,
        [int[]]$Ids,
        [datetime]$QueryStartTime = [datetime]::MinValue,
        [datetime]$QueryEndTime = [datetime]::MinValue,
        [int]$MaxEvents = 0,
        [string]$Label = ""
    )

    $all = @()
    $isOffline = ($script:RunMode -eq "Offline" -or -not [string]::IsNullOrWhiteSpace($LogFolder))

    if ($null -eq $Ids -or $Ids.Count -eq 0) { return $all }

    # v0.8.6：修复未显式传入 QueryStartTime / QueryEndTime 时，
    # 空值继续传给子查询函数导致 Hashtable / XPath / RecentScan 全部失败的问题。
    if ($null -eq $script:StartTime -or $script:StartTime -eq [datetime]::MinValue) {
        $script:StartTime = (Get-Date).AddDays(-1 * [Math]::Max(1, [int]$Days))
    }
    if ($null -eq $script:EndTime -or $script:EndTime -eq [datetime]::MinValue) {
        $script:EndTime = Get-Date
    }
    if ($null -eq $QueryStartTime -or $QueryStartTime -eq [datetime]::MinValue) { $QueryStartTime = $script:StartTime }
    if ($null -eq $QueryEndTime -or $QueryEndTime -eq [datetime]::MinValue) { $QueryEndTime = $script:EndTime }
    if ($QueryEndTime -lt $QueryStartTime) { return $all }

    $name = if ([string]::IsNullOrWhiteSpace($Label)) { $LogName } else { $Label }
    $idText = ($Ids -join ',')
    if ($idText.Length -gt 80) { $idText = $idText.Substring(0,80) + "..." }

    if ($MaxEvents -gt 0) { Write-Info "读取事件：$name，ID=$idText，最多 $MaxEvents 条。" }
    else { Write-Info "读取事件：$name，ID=$idText，全量时间窗口。" }

    if ($isOffline) {
        if ([string]::IsNullOrWhiteSpace($LogFolder) -or -not (Test-Path $LogFolder)) {
            Write-Warn "离线模式未找到有效 LogFolder：$LogFolder"
            Register-EventLogReadIssue -LogName $LogName -Stage "Offline" -Message "LogFolder 不存在或为空。"
            return $all
        }
        $evtxFiles = @(Get-ChildItem -Path $LogFolder -Recurse -File -Filter "*.evtx" -ErrorAction SilentlyContinue | Where-Object { Test-EvtxFileMatchesLogName -FileName $_.Name -LogName $LogName })
        foreach ($file in $evtxFiles) {
            try {
                $filter = @{ Path = $file.FullName; Id = $Ids; StartTime = $QueryStartTime; EndTime = $QueryEndTime }
                if ($MaxEvents -gt 0) { $events = @(Get-WinEvent -FilterHashtable $filter -MaxEvents $MaxEvents -ErrorAction Stop) }
                else { $events = @(Get-WinEvent -FilterHashtable $filter -ErrorAction Stop) }
                $all += $events
            }
            catch {
                Register-EventLogReadIssue -LogName $LogName -Stage "Offline:$($file.Name)" -Message $_.Exception.Message
            }
        }
        $offlineCount = @($all).Count
        $offlineStatus = if ($offlineCount -gt 0) { "完成" } else { "无匹配" }
        $offlineMessage = if ($offlineCount -gt 0) { "" } else { "离线日志可读取，但时间窗口内未命中指定事件。" }
        Add-EventLogQuerySummary -LogName $LogName -Label $name -Method "OfflineHashtable" -IdsText $idText -Count $offlineCount -Status $offlineStatus -Message $offlineMessage
    }
    else {
        $probe = Get-EventLogProbe -LogName $LogName
        $mode = if ([string]::IsNullOrWhiteSpace($EventReadMode)) { "Auto" } else { $EventReadMode }
        $methods = @()
        switch ($mode) {
            "Hashtable" { $methods = @("Hashtable") }
            "XPath" { $methods = @("XPath") }
            "RecentScan" { $methods = @("RecentScan") }
            default { $methods = @("Hashtable","XPath","RecentScan") }
        }

        foreach ($method in $methods) {
            if (@($all).Count -gt 0) { break }
            try {
                if ($method -eq "Hashtable") { $all = @(Invoke-EventQueryHashtable -LogName $LogName -Ids $Ids -QueryStartTime $QueryStartTime -QueryEndTime $QueryEndTime -MaxEvents $MaxEvents) }
                elseif ($method -eq "XPath") { $all = @(Invoke-EventQueryXPath -LogName $LogName -Ids $Ids -QueryStartTime $QueryStartTime -QueryEndTime $QueryEndTime -MaxEvents $MaxEvents) }
                elseif ($method -eq "RecentScan") { $all = @(Invoke-EventQueryRecentScan -LogName $LogName -Ids $Ids -QueryStartTime $QueryStartTime -QueryEndTime $QueryEndTime -MaxEvents $MaxEvents) }

                $resultCount = @($all).Count
                $queryStatus = if ($resultCount -gt 0) { "完成" } else { "无匹配" }
                $queryMessage = if ($resultCount -gt 0) { "" } else { "日志可读取，但时间窗口内未命中指定事件。" }
                Add-EventLogQuerySummary -LogName $LogName -Label $name -Method $method -IdsText $idText -Count $resultCount -Status $queryStatus -Message $queryMessage
                if ($resultCount -eq 0 -and $mode -eq "Auto" -and $method -ne "RecentScan") {
                    $probeRecordCount = 0
                    try { $probeRecordCount = [int64]$probe.RecordCount } catch { $probeRecordCount = 0 }
                    if ($probe.Status -eq "可读取" -and $probeRecordCount -gt 0) {
                        Write-Info "$name 使用 $method 未命中事件，结果记为无匹配。"
                    }
                    break
                }
            }
            catch {
                $msg = $_.Exception.Message
                if (Test-IsNoMatchEventQueryMessage -Message $msg) {
                    Add-EventLogQuerySummary -LogName $LogName -Label $name -Method $method -IdsText $idText -Count 0 -Status "无匹配" -Message "日志可读取，但时间窗口内未命中指定事件。"
                    if ($mode -eq "Auto") { break }
                }
                else {
                    Add-EventLogQuerySummary -LogName $LogName -Label $name -Method $method -IdsText $idText -Count 0 -Status "失败" -Message $msg
                    Register-EventLogReadIssue -LogName $LogName -Stage $method -Message $msg
                    if ($mode -ne "Auto") { break }
                }
            }
        }
    }

    $count = @($all).Count
    if ($count -gt 0) {
        $all = @($all | Sort-Object TimeCreated -Descending)
    }
    Write-Info "完成读取：$name，共 $count 条。"
    return $all
}

function Get-SecurityEventsFast {
    param([int]$MaxTotalEvents = 30000)

    if ($MaxTotalEvents -le 0) { $MaxTotalEvents = 30000 }

    $plan = @(
        [PSCustomObject]@{ Name = "账户/组/策略/任务关键事件"; Ids = @(1102,4720,4722,4723,4724,4725,4726,4728,4729,4732,4733,4738,4739,4740,4698,4702); Limit = [Math]::Min(6000, [Math]::Max(1000, [int]($MaxTotalEvents * 0.20))) },
        [PSCustomObject]@{ Name = "登录失败 4625"; Ids = @(4625); Limit = [Math]::Min(9000, [Math]::Max(2000, [int]($MaxTotalEvents * 0.30))) },
        [PSCustomObject]@{ Name = "登录成功 4624"; Ids = @(4624); Limit = [Math]::Min(9000, [Math]::Max(2000, [int]($MaxTotalEvents * 0.30))) },
        [PSCustomObject]@{ Name = "显式凭据/特权登录 4648/4672"; Ids = @(4648,4672); Limit = [Math]::Min(4000, [Math]::Max(1000, [int]($MaxTotalEvents * 0.12))) },
        [PSCustomObject]@{ Name = "进程创建 4688"; Ids = @(4688); Limit = [Math]::Min(2500, [Math]::Max(500, [int]($MaxTotalEvents * 0.08))) },
        [PSCustomObject]@{ Name = "账户注销 4634"; Ids = @(4634); Limit = [Math]::Min(1500, [Math]::Max(300, [int]($MaxTotalEvents * 0.05))) }
    )

    $raw = @()
    foreach ($item in $plan) {
        $remaining = $MaxTotalEvents - @($raw).Count
        if ($remaining -le 0) { break }
        $limit = [Math]::Min([int]$item.Limit, $remaining)
        $raw += @(Get-EventsById -LogName "Security" -Ids $item.Ids -MaxEvents $limit -Label $item.Name)
    }

    $dedup = @($raw | Sort-Object RecordId -Descending -Unique)
    if ($dedup.Count -ge $MaxTotalEvents) {
        Write-Warn "安全事件已达到快速模式上限 $MaxTotalEvents 条。报告会优先覆盖最近事件；如需完整日志，请使用 -SecurityProfile Full 或缩短 -Days。"
    }

    if ($dedup.Count -eq 0) {
        $probe = Get-EventLogProbe -LogName "Security"
        $probeRecordCount = 0
        try { $probeRecordCount = [int64]$probe.RecordCount } catch { $probeRecordCount = 0 }
        if ($probe.Status -eq "可读取" -and $probeRecordCount -gt 0) {
            Write-Warn "Security 日志可读取且存在记录，但本次关注事件全部为 0。请在报告的数据完整性中查看原因；可尝试 -EventReadMode RecentScan 或检查审计策略。"
        }
    }
    return $dedup
}
