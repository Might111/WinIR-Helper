﻿# WinIR-Helper v0.8.8-beta module: 00-Core.ps1
# This module is dot-sourced by WinIR-Helper.ps1.

# =========================================================
# 基础函数
# =========================================================

function Write-Info { param([string]$Message) Write-Host "[*] $Message" -ForegroundColor Cyan }
function Write-Ok   { param([string]$Message) Write-Host "[+] $Message" -ForegroundColor Green }
function Write-Warn { param([string]$Message) Write-Host "[!] $Message" -ForegroundColor Yellow }

function Test-IsAdmin {
    try {
        $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
        $principal = New-Object Security.Principal.WindowsPrincipal($identity)
        return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    }
    catch { return $false }
}

function Safe-String {
    param($Value)
    if ($null -eq $Value) { return "" }
    return ([string]$Value).Trim()
}

function HtmlEncode {
    param($Value)
    if ($null -eq $Value) { return "" }
    return [System.Net.WebUtility]::HtmlEncode([string]$Value)
}


function Add-Finding {
    param(
        [string]$Level,
        [string]$Category,
        [string]$Title,
        [string]$Evidence,
        [string]$Suggestion
    )

    $script:Findings.Add([PSCustomObject]@{
        Level      = $Level
        Category   = $Category
        Title      = $Title
        Evidence   = $Evidence
        Suggestion = $Suggestion
    }) | Out-Null
}

function Add-Scenario {
    param(
        [string]$Level,
        [string]$Scenario,
        [string]$Conclusion,
        [string]$Evidence,
        [string]$Suggestion
    )

    $script:Scenarios.Add([PSCustomObject]@{
        Level      = $Level
        Scenario   = $Scenario
        Conclusion = $Conclusion
        Evidence   = $Evidence
        Suggestion = $Suggestion
    }) | Out-Null
}

function Get-SHA256Safe {
    param([string]$Path)

    if ($NoHash) { return "" }

    try {
        if (Test-Path $Path -PathType Leaf) {
            return (Get-FileHash -Path $Path -Algorithm SHA256 -ErrorAction Stop).Hash
        }
    }
    catch {}
    return ""
}

function Test-IsNonPublicIP {
    param([string]$IP)

    if ([string]::IsNullOrWhiteSpace($IP)) { return $true }
    $ip2 = $IP.Trim()

    if ($ip2 -in @("-","0.0.0.0","::","::1","127.0.0.1","localhost")) { return $true }
    if ($ip2 -match "^127\.") { return $true }
    if ($ip2 -match "^10\.") { return $true }
    if ($ip2 -match "^192\.168\.") { return $true }
    if ($ip2 -match "^172\.(1[6-9]|2[0-9]|3[0-1])\.") { return $true }
    if ($ip2 -match "^169\.254\.") { return $true }
    if ($ip2 -match "^100\.(6[4-9]|[7-9][0-9]|1[01][0-9]|12[0-7])\.") { return $true }
    if ($ip2 -match "^(fc|fd)[0-9a-fA-F]{2}:") { return $true }
    if ($ip2 -match "^fe80:") { return $true }

    return $false
}

# 兼容旧函数名，避免其他模块或用户二次脚本调用中断。
function Test-PrivateIP {
    param([string]$IP)
    return (Test-IsNonPublicIP -IP $IP)
}

function Get-TimeWindow {
    if (-not $PSBoundParameters.ContainsKey("EndTime") -or $EndTime -eq [datetime]::MinValue) {
        $script:EndTime = Get-Date
    }
    else {
        $script:EndTime = $EndTime
    }

    if ($Days -le 0) { $script:Days = 7 } else { $script:Days = [Math]::Abs($Days) }
    if ($FocusDays -le 0) { $script:FocusDays = 3 } else { $script:FocusDays = [Math]::Abs($FocusDays) }

    if (-not $PSBoundParameters.ContainsKey("StartTime") -or $StartTime -eq [datetime]::MinValue) {
        $script:StartTime = $script:EndTime.AddDays(-1 * $script:Days)
    }
    else {
        $script:StartTime = $StartTime
    }

    $focusStart = $script:EndTime.AddDays(-1 * $script:FocusDays)
    if ($focusStart -lt $script:StartTime) {
        $script:FocusStartTime = $script:StartTime
    }
    else {
        $script:FocusStartTime = $focusStart
    }
}

function Test-IsInFocusWindow {
    param([datetime]$Time)
    if ($null -eq $Time -or $Time -eq [datetime]::MinValue) { return $false }
    return ($Time -ge $script:FocusStartTime -and $Time -le $script:EndTime)
}

function Ensure-OutputDir {
    if ([string]::IsNullOrWhiteSpace($OutputDir)) {
        $base = Join-Path (Get-Location) ("WinIR_Output_" + (Get-Date -Format "yyyyMMdd_HHmmss"))
    }
    else {
        $base = $OutputDir
    }

    New-Item -Path $base -ItemType Directory -Force | Out-Null
    $script:OutputDir = (Resolve-Path $base).Path
    $script:DetailDir = Join-Path $script:OutputDir "details"

    if ($ExportDetails) {
        New-Item -Path $script:DetailDir -ItemType Directory -Force | Out-Null
    }
}

function Export-DetailCsv {
    param(
        [string]$Name,
        [object]$Data
    )

    if (-not $ExportDetails) { return }

    $path = Join-Path $script:DetailDir $Name
    try {
        $rows = @()
        if ($null -ne $Data) {
            foreach ($item in $Data) {
                $rows += $item
            }
        }

        if ($rows.Count -eq 0) {
            $rows = @(
                [PSCustomObject]@{
                    Note = "本次扫描未发现对应明细。"
                }
            )
        }

        $rows | Export-Csv -Path $path -NoTypeInformation -Encoding UTF8
    }
    catch {
        Write-Warn "导出明细失败：$Name"
    }
}

function ConvertTo-HtmlTable {
    param(
        [object]$Data,
        [int]$MaxRows = 50
    )

    $safeData = @()
    if ($null -ne $Data) {
        foreach ($item in $Data) {
            $safeData += $item
        }
    }

    if ($safeData.Count -eq 0) {
        return "<p class='empty'>暂无数据</p>"
    }

    $rows = @($safeData | Select-Object -First $MaxRows)
    $props = $rows[0].PSObject.Properties.Name

    $html = "<table><thead><tr>"
    foreach ($p in $props) {
        $html += "<th>$(HtmlEncode $p)</th>"
    }
    $html += "</tr></thead><tbody>"

    foreach ($r in $rows) {
        $html += "<tr>"
        foreach ($p in $props) {
            $v = $r.$p
            if ($p -eq "Level") {
                $class = "badge-watch"
                if ($v -eq "高危") { $class = "badge-high" }
                elseif ($v -eq "中危") { $class = "badge-mid" }
                $html += "<td><span class='badge $class'>$(HtmlEncode $v)</span></td>"
            }
            else {
                $html += "<td>$(HtmlEncode $v)</td>"
            }
        }
        $html += "</tr>"
    }

    $html += "</tbody></table>"
    return $html
}

