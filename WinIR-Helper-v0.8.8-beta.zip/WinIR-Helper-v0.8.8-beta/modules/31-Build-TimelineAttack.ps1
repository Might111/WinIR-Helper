﻿# WinIR-Helper v0.8.8-beta module: 31-Build-TimelineAttack.ps1
# This module is dot-sourced by WinIR-Helper.ps1.

# 模块 8：攻击时间线与 ATT&CK 映射（v0.6.0-beta）
# =========================================================

Write-Info "正在构建攻击时间线与 ATT&CK 映射..."

$AttackTimeline = New-Object System.Collections.Generic.List[object]
$AttackTechniqueRaw = New-Object System.Collections.Generic.List[object]
$script:TimelineCounter = 0

function Add-AttackTimelineEvent {
    param(
        [datetime]$TimeCreated,
        [string]$Phase,
        [string]$Action,
        [string]$Level,
        [string]$EvidenceType,
        [string]$Source,
        [string]$Target,
        [string]$TechniqueId,
        [string]$TechniqueName,
        [string]$Tactic,
        [string]$Evidence,
        [string]$Suggestion
    )

    if ($null -eq $TimeCreated -or $TimeCreated -eq [datetime]::MinValue) {
        $TimeCreated = $EndTime
    }

    $script:TimelineCounter += 1
    $evidenceId = "TL-{0:D3}" -f $script:TimelineCounter

    $AttackTimeline.Add([PSCustomObject]@{
        EvidenceId    = $evidenceId
        TimeCreated   = $TimeCreated
        Phase         = $Phase
        Action        = $Action
        Level         = $Level
        EvidenceType  = $EvidenceType
        Source        = $Source
        Target        = $Target
        TechniqueId   = $TechniqueId
        TechniqueName = $TechniqueName
        Tactic        = $Tactic
        Evidence      = $Evidence
        Suggestion    = $Suggestion
    }) | Out-Null

    if ($TechniqueId) {
        $AttackTechniqueRaw.Add([PSCustomObject]@{
            EvidenceId    = $evidenceId
            Tactic        = $Tactic
            TechniqueId   = $TechniqueId
            TechniqueName = $TechniqueName
            Action        = $Action
            Level         = $Level
            Evidence      = $Evidence
            Suggestion    = $Suggestion
        }) | Out-Null
    }
}

function Get-FirstExistingFileTime {
    param([string]$SourceFiles)
    try {
        foreach ($line in (($SourceFiles -split "`n") | Where-Object { $_ })) {
            $candidate = ([string]$line).Trim()
            if ($candidate -and (Test-Path $candidate)) {
                return (Get-Item $candidate -Force).LastWriteTime
            }
        }
    } catch {}
    return $EndTime
}

# 1) 登录失败 / 爆破线索
$recentFailedLogonsForTimeline = @($FailedLogonDetails | Where-Object { $_.TimeCreated -ge $FocusStartTime })
if ($recentFailedLogonsForTimeline.Count -ge 5) {
    $firstFail = $recentFailedLogonsForTimeline | Sort-Object TimeCreated | Select-Object -First 1
    $lastFail  = $recentFailedLogonsForTimeline | Sort-Object TimeCreated | Select-Object -Last 1
    $targets = (($recentFailedLogonsForTimeline.TargetUser | Where-Object { $_ } | Sort-Object -Unique) -join ";")
    $sources = (($recentFailedLogonsForTimeline.Source | Where-Object { $_ } | Sort-Object -Unique) -join ";")

    Add-AttackTimelineEvent -TimeCreated $firstFail.TimeCreated `
        -Phase "凭证攻击" `
        -Action "多次登录失败 / 疑似口令猜测" `
        -Level "中危" `
        -EvidenceType "Security 4625" `
        -Source $sources `
        -Target $targets `
        -TechniqueId "T1110" `
        -TechniqueName "Brute Force" `
        -Tactic "Credential Access" `
        -Evidence "最近重点窗口内发现 $($recentFailedLogonsForTimeline.Count) 次登录失败，开始=$($firstFail.TimeCreated)，结束=$($lastFail.TimeCreated)，目标账户=$targets" `
        -Suggestion "结合来源 IP/WorkstationName、LogonType、Status/SubStatus 判断是否为 SMB/RDP/NLA 爆破或本机测试。"
}

foreach ($ipItem in ($FailedByIP | Where-Object { $_.FailedCount -ge 5 -and $_.LastFailTime -ge $FocusStartTime })) {
    Add-AttackTimelineEvent -TimeCreated $ipItem.AttackStartTime `
        -Phase "凭证攻击" `
        -Action "来源 IP 多次登录失败" `
        -Level "中危" `
        -EvidenceType "Security 4625 聚合" `
        -Source $ipItem.SourceIP `
        -Target $ipItem.TargetUsers `
        -TechniqueId "T1110" `
        -TechniqueName "Brute Force" `
        -Tactic "Credential Access" `
        -Evidence "失败次数=$($ipItem.FailedCount)，目标账户=$($ipItem.TargetUsers)，登录方式=$($ipItem.MainLogonMethod)，首次成功=$($ipItem.FirstSuccessTime)" `
        -Suggestion "若失败后出现同源成功登录，应优先复核该账户和后续行为。"
}

# 1.4) ADS 备用数据流隐藏配置线索
if ($AdsFindings.Count -gt 0) {
    $adsPreview = (($AdsFindings | Select-Object -First 5 | ForEach-Object { $_.AdsPath }) -join ";")
    Add-AttackTimelineEvent -TimeCreated $EndTime `
        -Phase "防御规避" `
        -Action "候选文件存在可疑 ADS 备用数据流" `
        -Level "中危" `
        -EvidenceType "ADS" `
        -Source "NTFS Alternate Data Stream" `
        -Target $adsPreview `
        -TechniqueId "T1564.004" `
        -TechniqueName "NTFS File Attributes" `
        -Tactic "Defense Evasion" `
        -Evidence "ADS数量=$($AdsFindings.Count)，示例=$adsPreview" `
        -Suggestion "复核 ADS 内容是否包含隐藏配置、投放 URL、钱包/矿池或脚本片段；必要时导出宿主文件和 ADS 内容留证。"
}

# 1.5) 自定义认证日志 IP 线索
if ($CustomAuthLogHits.Count -gt 0) {
    $ipPreview = (($CustomAuthLogHits.SourceIP | Sort-Object -Unique | Select-Object -First 8) -join ";")
    Add-AttackTimelineEvent -TimeCreated $EndTime `
        -Phase "凭证攻击" `
        -Action "自定义认证日志出现来源 IP 线索" `
        -Level "关注" `
        -EvidenceType "Custom Auth Log" `
        -Source "候选目录日志" `
        -Target $ipPreview `
        -TechniqueId "T1110" `
        -TechniqueName "Brute Force" `
        -Tactic "Credential Access" `
        -Evidence "自定义/应用日志中发现来源 IP 线索：$ipPreview；注意这不等同于 Windows Security 4625 真实来源 IP。" `
        -Suggestion "用于辅助复核；真实危险 IP 仍建议通过双机登录失败、网关、防火墙或 Security 4625 事件验证。"
}

# 2) RDP 远程服务行为
foreach ($rdp in ($RdpEvents | Where-Object { $_.TimeCreated -ge $FocusStartTime } | Sort-Object TimeCreated | Select-Object -First 30)) {
    Add-AttackTimelineEvent -TimeCreated $rdp.TimeCreated `
        -Phase "远程访问" `
        -Action "RDP 相关会话事件" `
        -Level "关注" `
        -EvidenceType "TerminalServices" `
        -Source $rdp.Address `
        -Target $rdp.UserName `
        -TechniqueId "T1021.001" `
        -TechniqueName "Remote Desktop Protocol" `
        -Tactic "Lateral Movement" `
        -Evidence "EventID=$($rdp.EventID)，描述=$($rdp.Description)，用户=$($rdp.UserName)，来源=$($rdp.Address)" `
        -Suggestion "与 4624/4625、1149、21/24/25、3389 监听和后续持久化行为进行时间线关联。"
}

# 3) PowerShell 执行痕迹
foreach ($ps in ($PowerShellFindings | Where-Object { $_.TimeCreated -ge $FocusStartTime } | Sort-Object TimeCreated | Select-Object -First 30)) {
    $psLevelForTimeline = if ($ps.Level) { $ps.Level } else { "中危" }
    $psAction = if ($psLevelForTimeline -eq "关注") { "PowerShell 管理/测试操作特征" } else { "PowerShell 高危命令特征" }

    Add-AttackTimelineEvent -TimeCreated $ps.TimeCreated `
        -Phase "执行" `
        -Action $psAction `
        -Level $psLevelForTimeline `
        -EvidenceType "PowerShell 4103/4104" `
        -Source "PowerShell" `
        -Target "ScriptBlock/Command" `
        -TechniqueId "T1059.001" `
        -TechniqueName "PowerShell" `
        -Tactic "Execution" `
        -Evidence "EventID=$($ps.EventID)，原因=$($ps.Reason)，摘要=$($ps.Summary)" `
        -Suggestion "结合时间、父进程、脚本路径判断是管理员临时操作还是攻击执行链。若伴随下载执行、编码命令、持久化或账户变更，应优先复核。"
}

# 4) 服务安装
foreach ($svc in ($ServiceEvents | Where-Object { $_.Level -in @("高危","中危") } | Sort-Object TimeCreated | Select-Object -First 40)) {
    Add-AttackTimelineEvent -TimeCreated $svc.TimeCreated `
        -Phase "持久化" `
        -Action "创建或安装可疑 Windows 服务" `
        -Level $svc.Level `
        -EvidenceType "System 7045" `
        -Source $svc.ServiceName `
        -Target $svc.ImagePath `
        -TechniqueId "T1543.003" `
        -TechniqueName "Windows Service" `
        -Tactic "Persistence" `
        -Evidence "服务=$($svc.ServiceName)，路径=$($svc.ImagePath)，原因=$($svc.Reason)" `
        -Suggestion "复核服务文件 Hash、签名、创建时间、父进程，以及是否与计划任务/启动项/矿池配置相关。"
}

# 5) 计划任务
foreach ($task in ($SuspiciousTasks | Select-Object -First 60)) {
    Add-AttackTimelineEvent -TimeCreated $EndTime `
        -Phase "持久化" `
        -Action "发现可疑计划任务" `
        -Level $task.Level `
        -EvidenceType "Scheduled Task" `
        -Source $task.TaskName `
        -Target $task.Actions `
        -TechniqueId "T1053.005" `
        -TechniqueName "Scheduled Task" `
        -Tactic "Persistence" `
        -Evidence "任务=$($task.TaskName)，动作=$($task.Actions)，原因=$($task.Reason)" `
        -Suggestion "复核任务触发器、创建时间、执行文件签名和命令行参数。"
}

# 6) 启动项 / Run Key / Startup Folder / 脚本宿主
foreach ($startup in ($SuspiciousStartup | Select-Object -First 80)) {
    $techId = "T1547.001"
    $techName = "Registry Run Keys / Startup Folder"
    $tactic = "Persistence"
    $phase = "持久化"

    if ($startup.Command -match "(?i)mshta\.exe") {
        $techId = "T1218.005"; $techName = "Mshta"; $tactic = "Defense Evasion"; $phase = "规避/脚本执行"
    }
    elseif ($startup.Command -match "(?i)wscript\.exe|cscript\.exe|\.vbs") {
        $techId = "T1059.005"; $techName = "Visual Basic"; $tactic = "Execution"; $phase = "脚本执行"
    }
    elseif ($startup.Command -match "(?i)powershell|\.ps1") {
        $techId = "T1059.001"; $techName = "PowerShell"; $tactic = "Execution"; $phase = "脚本执行"
    }

    Add-AttackTimelineEvent -TimeCreated $EndTime `
        -Phase $phase `
        -Action "发现可疑启动项" `
        -Level $startup.Level `
        -EvidenceType "Run/RunOnce/Startup" `
        -Source $startup.Location `
        -Target $startup.Command `
        -TechniqueId $techId `
        -TechniqueName $techName `
        -Tactic $tactic `
        -Evidence "位置=$($startup.Location)，名称=$($startup.Name)，命令=$($startup.Command)，原因=$($startup.Reason)" `
        -Suggestion "复核启动项文件是否仍存在、是否隐藏、是否由脚本宿主或 LOLBin 启动。"
}

# 7) 资源异常 / 挖矿活动
foreach ($ra in ($ResourceAnomalies | Where-Object { $_.CpuPercent -ge $CpuHighPercent -or $_.Tags -match "CPU占用" } | Select-Object -First 30)) {
    Add-AttackTimelineEvent -TimeCreated $EndTime `
        -Phase "影响" `
        -Action "资源占用异常 / 疑似资源劫持" `
        -Level $ra.Level `
        -EvidenceType "Process Resource" `
        -Source $ra.Name `
        -Target $ra.ExecutablePath `
        -TechniqueId "T1496" `
        -TechniqueName "Resource Hijacking" `
        -Tactic "Impact" `
        -Evidence "进程=$($ra.Name)，PID=$($ra.ProcessId)，CPU=$($ra.CpuPercent)%，路径=$($ra.ExecutablePath)，标签=$($ra.Tags)" `
        -Suggestion "结合矿池/钱包配置、服务/任务/启动项和文件 Hash 判断是否为活动中挖矿。"
}

# 8) 矿池 / 钱包配置
# v0.8.3：只有较明确的矿池/钱包/矿工 IOC 才进入 T1496 时间线；localhost/内网服务 URL 不参与攻击时间线。
# 详细候选值仍保留在「挖矿配置提取」表和 CSV 中。
$ConfirmedMiningConfigs = @($MiningConfigsGroupedArray | Where-Object { Test-IsProbablyMiningIoc -Type $_.Type -Value $_.Value -Context $_.Context })
if ($ConfirmedMiningConfigs.Count -gt 0) {
    $firstConfig = $ConfirmedMiningConfigs | Select-Object -First 1
    $eventTimeCandidates = @()
    foreach ($mc in $ConfirmedMiningConfigs) {
        $t = Get-FirstExistingFileTime -SourceFiles $mc.SourceFiles
        if ($t -and $t -ne [datetime]::MinValue) { $eventTimeCandidates += $t }
    }
    $eventTime = if ($eventTimeCandidates.Count -gt 0) { ($eventTimeCandidates | Sort-Object | Select-Object -First 1) } else { $EndTime }

    $previewValues = (($ConfirmedMiningConfigs | Select-Object -First 5 | ForEach-Object { "$($_.Type)=$($_.Value)" }) -join "；")
    $sourcePreview = (($ConfirmedMiningConfigs.SourceFiles -join "`n" -split "`n" | Where-Object { $_ } | Sort-Object -Unique | Select-Object -First 8) -join "`n")

    Add-AttackTimelineEvent -TimeCreated $eventTime `
        -Phase "影响" `
        -Action "发现矿池 / 钱包配置线索" `
        -Level "高危" `
        -EvidenceType "Mining Config" `
        -Source $sourcePreview `
        -Target "确认线索数=$($ConfirmedMiningConfigs.Count)" `
        -TechniqueId "T1496" `
        -TechniqueName "Resource Hijacking" `
        -Tactic "Impact" `
        -Evidence "确认后的矿池/钱包配置线索数=$($ConfirmedMiningConfigs.Count)，示例=$previewValues" `
        -Suggestion "确认配置文件是否仍被服务/计划任务/启动项引用，提取文件 Hash 并进行威胁情报检索。"
}

# 9) 账户创建 / 权限变更
foreach ($evt in ($SecurityEvents | Where-Object { $_.TimeCreated -ge $FocusStartTime -and $_.EventID -in @(4720,4732) } | Sort-Object TimeCreated | Select-Object -First 40)) {
    $techId = if ($evt.EventID -eq 4720) { "T1136.001" } else { "T1098" }
    $techName = if ($evt.EventID -eq 4720) { "Local Account" } else { "Account Manipulation" }
    Add-AttackTimelineEvent -TimeCreated $evt.TimeCreated `
        -Phase "账户变更" `
        -Action $evt.EventType `
        -Level "高危" `
        -EvidenceType "Security $($evt.EventID)" `
        -Source $evt.SubjectUser `
        -Target $evt.TargetUser `
        -TechniqueId $techId `
        -TechniqueName $techName `
        -Tactic "Persistence" `
        -Evidence "EventID=$($evt.EventID)，用户=$($evt.TargetUser)，成员=$($evt.MemberName)，操作者=$($evt.SubjectUser)，来源=$($evt.SourceIP)" `
        -Suggestion "核查新增账户/组成员是否为合法变更，并与远程登录和持久化时间线关联。"
}

# v0.6.2：先按时间排序，再重新生成 TL-001/TL-002，保证编号与时间线顺序一致。
$AttackTimelineRawSorted = @($AttackTimeline | Sort-Object TimeCreated,EvidenceId)
$AttackTimelineArray = @()
$timelineIndex = 0
foreach ($e in $AttackTimelineRawSorted) {
    $timelineIndex += 1
    $newEvidenceId = "TL-{0:D3}" -f $timelineIndex

    $AttackTimelineArray += [PSCustomObject]@{
        EvidenceId    = $newEvidenceId
        TimeCreated   = $e.TimeCreated
        Phase         = $e.Phase
        Action        = $e.Action
        Level         = $e.Level
        EvidenceType  = $e.EvidenceType
        Source        = $e.Source
        Target        = $e.Target
        TechniqueId   = $e.TechniqueId
        TechniqueName = $e.TechniqueName
        Tactic        = $e.Tactic
        Evidence      = $e.Evidence
        Suggestion    = $e.Suggestion
    }
}

$AttackTechniques = @()
foreach ($g in (($AttackTimelineArray | Where-Object { $_.TechniqueId }) | Group-Object TechniqueId | Sort-Object Name)) {
    $items = @($g.Group)
    $first = $items | Select-Object -First 1
    $AttackTechniques += [PSCustomObject]@{
        Tactic          = (($items.Tactic | Where-Object { $_ } | Sort-Object -Unique) -join ";")
        TechniqueId     = $g.Name
        TechniqueName   = $first.TechniqueName
        Count           = $items.Count
        EvidenceIds     = (($items.EvidenceId | Sort-Object -Unique) -join ";")
        ExampleEvidence = $first.Evidence
        Suggestion      = $first.Suggestion
    }
}

$EvidenceChain = @()
foreach ($e in ($AttackTimelineArray | Select-Object -First 120)) {
    $EvidenceChain += [PSCustomObject]@{
        EvidenceId  = $e.EvidenceId
        TimeCreated = $e.TimeCreated
        Phase       = $e.Phase
        Brief       = "$($e.Action) / $($e.TechniqueId)"
        Source      = $e.Source
        Target      = $e.Target
    }
}

Export-DetailCsv -Name "攻击时间线.csv" -Data $AttackTimelineArray
Export-DetailCsv -Name "ATTACK技术映射.csv" -Data $AttackTechniques
Export-DetailCsv -Name "证据链概览.csv" -Data $EvidenceChain

# =========================================================
