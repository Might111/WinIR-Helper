﻿# WinIR-Helper v0.8.8-beta module: 30-Analyze-Scenarios.ps1
# This module is dot-sourced by WinIR-Helper.ps1.

# 场景聚合判断
# =========================================================

if ($null -eq $MiningConfigsArray) {
    $MiningConfigsArray = @()
}

Write-Info "正在进行攻击场景聚合判断..."

$RdpListening = @($DangerPorts | Where-Object { $_.LocalPort -eq 3389 }).Count -gt 0
$SmbListening = @($DangerPorts | Where-Object { $_.LocalPort -eq 445 }).Count -gt 0

foreach ($ipItem in ($FailedByIP | Where-Object { $_.LastFailTime -ge $FocusStartTime })) {
    $relatedRdp = @($RdpEvents | Where-Object { $_.Address -eq $ipItem.SourceIP })
    $hasRdpEvents = $relatedRdp.Count -gt 0
    $hasSuccess = -not [string]::IsNullOrWhiteSpace([string]$ipItem.FirstSuccessTime)

    if ($ipItem.FailedCount -ge 5 -and ($RdpListening -or $hasRdpEvents -or $ipItem.FirstSuccessType -match "RDP|10-")) {
        $level = if ($hasSuccess -or $hasRdpEvents) { "高危" } else { "中危" }

        Add-Scenario -Level $level -Scenario "疑似 RDP 暴力破解 / 远程桌面攻击" `
            -Conclusion "来源 IP $($ipItem.SourceIP) 存在多次登录失败，且本机监听 3389 或存在 RDP 相关事件。" `
            -Evidence "疑似开始时间=$($ipItem.AttackStartTime)，失败次数=$($ipItem.FailedCount)，目标账户=$($ipItem.TargetUsers)，登录方式=$($ipItem.MainLogonMethod)，首次成功=$($ipItem.FirstSuccessTime)，RDP事件数=$($relatedRdp.Count)" `
            -Suggestion "优先复核 3389 是否对外开放、该 IP 是否出现 1149/21/25 RDP 成功事件、是否存在后续创建账户/加入组/服务安装行为。"
    }
    elseif ($ipItem.FailedCount -ge 5 -and $SmbListening -and $ipItem.MainLogonMethod -match "3-") {
        Add-Scenario -Level "中危" -Scenario "疑似 SMB / NTLM 网络登录爆破" `
            -Conclusion "来源 IP $($ipItem.SourceIP) 存在多次 LogonType 3 登录失败，且本机监听 445。" `
            -Evidence "疑似开始时间=$($ipItem.AttackStartTime)，失败次数=$($ipItem.FailedCount)，目标账户=$($ipItem.TargetUsers)，端口范围=$($ipItem.SourcePortRange)" `
            -Suggestion "检查 SMB 是否对外暴露，确认该 IP 是否有后续登录成功、横向移动或文件共享访问行为。"
    }
}


foreach ($failGroup in ($FailedByIdentity | Where-Object { $_.LastFailTime -ge $FocusStartTime -and $_.FailedCount -ge 5 })) {
    if ($failGroup.Source -match '^IP:') { continue }

    Add-Scenario -Level "中危" -Scenario "疑似登录失败集中发生（无标准来源 IP）" `
        -Conclusion "发现多次 4625 登录失败，但事件未解析到标准远程 IP，可能是本机/内网/IPC$ 失败登录或日志字段缺失。" `
        -Evidence "来源=$($failGroup.Source)，失败次数=$($failGroup.FailedCount)，目标账户=$($failGroup.TargetUser)，登录方式=$($failGroup.LogonTypeDesc)，开始=$($failGroup.AttackStartTime)，结束=$($failGroup.LastFailTime)" `
        -Suggestion "建议查看登录失败明细，结合 WorkstationName、LogonType、Status/SubStatus 与原始安全日志确认是否为爆破或测试行为。"
}

$activeMinerProcessEvidence = @($ResourceAnomalies | Where-Object {
    ($_.CpuPercent -ge $CpuHighPercent -or $_.Tags -match "CPU占用") -and
    ("$($_.Name) $($_.ExecutablePath) $($_.Tags) $($_.CommandLine)" -match "(?i)xmrig|xmr-stak|monero|stratum|WinRing0|c3pool|cryptonight|cpuminer|minerd|WindowStyle Hidden")
})
$minerServiceEvidence = @($ServiceEvents | Where-Object { "$($_.ServiceName) $($_.ImagePath)" -match "(?i)c3pool|xmrig|xmr-stak|miner|WinRing0|nssm|monero|stratum" })
$minerConfigEvidence = @($MiningConfigsGroupedArray | Where-Object { Test-IsProbablyMiningIoc -Type $_.Type -Value $_.Value -Context $_.Context })
$minerPersistenceEvidence = @($SuspiciousStartup | Where-Object { "$($_.Command) $($_.Reason)" -match "(?i)xmrig|xmr-stak|monero|stratum|c3pool|miner|downloadstring|-enc|-encodedcommand" }) + @($SuspiciousTasks | Where-Object { "$($_.Actions) $($_.Reason)" -match "(?i)xmrig|xmr-stak|monero|stratum|c3pool|miner|downloadstring|-enc|-encodedcommand" }) + @($minerServiceEvidence)
$minerEvidence = @($activeMinerProcessEvidence) + @($minerServiceEvidence) + @($minerConfigEvidence)

if (@($activeMinerProcessEvidence).Count -gt 0 -and @($minerConfigEvidence).Count -gt 0) {
    Add-Scenario -Level "高危" -Scenario "疑似活动中挖矿 / 资源滥用" `
        -Conclusion "当前存在资源异常进程，并发现矿池/钱包配置及持久化线索，倾向于活动中挖矿或资源滥用。" `
        -Evidence "活动进程数=$(@($activeMinerProcessEvidence).Count)，配置线索数=$(@($minerConfigEvidence).Count)，持久化线索数=$(@($minerPersistenceEvidence).Count)；示例=$((@($minerConfigEvidence) | Select-Object -First 1 | Out-String).Trim())" `
        -Suggestion "优先确认高 CPU 进程的路径、Hash、父进程和启动来源；立即复核服务/计划任务/启动项与矿池配置文件。"
}
elseif (@($minerConfigEvidence).Count -gt 0 -and @($minerPersistenceEvidence).Count -gt 0) {
    Add-Scenario -Level "中危" -Scenario "疑似挖矿残留 / 历史痕迹" `
        -Conclusion "当前未发现持续资源异常进程，但存在较明确的矿池/钱包配置和持久化线索，倾向于挖矿残留或历史投放痕迹。" `
        -Evidence "配置线索数=$(@($minerConfigEvidence).Count)，持久化线索数=$(@($minerPersistenceEvidence).Count)；示例=$((@($minerConfigEvidence) | Select-Object -First 1 | Out-String).Trim())" `
        -Suggestion "建议检查对应文件是否仍存在、服务/任务/启动项是否仍启用，并结合文件时间线判断是否已被清理或处于休眠状态。"
}
elseif (@($minerEvidence).Count -gt 0) {
    Add-Scenario -Level "中危" -Scenario "疑似挖矿相关线索" `
        -Conclusion "发现部分挖矿相关线索，但当前证据链不足以区分活动中挖矿或历史残留。" `
        -Evidence "相关线索数量=$(@($minerEvidence).Count)；示例=$((@($minerEvidence) | Select-Object -First 1 | Out-String).Trim())" `
        -Suggestion "建议继续结合进程、服务、计划任务、启动项、矿池/钱包配置和文件 Hash 进行人工复核。"
}

$persistenceEvidence = @()
$persistenceEvidence += @($SuspiciousStartup)
$persistenceEvidence += @($SuspiciousTasks)
$persistenceEvidence += @($ServiceEvents | Where-Object { $_.Level -in @("高危","中危") })

if (@($persistenceEvidence).Count -gt 0) {
    Add-Scenario -Level "中危" -Scenario "疑似持久化行为" `
        -Conclusion "发现启动项、计划任务或服务安装相关持久化线索。" `
        -Evidence "相关线索数量=$(@($persistenceEvidence).Count)" `
        -Suggestion "重点复核 AppData/Public/Temp/ProgramData 目录下的启动项、可疑服务、计划任务和 nssm/脚本启动方式。"
}

$accountEvidence = @($SecurityEvents | Where-Object { $_.TimeCreated -ge $FocusStartTime -and $_.EventID -in @(4720,4732) -and $_.TargetUser -match "(?i)Administrators|Remote Desktop Users|管理员|远程桌面用户|hack|test|support|admin" })
if (@($accountEvidence).Count -gt 0) {
    Add-Scenario -Level "高危" -Scenario "疑似账户权限变更" `
        -Conclusion "发现创建用户或加入敏感本地组的事件。" `
        -Evidence "相关线索数量=$(@($accountEvidence).Count)" `
        -Suggestion "核查新增账户、组成员变化、操作者账户和变化时间是否与攻击时间线重合。"
}

# v0.8.5：日志读取完整性也会影响“正常”结论。
try {
    $secProbeForScenario = Get-EventLogProbe -LogName "Security"
    $recordCountForScenario = 0
    try { $recordCountForScenario = [int64]$secProbeForScenario.RecordCount } catch { $recordCountForScenario = 0 }
    $queryFailureCountForScenario = 0
    try { $queryFailureCountForScenario = @($script:EventLogQuerySummary | Where-Object { $_.Status -eq "失败" }).Count } catch { $queryFailureCountForScenario = 0 }
    if ($script:RunMode -eq "Live" -and @($SecurityEvents).Count -eq 0 -and ($secProbeForScenario.Status -eq "异常" -or $recordCountForScenario -gt 0 -or $queryFailureCountForScenario -gt 0)) {
        Add-Scenario -Level "关注" -Scenario "数据完整性需确认" `
            -Conclusion "本次未形成明确攻击场景，但 Security 事件读取结果需要确认，不能把事件为 0 直接等同于安全。" `
            -Evidence "SecurityStatus=$($secProbeForScenario.Status)，RecordCount=$recordCountForScenario，LatestEventId=$($secProbeForScenario.LatestEventId)，LatestEventTime=$($secProbeForScenario.LatestEventTime)，QueryFailures=$queryFailureCountForScenario" `
            -Suggestion "建议手工执行 Get-WinEvent 验证 Security 日志；若本版本仍显示查询失败，请反馈数据完整性表中的错误信息。"
    }
} catch {}

# 如果没有任何场景结论，给出正常提示
if ($Scenarios.Count -eq 0) {
    Add-Scenario -Level "正常" -Scenario "未形成明确攻击场景" `
        -Conclusion "当前规则未聚合出明确攻击场景。" `
        -Evidence "未发现满足阈值的 RDP/SMB 爆破、挖矿、持久化或账户变更组合。" `
        -Suggestion "这不代表系统绝对安全，建议结合业务背景、EDR/杀软告警和人工分析继续复核。"
}

# 如果没有重点关注项，给出正常提示
if ($Findings.Count -eq 0) {
    Add-Finding -Level "正常" -Category "总体" -Title "当前规则未发现重点关注项" `
        -Evidence "在本次时间范围内，当前规则未命中高危、中危或关注项。" `
        -Suggestion "这不代表系统绝对安全，建议结合业务背景和人工分析继续复核。"
}


# =========================================================
