﻿# WinIR-Helper v0.8.8-beta module: 32-Score-And-Advisory.ps1
# This module is dot-sourced by WinIR-Helper.ps1.

# 模块 10：v0.7 证据链评分与处置建议生成器
# =========================================================

Write-Info "正在生成 v0.7 证据链评分与处置建议..."

function Limit-Score {
    param([int]$Score)
    if ($Score -lt 0) { return 0 }
    if ($Score -gt 100) { return 100 }
    return $Score
}

function Get-ScoreLevel {
    param([int]$Score)
    if ($Score -ge 80) { return "高危" }
    elseif ($Score -ge 50) { return "中危" }
    elseif ($Score -ge 25) { return "关注" }
    return "低"
}

function Get-EvidenceIdsByTechnique {
    param([string[]]$TechniqueIds)
    $ids = @()
    foreach ($tid in $TechniqueIds) {
        $ids += @($AttackTimelineArray | Where-Object { $_.TechniqueId -eq $tid } | Select-Object -ExpandProperty EvidenceId)
    }
    return (($ids | Where-Object { $_ } | Sort-Object -Unique) -join ";")
}

function Add-EvidenceScore {
    param(
        [System.Collections.Generic.List[object]]$List,
        [string]$Scenario,
        [int]$Score,
        [string]$Conclusion,
        [string]$Evidence,
        [string]$Priority,
        [string]$RecommendedAction,
        [string]$EvidenceIds
    )

    $finalScore = Limit-Score -Score $Score
    $List.Add([PSCustomObject]@{
        Level             = Get-ScoreLevel -Score $finalScore
        Scenario          = $Scenario
        Score             = $finalScore
        Priority          = $Priority
        Conclusion        = $Conclusion
        Evidence          = $Evidence
        EvidenceIds       = $EvidenceIds
        RecommendedAction = $RecommendedAction
    }) | Out-Null
}

function Add-CleanupAdvice {
    param(
        [System.Collections.Generic.List[object]]$List,
        [string]$Priority,
        [string]$RiskType,
        [string]$Target,
        [string]$Evidence,
        [string]$SuggestedCommand,
        [string]$SafetyNote
    )

    if ([string]::IsNullOrWhiteSpace($Target)) { return }

    foreach ($x in $List) {
        if ($x.RiskType -eq $RiskType -and $x.Target -eq $Target -and $x.SuggestedCommand -eq $SuggestedCommand) {
            return
        }
    }

    $List.Add([PSCustomObject]@{
        Priority         = $Priority
        RiskType         = $RiskType
        Target           = $Target
        Evidence         = $Evidence
        SuggestedCommand = $SuggestedCommand
        SafetyNote       = $SafetyNote
    }) | Out-Null
}

function Get-FirstPathFromText {
    param([string]$Text)
    if ([string]::IsNullOrWhiteSpace($Text)) { return "" }
    $m = [regex]::Match($Text, '(?i)[A-Z]:\\[^"''<>|\r\n]+?\.(exe|dll|sys|ps1|vbs|bat|cmd|hta|js|jse|wsf|scr|lnk|msi)')
    if ($m.Success) { return $m.Value.Trim() }
    return ""
}

function Get-SafeRegDeleteCommand {
    param([string]$Location,[string]$Name)
    if ([string]::IsNullOrWhiteSpace($Location) -or [string]::IsNullOrWhiteSpace($Name)) { return "" }
    if ($Location -match '^HKLM:\\(.+)$') { return "reg delete `"HKLM\$($Matches[1])`" /v `"$Name`" /f" }
    if ($Location -match '^HKCU:\\(.+)$') { return "reg delete `"HKCU\$($Matches[1])`" /v `"$Name`" /f" }
    return ""
}

function Resolve-ServiceNameForCommand {
    param(
        [string]$ServiceName,
        [string]$ImagePath
    )

    # 7045 日志中的 ServiceName 在部分系统/语言环境里可能更像 DisplayName。
    # sc.exe 更适合使用 Win32_Service.Name，所以这里尽量反查真实服务名。
    try {
        $services = Get-CimInstance Win32_Service -ErrorAction SilentlyContinue
        foreach ($svc in $services) {
            if ($svc.Name -eq $ServiceName) { return $svc.Name }
        }
        foreach ($svc in $services) {
            if ($svc.DisplayName -eq $ServiceName) { return $svc.Name }
        }
        if (-not [string]::IsNullOrWhiteSpace($ImagePath)) {
            $needle = ($ImagePath -replace '"','').Trim()
            foreach ($svc in $services) {
                $pn = ([string]$svc.PathName -replace '"','').Trim()
                if ($pn -eq $needle -or $pn.Contains($needle) -or $needle.Contains($pn)) {
                    return $svc.Name
                }
            }
        }
    } catch {}

    return $ServiceName
}

function Get-StartupArtifactPath {
    param(
        [string]$Location,
        [string]$Name,
        [string]$Command
    )

    # 注册表启动项没有文件路径本体，删除建议应走 reg delete。
    if ($Location -match '^HK') { return "" }

    # Startup 文件夹中的 .lnk/.vbs/.bat 等，处置对象应是 Startup 目录里的文件本身，
    # 不是快捷方式解析后的 wscript.exe 或 powershell.exe 命令行。
    try {
        if ((Test-Path $Location -PathType Container) -and -not [string]::IsNullOrWhiteSpace($Name)) {
            return (Join-Path $Location $Name)
        }
    } catch {}

    if ($Command -match '(?i)^[A-Z]:\\') { return $Command }
    return ""
}

function Test-IsSystemInterpreterPath {
    param([string]$Path)

    if ([string]::IsNullOrWhiteSpace($Path)) { return $false }

    return ($Path -match '(?i)^C:\\Windows\\(System32|SysWOW64)\\(wscript|cscript|mshta|powershell|powershell_ise|cmd|rundll32|regsvr32|wmic|schtasks|sc)\.exe$')
}

$EvidenceScores = New-Object System.Collections.Generic.List[object]
$CleanupAdvices = New-Object System.Collections.Generic.List[object]
$HighRiskHashTargets = New-Object System.Collections.Generic.List[object]

# v0.8.3：只把明确矿池/钱包/矿工 IOC 纳入挖矿评分，localhost/内网服务 URL 不参与评分。
$ConfirmedMiningConfigs = @($MiningConfigsGroupedArray | Where-Object { Test-IsProbablyMiningIoc -Type $_.Type -Value $_.Value -Context $_.Context })
$MiningRelatedTasks = @($SuspiciousTasks | Where-Object { "$($_.Actions) $($_.Reason)" -match "(?i)xmrig|xmr-stak|monero|stratum|c3pool|miner|downloadstring|-enc|-encodedcommand" })
$MiningRelatedStartup = @($SuspiciousStartup | Where-Object { "$($_.Command) $($_.Reason)" -match "(?i)xmrig|xmr-stak|monero|stratum|c3pool|miner|downloadstring|-enc|-encodedcommand" })

# 1. 挖矿 / 资源滥用证据链评分
$minerScore = 0
$minerReasons = @()
if (@($activeMinerProcessEvidence).Count -gt 0) { $minerScore += 30; $minerReasons += "存在资源异常/高 CPU 可疑进程" }
if (@($ConfirmedMiningConfigs).Count -gt 0) { $minerScore += 30; $minerReasons += "发现矿池/钱包/资源劫持配置" }
if (@($minerServiceEvidence).Count -gt 0) { $minerScore += 15; $minerReasons += "存在可疑服务关联" }
if (@($MiningRelatedTasks).Count -gt 0) { $minerScore += 10; $minerReasons += "存在与矿工/投放相关的计划任务" }
if (@($MiningRelatedStartup).Count -gt 0) { $minerScore += 10; $minerReasons += "存在与矿工/投放相关的启动项" }
if (@($CustomAuthLogHits).Count -gt 0) { $minerScore += 5; $minerReasons += "存在自定义认证日志 IP 线索" }

if ($minerScore -gt 0) {
    Add-EvidenceScore -List $EvidenceScores -Scenario "挖矿 / 资源滥用" -Score $minerScore `
        -Conclusion "根据资源异常、矿池配置和持久化线索综合评分。" `
        -Evidence (($minerReasons | Sort-Object -Unique) -join "；") `
        -Priority "优先确认是否仍在运行，然后处理服务/任务/启动项与配置文件。" `
        -RecommendedAction "先留证与计算 Hash，再停止可疑进程，随后禁用相关服务/计划任务/启动项。" `
        -EvidenceIds (Get-EvidenceIdsByTechnique -TechniqueIds @("T1496","T1543.003","T1053.005","T1547.001"))
}

# 2. 持久化证据链评分
$persistenceScore = 0
$persistenceReasons = @()
if (@($ServiceEvents | Where-Object { $_.Level -in @("高危","中危") }).Count -gt 0) { $persistenceScore += 25; $persistenceReasons += "发现可疑服务安装/服务线索" }
if (@($SuspiciousTasks).Count -gt 0) { $persistenceScore += 25; $persistenceReasons += "发现可疑计划任务" }
if (@($SuspiciousStartup).Count -gt 0) { $persistenceScore += 25; $persistenceReasons += "发现可疑启动项" }
if (@($AttackTimelineArray | Where-Object { $_.TechniqueId -in @("T1543.003","T1053.005","T1547.001") }).Count -ge 3) { $persistenceScore += 15; $persistenceReasons += "多类持久化技术同时出现" }
if (@($ConfirmedMiningConfigs).Count -gt 0) { $persistenceScore += 10; $persistenceReasons += "持久化线索附近存在明确矿池/钱包配置" }

if ($persistenceScore -gt 0) {
    Add-EvidenceScore -List $EvidenceScores -Scenario "持久化后门 / 自启动控制" -Score $persistenceScore `
        -Conclusion "根据服务、计划任务、启动项及其与 IOC 的关联综合评分。" `
        -Evidence (($persistenceReasons | Sort-Object -Unique) -join "；") `
        -Priority "优先处理仍启用的服务和计划任务，再处理 Run/Startup。" `
        -RecommendedAction "先导出任务 XML、服务配置和注册表项，再逐项禁用或删除。" `
        -EvidenceIds (Get-EvidenceIdsByTechnique -TechniqueIds @("T1543.003","T1053.005","T1547.001"))
}

# 3. 账户入侵证据链评分
$accountScore = 0
$accountReasons = @()
if (@($SuspiciousUsers | Where-Object { $_.Level -eq "高危" }).Count -gt 0) { $accountScore += 35; $accountReasons += "存在高危可疑账户" }
if (@($HiddenAccounts).Count -gt 0) { $accountScore += 30; $accountReasons += "存在 Winlogon 隐藏账户项" }
if (@($AccountSecurityEvents | Where-Object { $_.EventID -in @(4720,4732,4728) }).Count -gt 0) { $accountScore += 20; $accountReasons += "存在账户创建或敏感组变更事件" }
if (@($RdpMembers).Count -gt 0) { $accountScore += 10; $accountReasons += "远程桌面用户组存在成员，需要复核" }
if (@($FailedByIdentity | Where-Object { $_.TargetUser -match '(?i)hack|admin|svc_|\$' -and $_.FailedCount -ge 2 }).Count -gt 0) { $accountScore += 10; $accountReasons += "可疑账户存在登录失败痕迹" }

# v0.7.1：隐藏账户是账户入侵高价值证据。只要命中 Winlogon 隐藏账户项，
# 账户证据链最低提升到高危阈值，避免显示为“中危”而降低处置优先级。
if (@($HiddenAccounts).Count -gt 0 -and $accountScore -lt 80) {
    $accountScore = 80
    $accountReasons += "Winlogon 隐藏账户触发高危阈值"
}
if (@($HiddenAccounts).Count -gt 0 -and @($SuspiciousUsers | Where-Object { $_.Level -eq "高危" }).Count -gt 0 -and $accountScore -lt 85) {
    $accountScore = 85
    $accountReasons += "隐藏账户与高危可疑账户同时存在"
}

if ($accountScore -gt 0) {
    Add-EvidenceScore -List $EvidenceScores -Scenario "账户入侵 / 隐藏用户" -Score $accountScore `
        -Conclusion "根据可疑账户、隐藏账户、组成员和账户事件综合评分。" `
        -Evidence (($accountReasons | Sort-Object -Unique) -join "；") `
        -Priority "优先确认隐藏账户和新增管理员组成员。" `
        -RecommendedAction "留证后禁用未知账户，导出 Winlogon 隐藏账户注册表项，并复核 4720/4732/4624/4625。" `
        -EvidenceIds (Get-EvidenceIdsByTechnique -TechniqueIds @("T1136","T1098","T1110"))
}

# 4. 凭证攻击 / 爆破证据链评分
$credScore = 0
$credReasons = @()
# v0.8.3：将 ${jndi:...} 这类漏洞扫描 payload 从口令爆破评分中剔除，避免 Nessus/Log4Shell 测试痕迹误报为凭证攻击。
$CredFailedByIdentity = @($FailedByIdentity | Where-Object { $_.TargetUser -notmatch '\$\{jndi:' })
$CredFailedByIP = @($FailedByIP | Where-Object { $_.TargetUsers -notmatch '\$\{jndi:' })
$maxFailed = 0
try { $maxFailed = [int](($CredFailedByIdentity | Measure-Object -Property FailedCount -Maximum).Maximum) } catch { $maxFailed = 0 }
if ($maxFailed -ge 10) { $credScore += 35; $credReasons += "存在集中登录失败" }
elseif ($maxFailed -ge 5) { $credScore += 25; $credReasons += "存在多次登录失败" }
if (@($CredFailedByIP | Where-Object { $_.FailedCount -ge 5 }).Count -gt 0) { $credScore += 25; $credReasons += "存在按来源 IP 聚合的失败登录" }
if (@($CredFailedByIdentity | Where-Object { $_.FailedCount -ge 5 }).Count -gt 0) { $credScore += 15; $credReasons += "存在按 Workstation/账户聚合的失败登录" }
if ($RdpListening) { $credScore += 10; $credReasons += "RDP 端口处于监听状态" }
if ($SmbListening) { $credScore += 10; $credReasons += "SMB 端口处于监听状态" }
if (@($CustomAuthLogHits).Count -gt 0) { $credScore += 10; $credReasons += "存在自定义认证日志 IP 线索" }

if ($credScore -gt 0) {
    Add-EvidenceScore -List $EvidenceScores -Scenario "口令猜测 / 凭证攻击" -Score $credScore `
        -Conclusion "根据 4625 登录失败、服务监听和自定义认证日志综合评分。" `
        -Evidence (($credReasons | Sort-Object -Unique) -join "；") `
        -Priority "优先确认是否存在真实来源 IP、成功登录和后续账户/持久化变化。" `
        -RecommendedAction "导出登录失败明细，关联 4624 成功登录、RDP/SMB 访问和账户变更事件。" `
        -EvidenceIds (Get-EvidenceIdsByTechnique -TechniqueIds @("T1110","T1021.001"))
}

# 5. PowerShell / 脚本执行证据链评分
$scriptScore = 0
$scriptReasons = @()
if (@($PowerShellFindings | Where-Object { $_.Risk -in @("高危","中危") -or $_.Level -in @("高危","中危") }).Count -gt 0) { $scriptScore += 35; $scriptReasons += "存在高危 PowerShell/脚本日志特征" }
if (@($SuspiciousStartup | Where-Object { $_.Command -match '(?i)powershell|wscript|cscript|mshta|\.vbs|\.hta|\.ps1|\.bat|\.cmd' }).Count -gt 0) { $scriptScore += 25; $scriptReasons += "启动项中存在脚本解释器或脚本文件" }
if (@($SuspiciousTasks | Where-Object { $_.Actions -match '(?i)powershell|wscript|cscript|mshta|\.vbs|\.hta|\.ps1|\.bat|\.cmd' }).Count -gt 0) { $scriptScore += 25; $scriptReasons += "计划任务中存在脚本解释器或脚本文件" }
if (@($MiningConfigsGroupedArray | Where-Object { $_.Type -match '下载/投放URL' -and -not (Test-IsLocalOrPrivateIocValue -Value $_.Value) }).Count -gt 0) { $scriptScore += 15; $scriptReasons += "发现公网下载/投放 URL 候选" }

if ($scriptScore -gt 0) {
    Add-EvidenceScore -List $EvidenceScores -Scenario "脚本执行 / 投放链路" -Score $scriptScore `
        -Conclusion "根据 PowerShell/脚本日志、脚本型持久化和投放 URL 综合评分。" `
        -Evidence (($scriptReasons | Sort-Object -Unique) -join "；") `
        -Priority "优先复核脚本内容、执行来源和是否关联服务/任务/启动项。" `
        -RecommendedAction "导出脚本文件、计算 Hash，检查是否包含下载执行、EncodedCommand、Bypass、mshta/wscript 链路。" `
        -EvidenceIds (Get-EvidenceIdsByTechnique -TechniqueIds @("T1059.001","T1059.005","T1218.005"))
}

# 生成处置建议：仅输出建议，不自动执行
foreach ($p in ($ResourceAnomalies | Where-Object { $_.Level -in @("高危","中危") } | Select-Object -First 20)) {
    $hasStrongEvidence = ($p.Score -ge 7 -or $p.Tags -match '(?i)挖矿|矿池|CPU占用|内存占用|公网连接很多|命令行可疑')
    if ($hasStrongEvidence) {
        Add-CleanupAdvice -List $CleanupAdvices -Priority "P1" -RiskType "可疑进程" -Target "$($p.Name) PID=$($p.ProcessId)" `
            -Evidence "CPU=$($p.CpuPercent)，内存=$($p.MemoryMB)MB，公网连接=$($p.PublicConnections)，路径=$($p.ExecutablePath)，标签=$($p.Tags)" `
            -SuggestedCommand "# 先留证：Get-FileHash -Algorithm SHA256 -LiteralPath `"$($p.ExecutablePath)`" ; Get-AuthenticodeSignature -LiteralPath `"$($p.ExecutablePath)`" ; 确认恶意后再执行 Stop-Process -Id $($p.ProcessId) -Force" `
            -SafetyNote "v0.8.5 起不再对中低证据进程直接给强杀命令。请先确认签名、Hash、外联和业务归属。"
    }
    else {
        Add-CleanupAdvice -List $CleanupAdvices -Priority "P3" -RiskType "进程复核" -Target "$($p.Name) PID=$($p.ProcessId)" `
            -Evidence "CPU=$($p.CpuPercent)，内存=$($p.MemoryMB)MB，公网连接=$($p.PublicConnections)，路径=$($p.ExecutablePath)，标签=$($p.Tags)" `
            -SuggestedCommand "Get-FileHash -Algorithm SHA256 -LiteralPath `"$($p.ExecutablePath)`" ; Get-AuthenticodeSignature -LiteralPath `"$($p.ExecutablePath)`"" `
            -SafetyNote "低资源、无公网连接、无持久化关联的进程只建议复核，不建议直接停止。"
    }
}

foreach ($s in ($ServiceEvents | Where-Object { $_.Level -in @("高危","中危") } | Select-Object -First 30)) {
    $svcCmdName = Resolve-ServiceNameForCommand -ServiceName $s.ServiceName -ImagePath $s.ImagePath
    Add-CleanupAdvice -List $CleanupAdvices -Priority "P1" -RiskType "可疑服务" -Target "$($s.ServiceName) [ServiceName=$svcCmdName]" `
        -Evidence "路径=$($s.ImagePath)，原因=$($s.Reason)" `
        -SuggestedCommand "sc.exe stop `"$svcCmdName`" ; sc.exe config `"$svcCmdName`" start= disabled" `
        -SafetyNote "先导出服务配置和服务文件 Hash；确认非业务服务后再禁用。命令优先使用 Win32_Service.Name，而不是显示名。"
}

foreach ($t in ($SuspiciousTasks | Select-Object -First 40)) {
    Add-CleanupAdvice -List $CleanupAdvices -Priority "P2" -RiskType "可疑计划任务" -Target $t.TaskName `
        -Evidence "动作=$($t.Actions)，原因=$($t.Reason)" `
        -SuggestedCommand "schtasks /Change /TN `"$($t.TaskName)`" /Disable" `
        -SafetyNote "建议先使用 schtasks /Query /TN 任务名 /XML 导出任务 XML 留证，确认后再禁用或删除。"
}

foreach ($st in ($SuspiciousStartup | Select-Object -First 40)) {
    $cmd = ""
    $artifactPath = Get-StartupArtifactPath -Location $st.Location -Name $st.Name -Command $st.Command

    if ($st.Location -match '^HK') {
        $cmd = Get-SafeRegDeleteCommand -Location $st.Location -Name $st.Name
    }
    elseif (-not [string]::IsNullOrWhiteSpace($artifactPath)) {
        $cmd = "Remove-Item -LiteralPath `"$artifactPath`" -Force"
    }
    else {
        $cmd = "# 请手工复核并备份后删除启动项：$($st.Name)"
    }

    Add-CleanupAdvice -List $CleanupAdvices -Priority "P2" -RiskType "可疑启动项" -Target $st.Name `
        -Evidence "位置=$($st.Location)，启动项文件=$artifactPath，命令=$($st.Command)，原因=$($st.Reason)" `
        -SuggestedCommand $cmd `
        -SafetyNote "先导出注册表项或备份 Startup 文件；对于 .lnk，应删除 Startup 目录中的 .lnk 本体，不要删除系统解释器。"
}

foreach ($u in ($SuspiciousUsers | Where-Object { $_.Level -in @("高危","中危") } | Select-Object -First 20)) {
    Add-CleanupAdvice -List $CleanupAdvices -Priority "P1" -RiskType "可疑账户" -Target $u.Name `
        -Evidence "原因=$($u.Reasons)，隐藏=$($u.IsHidden)，管理员组=$($u.IsAdmin)，远程桌面组=$($u.IsRemoteDesktopUser)" `
        -SuggestedCommand "Disable-LocalUser -Name `"$($u.Name)`"" `
        -SafetyNote "先确认账户归属并导出账户/组成员/登录事件；未知高危账户优先禁用而不是直接删除。"
}

foreach ($h in ($HiddenAccounts | Select-Object -First 20)) {
    Add-CleanupAdvice -List $CleanupAdvices -Priority "P1" -RiskType "Winlogon 隐藏账户" -Target $h.Account `
        -Evidence "注册表=$($h.RegPath)，值=$($h.Value)" `
        -SuggestedCommand "Remove-ItemProperty -Path `"$($h.RegPath)`" -Name `"$($h.Account)`"" `
        -SafetyNote "先导出注册表项留证；确认不是业务隐藏账户后再删除该隐藏项。"
}

# 高危文件 Hash 建议目标
$hashCandidates = @()
$hashCandidates += @($ResourceAnomalies | Where-Object { $_.ExecutablePath } | ForEach-Object { $_.ExecutablePath })
$hashCandidates += @($ServiceEvents | Where-Object { $_.Level -in @("高危","中危") } | ForEach-Object { Get-FirstPathFromText -Text $_.ImagePath })
$hashCandidates += @($SuspiciousStartup | ForEach-Object {
    $artifactPath = Get-StartupArtifactPath -Location $_.Location -Name $_.Name -Command $_.Command
    if ($artifactPath) { $artifactPath }
    $cmdPath = Get-FirstPathFromText -Text $_.Command
    if ($cmdPath) { $cmdPath }
})
$hashCandidates += @($SuspiciousTasks | ForEach-Object { Get-FirstPathFromText -Text $_.Actions })
$hashCandidates += @($ConfirmedMiningConfigs | ForEach-Object {
    if ($_.SourceFiles) {
        $_.SourceFiles -split "`n"
    }
})

foreach ($hp in ($hashCandidates | Where-Object { $_ -and ($_ -notmatch ':\w+$') } | Sort-Object -Unique | Select-Object -First 200)) {
    if (Test-IsSystemInterpreterPath -Path $hp) { continue }
    if (-not (Test-IsHashCandidatePath -Path $hp)) { continue }

    $exists = Test-Path $hp -PathType Leaf
    $HighRiskHashTargets.Add([PSCustomObject]@{
        FilePath           = $hp
        Exists             = $exists
        SuggestedCommand   = "Get-FileHash -Algorithm SHA256 -LiteralPath `"$hp`""
        Note               = "优先计算 SHA256；必要时补充 MD5/SHA1 并进行威胁情报检索。系统解释器本体已降噪，重点关注被解释执行的脚本/配置/样本文件。"
    }) | Out-Null
}

$EvidenceScoresArray = @($EvidenceScores | Sort-Object Score -Descending)
$CleanupAdvicesArray = @($CleanupAdvices | Sort-Object Priority,RiskType,Target)
$HighRiskHashTargetsArray = @($HighRiskHashTargets | Sort-Object FilePath -Unique)

Export-DetailCsv -Name "证据链评分.csv" -Data $EvidenceScoresArray
Export-DetailCsv -Name "处置建议.csv" -Data $CleanupAdvicesArray
Export-DetailCsv -Name "高危文件Hash建议.csv" -Data $HighRiskHashTargetsArray

