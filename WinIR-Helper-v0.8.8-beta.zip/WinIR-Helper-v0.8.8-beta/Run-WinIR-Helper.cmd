﻿@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0dist\WinIR-Helper.ps1" %*
endlocal
