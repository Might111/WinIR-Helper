﻿# WinIR-Helper v0.8.8-beta

- 收尾修复：将 Get-WinEvent 的“无匹配事件”从读取失败中拆出，避免 RDP 1149 或 PowerShell 4103/4104 未命中时误报数据完整性异常。
- 增强 Hyper-V / WSL / Docker / vmswitch.sys 降噪，VMSMP 不再被判定为随机驱动服务，也不再生成 P1 禁用建议。
- 报告维持威胁项、暴露面风险、数据完整性分开展示，适合作为 v0.8 模块化 beta 的收口版本。

# CHANGELOG

## v0.8.8-beta

### 修复

- 修复 Windows PowerShell 5.1 下运行 `dist/WinIR-Helper.ps1` 时出现 `ParserError`、中文乱码、字符串中断的问题。根因是单文件脚本由非 Windows 环境生成时为 UTF-8 无 BOM，旧版 Windows PowerShell 会按本地 ANSI 代码页解析。
- 所有 `.ps1` 与配置 JSON 统一写入 UTF-8 with BOM。
- `build/Build-SingleFile.ps1` 改为使用 `[System.Text.UTF8Encoding]::new($true)` 显式写入 BOM，避免后续重新打包再次出现编码问题。

### 优化

- 保留 v0.8.4 的日志读取健康检查、事件读取 fallback、端口风险与威胁风险分离、BurpSuite/QuarkUpdater 降噪和公网连接聚合。

## v0.8.8-beta

### 修复

- 修复部分环境下 Security 事件读取结果异常为 0 时缺少解释的问题。
- 增加事件读取 fallback：默认 Auto 模式依次尝试 FilterHashtable、XPath 和 RecentScan。
- 记录每个日志通道的探测状态、查询方法、返回数量和异常信息，并在 HTML 报告中展示。

### 优化

- 首页统计将威胁发现与暴露面风险分开，避免监听端口直接造成“高危入侵”的误读。
- BurpSuite 内置浏览器、QuarkUpdater、Npcap、Hotpatch、Acunetix/Nessus 等测试环境常见组件继续降噪。
- 低资源、无公网连接、无持久化关联的进程只给复核建议，不直接给强杀命令。
- 公网连接新增按进程聚合展示，完整明细可通过 `-ExportDetails` 导出。
- 8080 仅监听 127.0.0.1 时降为关注。

### 使用建议

如果报告显示“数据完整性：需确认”，建议优先运行：

```powershell
.\Run-WinIR-Helper.cmd -EventReadMode RecentScan -EventRecentScanMaxEvents 80000
```

或手工验证：

```powershell
Get-WinEvent -LogName Security -MaxEvents 1
Get-WinEvent -FilterHashtable @{LogName='Security'; Id=4624; StartTime=(Get-Date).AddDays(-7)} -MaxEvents 5
```
