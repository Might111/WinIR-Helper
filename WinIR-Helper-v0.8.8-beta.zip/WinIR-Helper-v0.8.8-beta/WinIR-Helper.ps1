﻿<#
.SYNOPSIS
    v0.8.8-beta - WinIR-Helper 模块化重构版主入口。

.DESCRIPTION
    v0.8.8-beta 保留模块化源码结构，修复 Windows PowerShell 5.1 对 UTF-8 无 BOM 脚本的解析问题，并继续优化日志读取可信度。
    主入口只负责参数、配置加载、模块编排和运行入口；具体采集、分析、评分、报告导出在 modules/ 中维护。

.NOTES
    本工具只做蓝队应急响应辅助取证与线索整理，不做查杀，不替代 EDR、杀毒软件等专业工具。
    请仅在合法授权环境中使用。
#>

param(
    [int]$Days = 7,
    [int]$FocusDays = 3,
    [datetime]$StartTime,
    [datetime]$EndTime,
    [string]$OutputDir = "",
    [string]$LogFolder = "",
    [ValidateSet("Live","Offline")]
    [string]$Mode = "Live",
    [string]$ConfigPath = "",
    [switch]$AllowNonAdmin,
    [switch]$ExportDetails,
    [switch]$NoHash,
    [int]$CpuSampleSeconds = 3,
    [double]$CpuHighPercent = 30,
    [double]$MemoryHighMB = 1024,
    [double]$MemoryHighPercent = 25,
    [ValidateSet("Fast","Full")]
    [string]$SecurityProfile = "Fast",
    [int]$SecurityMaxEvents = 30000,
    [ValidateSet("Auto","Hashtable","XPath","RecentScan")]
    [string]$EventReadMode = "Auto",
    [int]$EventRecentScanMaxEvents = 50000,
    [string[]]$HashFile = @(),
    [string]$HashFolder = "",
    [switch]$HashRecurse,
    [switch]$HashOnly,
    [ValidateSet("MD5","SHA1","SHA256","SHA384","SHA512")]
    [string[]]$HashAlgorithm = @("MD5","SHA1","SHA256")
)

$Version = "v0.8.8-beta"
$ScriptName = "WinIR-Helper.ps1"
$script:RunMode = $Mode
$script:ProjectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$script:ModuleRoot = Join-Path $script:ProjectRoot "modules"

$helperModules = @(
    "00-Core.ps1",
    "01-EventParsing.ps1",
    "02-ProcessNetworkHelpers.ps1",
    "03-Configuration.ps1"
)

foreach ($m in $helperModules) {
    $path = Join-Path $script:ModuleRoot $m
    if (-not (Test-Path $path -PathType Leaf)) { throw "缺少模块文件：$path" }
    . $path
}

if ([string]::IsNullOrWhiteSpace($ConfigPath)) {
    $defaultConfig = Join-Path $script:ProjectRoot "config\WinIR-Helper.config.json"
    if (Test-Path $defaultConfig -PathType Leaf) { $ConfigPath = $defaultConfig }
}
Initialize-WinIRConfig -ConfigPath $ConfigPath

# 独立文件 Hash 计算模式：保持旧版本调用习惯。
if ($HashOnly -or $HashFile.Count -gt 0 -or -not [string]::IsNullOrWhiteSpace($HashFolder)) {
    Invoke-HashCalculator
    return
}

$runtimeModules = @(
    "10-Initialize.ps1",
    "20-Collect-SecurityEvents.ps1",
    "21-Collect-RdpEvents.ps1",
    "22-Collect-ServiceEvents.ps1",
    "23-Collect-Accounts.ps1",
    "24-Collect-Persistence.ps1",
    "25-Collect-ProcessesNetwork.ps1",
    "26-Analyze-MiningConfig.ps1",
    "27-Analyze-PowerShell.ps1",
    "30-Analyze-Scenarios.ps1",
    "31-Build-TimelineAttack.ps1",
    "32-Score-And-Advisory.ps1",
    "90-Export-Report.ps1"
)

foreach ($m in $runtimeModules) {
    $path = Join-Path $script:ModuleRoot $m
    if (-not (Test-Path $path -PathType Leaf)) { throw "缺少模块文件：$path" }
    . $path
}
