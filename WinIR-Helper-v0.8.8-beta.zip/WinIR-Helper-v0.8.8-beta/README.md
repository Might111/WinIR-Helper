﻿# WinIR-Helper v0.8.8-beta

Windows 应急响应辅助脚本。v0.8 系列采用模块化源码维护，同时在 `dist/` 中提供单文件运行版，方便现场使用。

## v0.8.5 重点修复

- 所有 PowerShell 脚本改为 UTF-8 with BOM，兼容 Windows PowerShell 5.1，避免中文字符串在旧版 PowerShell 中被当作 ANSI 解析导致 ParserError。
- `build/Build-SingleFile.ps1` 改为使用 .NET 显式写入 UTF-8 BOM，后续重新打包不会再次生成无 BOM 单文件。
- `config/WinIR-Helper.config.json` 同步使用 UTF-8 with BOM，避免配置中的中文或特殊字符在 Windows PowerShell 5.1 下读取异常。

## 推荐运行方式

管理员 PowerShell 或 CMD 中运行：

```powershell
.\Run-WinIR-Helper.cmd
```

或直接运行单文件版：

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\dist\WinIR-Helper.ps1
```

## v0.8.5 重点优化

- 事件日志读取改为 Auto 模式：Hashtable → XPath → RecentScan 自动 fallback。
- 新增数据完整性状态，避免把“事件读取为 0”误解成“系统安全”。
- 首页将威胁项与暴露面风险分开展示。
- BurpSuite 内置浏览器、QuarkUpdater 等开发/测试环境常见进程进一步降噪。
- P1 处置建议更保守：不再对中低证据进程直接给 `Stop-Process -Force`，优先提示 Hash、签名和业务归属复核。
- 公网连接按进程聚合，减少代理/聊天软件/浏览器造成的报告刷屏。

## 常用参数

```powershell
# 最近 7 天，默认 Fast Security 模式
.\Run-WinIR-Helper.cmd

# 如果 Security 事件异常为 0，可强制使用 RecentScan 兜底
.\Run-WinIR-Helper.cmd -EventReadMode RecentScan -EventRecentScanMaxEvents 80000

# 缩短时间范围，提高完整性和速度
.\Run-WinIR-Helper.cmd -Days 1 -SecurityProfile Full

# 离线 EVTX 分析
.\Run-WinIR-Helper.cmd -Mode Offline -LogFolder .\evtx

# 导出详细 CSV
.\Run-WinIR-Helper.cmd -ExportDetails
```

## 目录结构

```text
WinIR-Helper.ps1              模块化主入口，开发调试用
modules/                      模块化源码
config/                       默认配置
dist/WinIR-Helper.ps1         单文件运行版
build/Build-SingleFile.ps1    单文件打包脚本
```

本工具只做线索整理和辅助取证，不执行查杀，不自动清理系统。
